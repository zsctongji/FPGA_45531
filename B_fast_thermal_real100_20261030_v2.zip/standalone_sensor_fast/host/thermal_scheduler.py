"""Finite MLX reads and pair assembly. No hardware is opened by this module."""
from dataclasses import dataclass
import time


class CaptureError(RuntimeError):
    pass


def age(now, then):
    value = (now-then)&0xffffffff
    if value >= 0x80000000:
        raise CaptureError("invalid board time order")
    return value


def refresh_control(original, code=3):
    if not 0 <= original <= 65535 or not 0 <= code <= 7:
        raise ValueError("invalid MLX control/refresh code")
    return (original & ~0x0380) | (code << 7)


@dataclass
class Subpage:
    words: list
    ready_observed_ms: int
    clear_completed_ms: int
    read_completed_ms: int
    checked_completed_ms: int
    read_duration_host_ms: float

    @property
    def page(self): return self.words[833]
    @property
    def control(self): return self.words[832]


def validate_frame(words):
    if len(words)!=834 or words[833] not in (0,1):
        raise CaptureError("invalid raw frame dimensions/subpage")
    if any(isinstance(v,bool) or not isinstance(v,int) or not 0<=v<=65535 for v in words):
        raise CaptureError("raw frame must contain uint16 words")
    # Same checked auxiliary positions as the bundled official library.
    aux_indices = [0] + list(range(8,19))+list(range(20,23))+list(range(24,33))+list(range(40,51))+list(range(52,55))+list(range(56,64))
    if any(words[768+i]==0x7fff for i in aux_indices):
        raise CaptureError("invalid auxiliary data")
    if any(words[i]==0x7fff and (i//32)%2==words[833] for i in range(0,768,32)):
        raise CaptureError("invalid pixel-row data")


class FrameReader:
    def __init__(self, io, *, clock=time.monotonic, sleep=time.sleep):
        self.io, self.clock, self.sleep = io, clock, sleep

    def capture(self, budget_ms=1200):
        if not 0 < budget_ms < 2**31:
            raise ValueError("invalid capture budget")
        started = self.clock()
        deadline = started+budget_ms/1000

        def bounded(call):
            if self.clock()>=deadline: raise TimeoutError("subpage deadline before I/O")
            value = call()
            if self.clock()>deadline: raise TimeoutError("subpage deadline after I/O")
            return value

        while True:
            status = bounded(lambda:self.io.read_words(0x8000,1))[0]
            if status & 8: break
            self.sleep(min(.002,max(0,deadline-self.clock())))
        observed = self.io.last_ms
        bounded(lambda:self.io.write_word(0x8000,0x0030))
        cleared = self.io.last_ms
        # 26 x 64-byte bounded transfers, preserving all 832 RAM positions.
        words = bounded(lambda:self.io.read_words(0x0400,832))
        completed = self.io.last_ms
        control = bounded(lambda:self.io.read_words(0x800d,1))[0]
        after = bounded(lambda:self.io.read_words(0x8000,1))[0]
        checked = self.io.last_ms
        if after & 8:
            raise CaptureError("new subpage arrived during RAM read; discard possible torn frame")
        if (after & 1)!=(status & 1):
            raise CaptureError("subpage changed during capture")
        words = list(words)+[control,status&1]
        validate_frame(words)
        age(checked,observed)
        return Subpage(words,observed,cleared,completed,checked,(self.clock()-started)*1000)


class PairAssembler:
    def __init__(self, max_observed_age_ms=500):
        if not 0 < max_observed_age_ms < 2**31:
            raise ValueError("invalid pair age limit")
        self.limit, self.pending = max_observed_age_ms, None

    def reset(self): self.pending = None

    def push(self, frame):
        validate_frame(frame.words)
        for stamp in (frame.ready_observed_ms,frame.clear_completed_ms,
                      frame.read_completed_ms,frame.checked_completed_ms):
            if isinstance(stamp,bool) or not isinstance(stamp,int) or not 0<=stamp<=0xffffffff:
                raise CaptureError("invalid board timestamp")
        age(frame.clear_completed_ms,frame.ready_observed_ms)
        age(frame.read_completed_ms,frame.clear_completed_ms)
        age(frame.checked_completed_ms,frame.read_completed_ms)
        old = self.pending
        if old is None:
            self.pending = frame
            return {"status":"WAITING_FOR_OTHER_SUBPAGE"}
        elapsed = age(frame.checked_completed_ms,old.ready_observed_ms)
        if old.control != frame.control:
            self.pending = frame
            return {"status":"CONTROL_CHANGED_DISCARD_OLD"}
        if old.page == frame.page:
            self.pending = frame
            return {"status":"DUPLICATE_SUBPAGE_REPLACED"}
        if elapsed > self.limit:
            self.pending = frame
            return {"status":"PAIR_OBSERVED_AGE_EXCEEDED", "observed_age_ms":elapsed}
        self.pending = None
        return {"status":"PAIRED_FOR_DIAGNOSTIC_ANALYSIS", "frames":[old,frame],
                "observed_age_ms":elapsed,
                "timestamp_scope":"board ready-observation to final status completion; exposure age and final shared clock unvalidated"}
