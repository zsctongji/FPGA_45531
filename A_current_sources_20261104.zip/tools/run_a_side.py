"""Reproducible A-only tests; preserve the historical twelve-test baseline."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import shutil

root=Path(__file__).resolve().parents[1]
build=root/'build/a_side'
build.mkdir(parents=True,exist_ok=True)
scratch=build/'tmp'
scratch.mkdir(exist_ok=True)
test_env=dict(os.environ,TMP=str(scratch),TEMP=str(scratch))
logs=root/'logs'
logs.mkdir(exist_ok=True)
record=dict(status='RUNNING',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            hardware_tested=False,tests=[],source_sha256={})
sources=['rtl/a_side_units.v','rtl/ai_frame_mailbox.v','rtl/video_a_capture.v','rtl/video_status_overlay.v','rtl/osd_font5x7.vh','rtl/video_grid_sampler.v','rtl/camera_input_monitor.v','rtl/camera_input_uart.v']
sources += [str(p.relative_to(root)).replace('\\','/') for p in (root/'tools/a_side').glob('*.py')]
sources += ['tools/run_a_side.py']+['sim/'+p+'.sv' for p in ('tb_a_mailbox','tb_a_capture','tb_a_overlay','tb_a_pipeline','tb_camera_input_monitor','tb_camera_input_uart')]
sources += ['sim/tb_a_camera_register_read.sv','projects/11_a_camera_diag/rtl/cam_i2c_ctrl/i2c/i2c_16addr_8data.v']
sources += ['rtl/a_gray_snapshot.v','rtl/a_headless_uart.v','rtl/frame_motion_stats.v','sim/tb_a_gray_snapshot.sv','sim/tb_a_headless_uart.sv']
sources += ['rtl/a_status_guard.v','rtl/video_a_result_display.v','sim/tb_a_status_guard.sv','sim/tb_a_result_display.sv']
sources += ['rtl/a_hdmi_display_exercise.v','sim/tb_a_hdmi_display_exercise.sv','projects/13_a_display_test/a_display_thermal.mem']
for name in sources:record['source_sha256'][name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
status=logs/'a_side_selftest.json'

def save():status.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
def run(name,command,cwd,expected=None):
    result=subprocess.run(command,cwd=cwd,env=test_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',timeout=180)
    (logs/(name+'.log')).write_text(result.stdout,encoding='utf-8')
    passed=result.returncode==0 and (expected is None or expected in result.stdout)
    record['tests'].append(dict(name=name,status='PASS' if passed else 'FAIL',exit_code=result.returncode,log=str(logs/(name+'.log'))))
    save();print(name,record['tests'][-1]['status'],flush=True)
    if not passed:raise RuntimeError(result.stdout[-5000:])

save()
try:
    run('a_python_tests',[sys.executable,'-X','utf8','-m','unittest','-v','test_a_side.py','test_headless.py','test_capture_contract.py','test_csi_debug.py'],root/'tools/a_side')
    iv=root/'tools/iverilog/bin/iverilog.exe'
    vvp=iv.with_name('vvp.exe')
    shutil.copy2(root/'projects/13_a_display_test/a_display_thermal.mem',build/'a_display_thermal.mem')
    top='tb_a_hdmi_display_exercise';output=build/(top+'.vvp')
    run(top+'_compile',[str(iv),'-g2012','-I',str(root/'rtl'),'-s',top,'-o',str(output),str(root/'sim'/(top+'.sv'))]+[str(root/'rtl'/(name+'.v')) for name in ['a_hdmi_display_exercise','video_a_result_display','video_status_overlay','a_status_guard']],build)
    run(top,[str(vvp),str(output)],build,'PASS '+top)
    for top,rtl in [('tb_a_status_guard',['a_status_guard']),('tb_a_result_display',['video_a_result_display','a_status_guard','video_status_overlay']),('tb_a_gray_snapshot',['a_gray_snapshot','video_a_capture','video_grid_sampler','frame_motion_stats']),('tb_a_headless_uart',['a_headless_uart','camera_input_monitor']),('tb_camera_input_uart',['camera_input_uart','camera_input_monitor']),('tb_camera_input_monitor',['camera_input_monitor']),('tb_a_mailbox',['ai_frame_mailbox']),('tb_a_capture',['video_a_capture','video_grid_sampler']),('tb_a_overlay',['video_status_overlay']),('tb_a_pipeline',['video_a_capture','video_grid_sampler','ai_frame_mailbox'])]:
        output=build/(top+'.vvp')
        run(top+'_compile',[str(iv),'-g2012','-Wall','-I',str(root/'rtl'),'-s',top,'-o',str(output),str(root/'sim'/(top+'.sv'))]+[str(root/'rtl'/(s+'.v')) for s in rtl],build)
        run(top,[str(vvp),str(output)],build,'PASS '+top)
        if top=='tb_camera_input_uart':
            run(top+'_high_compile',[str(iv),'-g2012','-s',top,'-P'+top+'.DATA_VS_HIGH=1','-P'+top+'.HAS_CONFIG=1','-o',str(output),str(root/'sim'/(top+'.sv'))]+[str(root/'rtl'/(s+'.v')) for s in rtl],build)
            run(top+'_high',[str(vvp),str(output)],build,'PASS '+top)
            for polarity in (0,1):
                name=top+'_extended_'+str(polarity)
                run(name+'_compile',[str(iv),'-g2012','-s',top,'-P'+top+'.EXTENDED=1','-P'+top+'.DATA_VS_HIGH='+str(polarity),'-P'+top+'.HAS_CONFIG=1','-o',str(output),str(root/'sim'/(top+'.sv'))]+[str(root/'rtl'/(s+'.v')) for s in rtl],build)
                run(name,[str(vvp),str(output)],build,'PASS '+top)
    top='tb_a_camera_register_read';output=build/(top+'.vvp')
    run(top+'_compile',[str(iv),'-g2012','-s',top,'-o',str(output),str(root/'sim'/(top+'.sv')),str(root/'projects/11_a_camera_diag/rtl/cam_i2c_ctrl/i2c/i2c_16addr_8data.v')],build)
    run(top,[str(vvp),str(output)],build,'PASS '+top)
    record['status']='PASS'
except Exception as exc:
    record['status']='FAIL';record['error']=str(exc);raise
finally:
    record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
