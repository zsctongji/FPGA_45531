import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
B=Path(r'D:\Ti60B\b_delivery');T=Path(r'D:\Ti60B\team_work')
GCC=r'C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe'
RV=r'D:\Ti60B\tools\riscv_gcc\13.4.0\bin\riscv-none-elf-gcc.exe'
env=os.environ.copy();env['PATH']=str(Path(GCC).parent)+';'+env['PATH']
incs=['-I'+str(T/'03_ai_soc'/'c3_hal'),'-I'+str(T/'shared'/'include'),'-I'+str(B/'team_work'/'02_sensors_alarm'/'include'),'-I'+str(B/'third_party'/'mlx90640'/'headers')]
sources=[B/'tests'/'test_b.c',T/'03_ai_soc'/'c3_hal'/'c3_hal.c']+list((B/'team_work'/'02_sensors_alarm'/'src').glob('*.c'))
vendor=B/'third_party'/'mlx90640'/'functions'/'MLX90640_API.c'
report={'at':datetime.now().astimezone().isoformat(),'scope':'OFFLINE_SYNTHETIC_CURRENT_SHARED_HEADERS','real_sensor_samples':0,'source_sha256':{},'steps':[]}
with (ROOT/'checks.log').open('w',encoding='utf-8') as log:
 def run(args,name):
  p=subprocess.run([str(x) for x in args],capture_output=True,text=True,env=env,timeout=45)
  log.write(name+'\n'+p.stdout+p.stderr+'\n');log.flush();report['steps'].append({'step':name,'exit_code':p.returncode})
  if p.returncode:raise RuntimeError(name+' failed')
  if p.stdout:print(p.stdout.strip())
 try:
  objects=[]
  for source in sources+[vendor]:
   report['source_sha256'][str(source)]=hashlib.sha256(source.read_bytes()).hexdigest();obj=ROOT/(source.stem+'.o');objects.append(obj)
   flags=['-std=c11','-O1']+([] if source==vendor else ['-Wall','-Wextra','-Werror'])
   run([GCC]+flags+incs+['-c',source,'-o',obj],'host compile '+source.name)
  for header in [T/'03_ai_soc'/'c3_hal'/'c3_hal.h',T/'shared'/'include'/'cooperation_v1.h']:
   report['source_sha256'][str(header)]=hashlib.sha256(header.read_bytes()).hexdigest()
  run([GCC]+objects+['-static','-lm','-o',ROOT/'test_b_current.exe'],'host link')
  run([ROOT/'test_b_current.exe'],'execute existing B regression against current interfaces')
  for source in sources[1:]+[vendor]:
   run([RV,'-std=c11','-Os','-ffreestanding','-march=rv32imac','-mabi=ilp32']+incs+['-c',source,'-o',ROOT/(source.stem+'_rv32.o')],'RV32 compile '+source.name)
  report['status']='PASS'
 except Exception as exc:report['status']='FAIL';report['error']=repr(exc)
(ROOT/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'},indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
