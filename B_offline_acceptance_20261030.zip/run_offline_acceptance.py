"""One offline evidence run. Success means execution succeeded, not board release."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import struct

from gate_host import Gate, build_library
from gray96_adapter import prepare_frame, fnv1a32
from thermal_features import analyze

ROOT = Path(__file__).resolve().parent


def load_json(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(ok, message):
    if not ok: raise ValueError(message)


def crc8(data):
    c = 255
    for b in data:
        c ^= b
        for _ in range(8): c = (((c << 1) ^ 0x31) if c & 128 else c << 1) & 255
    return c


def assess_release(checks):
    required = ("environment_source_integrity", "thermal_source_integrity",
                "thermal_quality_policy", "thermal_pair_500ms", "shared_clock_validated",
                "real_image_same_session", "final_soc_i2c_deadlines_validated")
    # Missing evidence is a failed release condition, never a default pass.
    blockers = [k for k in required if checks.get(k) is not True]
    return {"release_allowed":not blockers,"status":"READY_FOR_REVIEW" if not blockers else "BLOCKED_BY_EVIDENCE",
            "checks":{k:checks.get(k) is True for k in required},"blockers":blockers}


def verify_provenance():
    p = load_json(ROOT/"provenance.json")
    for entry in p["files"]:
        file = ROOT/entry["path"]
        require(file.is_file() and sha(file)==entry["sha256"], "source changed: "+entry["path"])
    return {"status":"PASS","files_verified":len(p["files"]),"sha256":sha(ROOT/"provenance.json")}


def analyze_sht(gate):
    folder = ROOT/"inputs/sht30"
    summary = load_json(folder/"summary.json")
    for name,digest in summary["sha256"].items():
        require(sha(folder/name)==digest,"original SHT source hash: "+name)
    rows = [json.loads(line) for line in (folder/"sht30_cycles.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    wire = [json.loads(line) for line in (folder/"uart_transactions.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    require(len({r["sample_id"] for r in rows})==len(rows),"duplicate SHT sample id")
    results, temps, humidities, last_ts = [], [], [], None
    for row in rows:
        raw = bytes.fromhex(row["raw_hex"])
        t, h = round(row["temperature_c"]*100), round(row["humidity_percent"]*100)
        if row["valid"]:
            require(row["rc"]==0 and row["get_rc"]==0 and row["valid_flags"]==7 and row["error_bits"]==0,"SHT valid status mismatch")
            require(len(raw)==6 and crc8(raw[:2])==raw[2] and crc8(raw[3:5])==raw[5],"SHT CRC mismatch")
            require(t==-4500+(17500*int.from_bytes(raw[:2],"big")+32767)//65535,"SHT temperature conversion mismatch")
            require(h==(10000*int.from_bytes(raw[3:5],"big")+32767)//65535,"SHT humidity conversion mismatch")
            require(any(w.get("status")==0 and w.get("board_ms")==row["board_timestamp_ms"] and
                        bytes.fromhex(w["response_hex"])[9:-1]==raw for w in wire),"SHT UART evidence mismatch")
            if last_ts is not None:
                require(0 < ((row["board_timestamp_ms"]-last_ts)&0xffffffff) < 0x80000000,"SHT timestamp order")
            last_ts = row["board_timestamp_ms"]
            temps.append(row["temperature_c"]); humidities.append(row["humidity_percent"])
        else:
            require(row["rc"]!=0 and row["error_bits"]!=0,"SHT failure lost error")
        # Reconstruction for policy replay only: not an observed fusion publication.
        decision = gate.environment(sample_id=row["sample_id"],timestamp_ms=row["board_timestamp_ms"],
                                    flags=row["valid_flags"],errors=row["error_bits"],temp_centi=t,
                                    humidity_centi=h,now_ms=row["board_timestamp_ms"])
        require(decision["copy_or_rejection_preserved"],"C gate mutated rejected output")
        require((decision["rc"]==0)==row["valid"],"unexpected C gate decision on saved SHT row")
        results.append({"cycle":row["cycle"],"source_valid":row["valid"],"source_rc":row["rc"],
                        "board_timestamp_ms":row["board_timestamp_ms"],**decision})
    accepted = sum(r["rc"]==0 for r in results)
    return {"scope":"SAVED_REAL_SHT30_LOG_PLUS_CONDITIONAL_HOST_C_REPLAY",
            "cycles":len(rows),"raw_valid_samples":len(temps),"failed_cycles":len(rows)-len(temps),
            "host_gate_accepted":accepted,"host_gate_rejected":len(rows)-accepted,
            "failed_cycle_numbers":[r["cycle"] for r in rows if not r["valid"]],
            "temperature_c":{"min":min(temps),"max":max(temps),"mean":statistics.mean(temps)},
            "humidity_percent":{"min":min(humidities),"max":max(humidities),"mean":statistics.mean(humidities)},
            "freshness_probe":"now equals saved board acquisition timestamp; does not validate age at real fusion/image publication",
            "row_results":results}


def thermal_timing():
    folder = ROOT/"inputs/mlx90640"
    transactions = load_json(folder/"transactions.json")
    source_summary = load_json(folder/"summary.json")
    require(sha(folder/"transactions.json")==source_summary["sha256_transactions"],"MLX transaction hash mismatch")
    wire = [json.loads(line) for line in (folder/"uart_transactions.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    for t in transactions:
        if t["rx_hex"]:
            require(t["rc"]==0 and any(w.get("status")==0 and w.get("board_ms")==t["board_ms"] and
                    bytes.fromhex(w["response_hex"])[9:-1].hex()==t["rx_hex"] for w in wire),"MLX UART mismatch")
    ee = b"".join(bytes.fromhex(t["rx_hex"]) for t in transactions if len(t["tx_hex"])==4 and 0x2400<=int(t["tx_hex"],16)<0x2740)
    require(ee==(folder/"eeprom_u16_be.bin").read_bytes(),"MLX EEPROM mismatch")
    groups, current = [], None
    for t in transactions:
        if t["tx_hex"]=="80000030":
            current={"clear_ms":t["board_ms"],"ram":bytearray()};groups.append(current)
        elif current is not None and len(t["tx_hex"])==4:
            reg=int(t["tx_hex"],16)
            if 0x400<=reg<=0x73f: current["ram"].extend(bytes.fromhex(t["rx_hex"]))
            elif reg==0x800d:
                current["control"]=int(t["rx_hex"],16);current["end_ms"]=t["board_ms"]
    require(len(groups)==2,"expected two captured subpages")
    ids=[]
    for i,g in enumerate(groups):
        frame=struct.unpack(">834H",(folder/("frame%d_u16_be.bin"%i)).read_bytes())
        require(bytes(g.pop("ram"))==struct.pack(">832H",*frame[:832]),"MLX indexed frame bytes mismatch")
        require(g["control"]==frame[832],"MLX control mismatch")
        g["subpage"]=frame[833];ids.append(frame[833])
        g["read_duration_ms"]=(g["end_ms"]-g["clear_ms"])&0xffffffff
        require(g["read_duration_ms"]<0x80000000,"invalid MLX duration")
    require(set(ids)=={0,1} and groups[0]["control"]==groups[1]["control"],"MLX mode/subpage mismatch")
    delta=(groups[1]["end_ms"]-groups[0]["end_ms"])&0xffffffff
    require(delta<0x80000000,"invalid subpage completion order")
    return {"groups":groups,"oldest_completion_age_lower_bound_at_second_completion_ms":delta,
            "limit_ms":500,"pair_within_limit":delta<=500,
            "clock_scope":"saved FPGA transaction clock only; final shared fusion clock is unvalidated"}


def run(output_dir, compiler=None):
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    integrity=verify_provenance()
    library,build=build_library(output_dir/"build",compiler)
    grid=load_json(ROOT/"inputs/mlx_corrected_grid.json")
    features=analyze(grid)
    timing=thermal_timing()
    source_summary=load_json(ROOT/"inputs/mlx90640/summary.json")
    audited=load_json(ROOT/"inputs/audit_summary.json")
    require(features["valid_pixels"]==audited["mlx90640"]["valid_pixels"],"audited MLX valid count changed")
    mask=bytes.fromhex(grid["pixel_valid_bits_hex"])
    # Invalid slots use an arbitrary ABI placeholder zero but remain masked;
    # the feature tool keeps nulls. No bad-pixel temperature is imputed.
    temperatures=[round(v*100) if v is not None else 0 for v in grid["temperature_c"]]
    first,last=timing["groups"][0]["end_ms"],timing["groups"][1]["end_ms"]
    with Gate(library) as gate:
        sht=analyze_sht(gate)
        kwargs=dict(sample_id=source_summary["thermal_sample_id"],timestamp_ms=first,
                    flags=source_summary["thermal_valid_flags"],errors=source_summary["thermal_error_bits"],
                    temperatures=temperatures,mask=mask)
        quality_probe=gate.thermal(now_ms=first,**kwargs)
        age_probe=gate.thermal(now_ms=last,**kwargs)
        min_valid=int(gate.lib.host_min_valid_pixels())
    require(quality_probe["copy_or_rejection_preserved"] and age_probe["copy_or_rejection_preserved"],"thermal C output preservation failed")
    # This is explicitly a synthetic component exercise, not a real A frame.
    gradient=bytes((x*3+y*5)&255 for y in range(54) for x in range(96))
    image=prepare_frame(gradient,event_id=1,frame_id=1,capture_ms=0,motion_bbox_96x54=(0,0,95,53))
    require(image.gray8[:2016]==bytes(2016) and image.gray8[2016:7200]==gradient and image.gray8[7200:]==bytes(2016),"image padding mismatch")
    require(image.motion_bbox_96x96==(0,21,95,74) and len(image.tensor_int8)==9216,"image adapter metadata mismatch")
    decision=assess_release({"environment_source_integrity":True,"thermal_source_integrity":True,
                            "thermal_quality_policy":quality_probe["rc"]==0,
                            "thermal_pair_500ms":timing["pair_within_limit"],
                            "shared_clock_validated":False,"real_image_same_session":False,
                            "final_soc_i2c_deadlines_validated":False})
    report={"schema":"B_OFFLINE_ACCEPTANCE_V1","executed_at_utc":datetime.now(timezone.utc).isoformat(),
            "execution_status":"PASS","scope":"OFFLINE_ANALYSIS_OF_SAVED_REAL_SENSOR_LOGS_AND_SYNTHETIC_IMAGE_CHECK",
            "hardware_accessed":False,"new_board_measurements":0,"provenance":integrity,"build":build,
            "sht30":sht,"thermal_features":features,
            "thermal_policy":{"source_flags":source_summary["thermal_valid_flags"],
                              "source_error_bits":source_summary["thermal_error_bits"],
                              "actual_b4_default_min_valid_pixels":min_valid,
                              "rounding":"valid temperatures rounded to nearest centi-C for host ABI probe",
                              "quality_only_age_zero_probe":quality_probe,
                              "oldest_subpage_age_lower_bound_probe":age_probe,
                              "probe_scope":"reconstructed host inputs; not an observed on-board publish call",
                              "flags_and_error_bits_preserved":True,
                              "shared_driver_policy_difference":"C3 strict pair driver and B4 warning-tolerant quality policy remain distinct; no ABI/driver change"},
            "thermal_timing":timing,
            "image_component":{"scope":"SYNTHETIC_COMPONENT_CHECK_ONLY","policy":image.policy_id,
                               "source_dimensions":[96,54],"output_dimensions":[96,96],
                               "bytes":len(image.gray8),"fnv1a":"0x%08X"%fnv1a32(image.gray8),
                               "real_camera_or_model_acceptance":False},
            "release_decision":decision,
            "limitations":["No simultaneous real image/environment/thermal capture is bundled.",
                           "The corrected thermal grid is a previously audited derived input, not a fresh radiometric recalculation in this runner.",
                           "Median+2C and area>=3 are exploratory settings without human/fall ground truth.",
                           "No final SoC I2C timing, inference, cold boot, Flash programming, or buzzer test was run."]}
    (output_dir/"offline_acceptance.json").write_text(json.dumps(report,ensure_ascii=False,allow_nan=False,indent=2)+"\n",encoding="utf-8")
    (output_dir/"thermal_features.json").write_text(json.dumps(features,ensure_ascii=False,allow_nan=False,indent=2)+"\n",encoding="utf-8")
    text=make_markdown(report)
    (output_dir/"B_离线验收结果.md").write_text(text,encoding="utf-8")
    return report


def make_markdown(r):
    s,t,f=r["sht30"],r["thermal_timing"],r["thermal_features"]
    return f'''# B 离线分析与统一验收结果

执行状态：{r["execution_status"]}。整机发布条件：{r["release_decision"]["status"]}。

本次只重放已保存的真实传感器日志，并检查合成图像适配器。没有连接板卡，没有新增测量。

| 检查 | 结果 | 证据边界 |
|---|---|---|
| SHT30 | {s["cycles"]} 次周期，{s["raw_valid_samples"]} 个有效样本、{s["failed_cycles"]} 次失败 | 原始 UART、CRC、换算与 SHA256 重新核对 |
| 原 C 环境闸门 | 接收 {s["host_gate_accepted"]}，拒绝 {s["host_gate_rejected"]} | 主机条件重放，now 取同条记录的采集时间；未证明实际发布新鲜度 |
| MLX90640 | {f["valid_pixels"]}/768 有效，坏点 {f["invalid_indices_zero_based"]} | 保留完整坐标及 96 字节有效位图，不插值 |
| 热图质量策略 | 原 C B4 默认最低 {r["thermal_policy"]["actual_b4_default_min_valid_pixels"]} 像素，质量探针 rc={r["thermal_policy"]["quality_only_age_zero_probe"]["rc"]} | 允许坏点警告并保留 flags=3、error=64；未把标志改成 7 |
| 热图时间条件 | 子页完成差 {t["oldest_completion_age_lower_bound_at_second_completion_ms"]} ms，限制 {t["limit_ms"]} ms | 不通过；最早子页在第二页完成时已经至少这么旧 |
| 96×96 图像适配 | 合成图检查通过 | 不能作为真实相机、模型或三路同步验收 |

有效温度范围 {f["statistics_valid_only"]["min_c"]:.3f}～{f["statistics_valid_only"]["max_c"]:.3f} °C。
热区候选阈值为有效像素中位数 + 2 °C（本帧 {f["candidate_policy"]["threshold_c"]:.3f} °C），四邻域、至少 3 像素；
得到 {len(f["candidates"])} 个候选区域。这只是探索性热区特征，没有人体/跌倒真值，不代表人体或跌倒检测成功。

整机发布仍缺以下条件：

'''+"\n".join("- "+v for v in r["release_decision"]["blockers"])+'''

后续上板应采集同一时钟下的真实图像、温湿度与连续双子页热图，验证完整 I2C 事务预算和真实发布年龄，
并取得目标场景及负样本的标注。当前结果不证明推理准确率、低功耗唤醒、断电启动或蜂鸣器冷启动。

源文件校验、编译信息、逐样本结果见 offline_acceptance.json；热区参数与位图见 thermal_features.json。
'''


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir",type=Path,default=ROOT/"results")
    parser.add_argument("--cc")
    args=parser.parse_args()
    result=run(args.output_dir,args.cc)
    print(json.dumps({"execution_status":result["execution_status"],"hardware_accessed":False,
                      "release_decision":result["release_decision"],"report":str(args.output_dir/"offline_acceptance.json")},indent=2))
