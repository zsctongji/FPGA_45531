"""Extract reproducible camera/reference facts without opening any hardware."""
from pathlib import Path
import datetime,hashlib,json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
VENDOR=ROOT/'vendor_projects/Ti60_V4/07_Ti60F225_MIPI_C2D_Demo/Ti60f225_csi2dsi_sc431hai_v3.4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def registers(path):
    s=path.read_text(encoding='utf-8',errors='replace')
    s=re.sub(r'/\*.*?\*/','',s,flags=re.S);s=re.sub(r'//[^\n]*','',s)
    entries=re.findall(r"ROM\[8'h([0-9a-f]+)\]\s*=\s*\{\s*16'h([0-9a-f]+),\s*8'h([0-9a-f]+),\s*1'b([01])\s*\}",s,re.I)
    result={}
    for index,address,value,read in entries:
        if read=='0':result[f'0x{int(address,16):04X}']=f'0x{int(value,16):02X}'
    return result, len(entries)
def peripheral(path):
    root=ET.parse(path).getroot();rx=[];plls=[]
    for el in root.iter():
        tag=el.tag.split('}')[-1]
        # Efinity reserialization adds an empty dly_clock_name. Preserve raw
        # XML hashes but normalize semantically absent optional attributes.
        if tag=='rx_info':rx.append({k:v for k,v in el.attrib.items() if v!=''})
        if tag=='pll':plls.append(dict(el.attrib))
    return dict(rx_info=rx,plls=plls,sha256=sha(path))
def main():
    base_rom=VENDOR/'rtl/cam_i2c_ctrl/i2c/i2c_master_reg_rom.v'
    base,_=registers(base_rom);base_peri=peripheral(VENDOR/'ti60f225_oob.peri.xml')
    record=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),hardware_accessed=False,
        scope='static source/reference comparison, not SoT diagnosis or electrical acceptance',
        reference=str(VENDOR.relative_to(ROOT)),reference_rom_sha256=sha(base_rom),projects={})
    expected={'0x3E00':'0x00','0x3E01':'0x7D','0x3E02':'0x00','0x320E':'0x05','0x320F':'0xD2'}
    for name in ['11_a_camera_diag','12_a_headless','13_a_display_test']:
        p=ROOT/'projects'/name;rom=p/'rtl/cam_i2c_ctrl/i2c/i2c_master_reg_rom.v'
        current,count=registers(rom);peri=peripheral(p/'ti60f225_oob.peri.xml')
        delta={k:dict(reference=base.get(k),current=current.get(k)) for k in base.keys()|current.keys() if base.get(k)!=current.get(k)}
        unexpected={k:v for k,v in delta.items() if k not in expected or v['current']!=expected[k]}
        clocks=re.findall(r'create_clock -period ([0-9.]+) -name (\S+)',(p/'ti60f225_oob.sdc').read_text(errors='replace'))
        item=dict(rom_sha256=sha(rom),rom_entries=count,register_delta=delta,
            expected_runtime_values_match=all(current.get(k)==v for k,v in expected.items()),
            unexpected_write_changes=unexpected,peripheral=peri,
            rx_attributes_equal_reference=peri['rx_info']==base_peri['rx_info'],
            declared_clock_period_ns={n:float(t) for t,n in clocks},
            top_sha256=sha(p/'rtl/ti60f225_oob_top.v'))
        record['projects'][name]=item
    record['static_check']='PASS' if all(p['expected_runtime_values_match'] and not p['unexpected_write_changes'] and p['rx_attributes_equal_reference'] for p in record['projects'].values()) else 'REVIEW_REQUIRED'
    record['physical_remaining']=['actual module/PCB/polarity/cable and voltages','SoT lane error telemetry in a new real session','source RAW/debayer/one-pixel C2 integration','PLL/Bank/pad ownership and final SDC/CDC/P&R']
    target=ROOT/'logs/a_camera_reference_20261103.json'
    target.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    for n,p in record['projects'].items():print(n,'rx_equal=',p['rx_attributes_equal_reference'],'expected_exposure=',p['expected_runtime_values_match'],'unexpected=',p['unexpected_write_changes'])
    print(record['static_check'],str(target))
    return 0 if record['static_check']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
