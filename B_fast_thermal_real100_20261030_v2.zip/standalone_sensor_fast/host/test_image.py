import contextlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from load_fast_sram import ROOT, main, preflight


class ImageChecks(unittest.TestCase):
    def test_default_only_verifies_files(self):
        with patch("load_fast_sram.program",side_effect=AssertionError("unexpected programming")) as program:
            with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(main([]),0)
        program.assert_not_called()
    def test_changed_bit_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/"outflow";target.mkdir()
            raw=bytearray((ROOT/"outflow/B_sensor_fast.bit").read_bytes());raw[-1]^=1
            (target/"B_sensor_fast.bit").write_bytes(raw)
            with self.assertRaisesRegex(RuntimeError,"hash mismatch"):preflight(directory)
    def test_changed_design_source_is_rejected(self):
        evidence=json.loads((ROOT/"logs/build_evidence.json").read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)
            for relative in list(evidence["files_sha256"])+["logs/build_evidence.json"]:
                destination=target/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(ROOT/relative,destination)
            changed=target/"src/B_sensor_fast.v"
            changed.write_bytes(changed.read_bytes()+b"\n// changed\n")
            with self.assertRaisesRegex(RuntimeError,"evidence changed"):preflight(target)


if __name__=="__main__":unittest.main()
