"""Standalone 96x54 GRAY8 -> 96x96 adapter for B-side integration.

The current candidate policy is deliberately explicit: keep each 96x54 row
unchanged and add 21 zero rows above and below. This is an adapter with a
versioned policy, not a claim that the final camera/model preprocessing has
been accepted by A/C.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

SOURCE_W = 96
SOURCE_H = 54
PAD_TOP = 21
PAD_BOTTOM = 21
IMAGE_W = 96
IMAGE_H = 96
IMAGE_BYTES = IMAGE_W * IMAGE_H
SOURCE_BYTES = SOURCE_W * SOURCE_H
POLICY_ID = "GRAY54_PAD_Y21_ZERO_V1"


class FrameError(ValueError):
    pass


def fnv1a32(data: bytes) -> int:
    value = 0x811C9DC5
    for byte in data:
        value = ((value ^ byte) * 0x01000193) & 0xFFFFFFFF
    return value


def sum32(data: bytes) -> int:
    return sum(data) & 0xFFFFFFFF


def pad_gray54(source: bytes) -> bytes:
    if len(source) != SOURCE_BYTES:
        raise FrameError(f"expected {SOURCE_BYTES} source bytes, got {len(source)}")
    return b"\x00" * (PAD_TOP * IMAGE_W) + source + b"\x00" * (PAD_BOTTOM * IMAGE_W)


def gray_to_vendor_int8(gray96: bytes) -> bytes:
    if len(gray96) != IMAGE_BYTES:
        raise FrameError(f"expected {IMAGE_BYTES} gray bytes, got {len(gray96)}")
    return bytes(((pixel - 128) & 0xFF) for pixel in gray96)


def map_motion_bbox(bbox: tuple[int, int, int, int] | None) -> tuple[int, int, int, int] | None:
    """Map a 96x54 motion box into the padded 96x96 image coordinates."""
    if bbox is None:
        return None
    x0, y0, x1, y1 = bbox
    if not (0 <= x0 <= x1 < SOURCE_W and 0 <= y0 <= y1 < SOURCE_H):
        raise FrameError("motion bbox is outside the 96x54 source grid")
    return x0, y0 + PAD_TOP, x1, y1 + PAD_TOP


@dataclass(frozen=True)
class PreparedFrame:
    event_id: int
    frame_id: int
    capture_ms: int
    policy_id: str
    width: int
    height: int
    stride: int
    gray8: bytes
    tensor_int8: bytes
    gray_fnv1a: int
    gray_sum32: int
    motion_bbox_96x96: tuple[int, int, int, int] | None

    def metadata(self) -> dict:
        bbox = self.motion_bbox_96x96
        return {
            "event_id": self.event_id,
            "frame_id": self.frame_id,
            "capture_ms": self.capture_ms,
            "policy_id": self.policy_id,
            "source_width": SOURCE_W,
            "source_height": SOURCE_H,
            "width": self.width,
            "height": self.height,
            "stride": self.stride,
            "format": "GRAY8",
            "bytes": len(self.gray8),
            "gray_fnv1a": f"0x{self.gray_fnv1a:08X}",
            "gray_sum32": self.gray_sum32,
            "tensor_preprocess": "pixel_minus_128_mod_256",
            "motion_bbox_96x96": list(bbox) if bbox is not None else None,
        }


def prepare_frame(
    source: bytes,
    *,
    event_id: int,
    frame_id: int,
    capture_ms: int,
    motion_bbox_96x54: tuple[int, int, int, int] | None = None,
) -> PreparedFrame:
    for name, value in (("event_id", event_id), ("frame_id", frame_id), ("capture_ms", capture_ms)):
        if not isinstance(value, int) or not 0 <= value <= 0xFFFFFFFF:
            raise FrameError(f"{name} must be uint32")
    gray = pad_gray54(source)
    return PreparedFrame(
        event_id=event_id,
        frame_id=frame_id,
        capture_ms=capture_ms,
        policy_id=POLICY_ID,
        width=IMAGE_W,
        height=IMAGE_H,
        stride=IMAGE_W,
        gray8=gray,
        tensor_int8=gray_to_vendor_int8(gray),
        gray_fnv1a=fnv1a32(gray),
        gray_sum32=sum32(gray),
        motion_bbox_96x96=map_motion_bbox(motion_bbox_96x54),
    )


def write_prepared_frame(source_path: Path, output_dir: Path, *, event_id: int, frame_id: int,
                         capture_ms: int, motion_bbox: tuple[int, int, int, int] | None = None) -> dict:
    source = source_path.read_bytes()
    frame = prepare_frame(source, event_id=event_id, frame_id=frame_id,
                          capture_ms=capture_ms, motion_bbox_96x54=motion_bbox)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = source_path.stem
    (output_dir / f"{stem}.gray96.bin").write_bytes(frame.gray8)
    (output_dir / f"{stem}.tensor_int8.bin").write_bytes(frame.tensor_int8)
    metadata = frame.metadata()
    (output_dir / f"{stem}.metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return metadata


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Prepare one 96x54 GRAY8 frame for the current 96x96 candidate policy")
    parser.add_argument("source", type=Path, help="exactly 5184 GRAY8 bytes")
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--event-id", type=int, default=1)
    parser.add_argument("--frame-id", type=int, default=1)
    parser.add_argument("--capture-ms", type=int, default=0)
    args = parser.parse_args()
    print(json.dumps(write_prepared_frame(args.source, args.output_dir,
                                          event_id=args.event_id, frame_id=args.frame_id,
                                          capture_ms=args.capture_ms), ensure_ascii=False, indent=2))
