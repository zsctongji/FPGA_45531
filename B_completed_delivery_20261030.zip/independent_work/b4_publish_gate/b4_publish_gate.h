#ifndef B4_PUBLISH_GATE_H
#define B4_PUBLISH_GATE_H
#include "cooperation_v1.h"
#include "b4_quality_policy.h"
#include "b4_temporal_policy.h"
#include <stdint.h>

typedef struct {
    b4_quality_policy_t quality;
    b4_temporal_config_t temporal;
    uint32_t max_thermal_age_ms;
} b4_publish_config_t;

typedef struct {
    b4_temporal_state_t environment_temporal;
} b4_publish_state_t;

#define B4_GATE_REASON_QUALITY_SHIFT 0u
#define B4_GATE_REASON_TEMPORAL_SHIFT 16u
#define B4_GATE_REASON_QUALITY_MASK 0x0000ffffu
#define B4_GATE_REASON_TEMPORAL_MASK 0xffff0000u

void b4_publish_config_default(b4_publish_config_t *config);
void b4_publish_reset(b4_publish_state_t *state);
/* The output is copied only after both gates pass. A rejected sample never
 * updates the environmental history baseline. */
int b4_publish_environment(b4_publish_state_t *state,
                           const coop_environment_t *input,
                           uint32_t now_ms,
                           const b4_publish_config_t *config,
                           coop_environment_t *output,
                           uint32_t *reason_bits);
/* Thermal acceptance permits the audited single bad pixel when the quality
 * policy minimum is met. Its original validity mask and error bits are copied. */
int b4_publish_thermal(const coop_thermal_t *input,
                       uint32_t now_ms,
                       const b4_publish_config_t *config,
                       coop_thermal_t *output,
                       uint16_t *valid_pixels,
                       uint32_t *reason_bits);

#endif
