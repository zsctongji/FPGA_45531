"""Optional low-latency FTDI transport. No enumeration/open on import."""
import time


class D2xxTransport:
    def __init__(self, handle, previous_latency):
        self.handle, self.previous_latency = handle, previous_latency

    @classmethod
    def open(cls, serial_number, port, module=None):
        if not serial_number or not port.upper().startswith("COM") or not port[3:].isdigit():
            raise ValueError("need exact FTDI interface serial and COM port")
        if module is None: import ftd2xx as module
        handle = module.openEx(serial_number.encode("ascii"))
        previous = None
        try:
            # Never enumerate/open other FTDI interfaces to guess the UART.
            if handle.getComPortNumber() != int(port[3:]):
                raise ValueError("FTDI interface serial does not match the confirmed COM port")
            previous = handle.getLatencyTimer()
            handle.setBaudRate(921600)
            handle.setDataCharacteristics(8,0,0)
            handle.setFlowControl(0,0,0)
            handle.clrDtr()
            handle.clrRts()
            handle.setTimeouts(1,20)
            handle.setLatencyTimer(1)
            if handle.getLatencyTimer() != 1: raise RuntimeError("FTDI latency readback mismatch")
            # The real Windows FT4232 link can drop the first request immediately
            # after reconfiguration. Settle before purging and starting deadlines.
            time.sleep(.3)
            handle.purge(3)
            return cls(handle,previous)
        except Exception:
            try:
                if previous is not None: handle.setLatencyTimer(previous)
            finally: handle.close()
            raise

    @property
    def in_waiting(self): return self.handle.getQueueStatus()
    def read(self, count): return self.handle.read(count)
    def write(self, data): return self.handle.write(data)
    def close(self):
        try: self.handle.setLatencyTimer(self.previous_latency)
        finally: self.handle.close()
