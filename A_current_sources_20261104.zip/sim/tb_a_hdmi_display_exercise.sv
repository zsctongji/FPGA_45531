`timescale 1ns/1ps
module tb_a_hdmi_display_exercise;
    localparam W=1280,H=600;
    reg clk=0;always #5 clk=~clk;
    reg rst=0,vs=0,de=0;reg [23:0] rgb=0;
    wire oh,ov,od;wire [23:0] out;wire [2:0] phase;
    integer mode=0,checks=0,file;
    integer prev_x=0,prev_y=0;
    reg prev_de=0,prev_vs=0;reg [23:0] prev_rgb=0;
    a_hdmi_display_exercise #(.WIDTH(W),.HEIGHT(H),.UI_SCALE(3)) dut(
        .clk(clk),.rst_n(rst),.in_hs(1'b0),.in_vs(vs),.in_de(de),.in_rgb(rgb),
        .out_hs(oh),.out_vs(ov),.out_de(od),.out_rgb(out),.phase(phase));
    task pixel(input integer x,input integer y,input bit d,input bit v);
        integer ux,uy,addr;reg [7:0] g;reg [23:0] expected;
        begin
            @(negedge clk);de=d;vs=v;g=(x+y)%256;rgb={g,g,g};
            @(posedge clk);#1;
            if({oh,ov,od}!={1'b0,prev_vs,prev_de})$fatal(1,"RGB/control prefetch alignment");
            if(prev_de)begin
                ux=prev_x/3;uy=prev_y/3;checks++;
                if(mode==1)$fwrite(file,"%c%c%c",out[23:16],out[15:8],out[7:0]);
                if(ux>=16&&ux<144&&uy>=80&&uy<176)begin
                    addr=((uy-80)/4)*32+(ux-16)/4;
                    if(mode==1||mode==4||mode==5)expected={dut.thermal[addr],8'h20,~dut.thermal[addr]};
                    else expected=((ux/4+uy/4)%2)?24'h606060:24'h303030;
                    if(out!==expected)$fatal(1,"synchronous heat prefetch mode=%d x=%d y=%d got=%h expected=%h",mode,prev_x,prev_y,out,expected);
                end
                if(ux==22&&uy==20)begin
                    expected=mode==0?24'h606060:mode==2?24'hffaa00:mode==3?24'hff3000:24'h00cc80;
                    if(out!==expected)$fatal(1,"scaled IR status");
                end
                if(ux==54&&uy==20)begin
                    expected=mode==0?24'h606060:(mode==2||mode==5)?24'hffaa00:mode==3?24'hff3000:24'h00cc80;
                    if(out!==expected)$fatal(1,"scaled AI state");
                end
                if(ux==100&&uy==40&&out!==((mode==1||mode==4)?24'h00aaff:24'h303030))$fatal(1,"score gate");
                if(prev_x==0&&prev_y==0&&out!==(mode==4?24'hff0000:prev_rgb))$fatal(1,"test alarm border");
                if(ux==320&&uy==56&&dut.display.display.textline!=="A DISPLAY TEST  ")$fatal(1,"visible TEST label");
                if(prev_x==800&&prev_y==550&&out!==prev_rgb)$fatal(1,"video fixture must remain underneath");
            end
            prev_de=d;prev_vs=v;prev_x=x;prev_y=y;prev_rgb=rgb;
        end
    endtask
    initial begin
        repeat(5)@(negedge clk);rst=1;
        for(mode=0;mode<6;mode++)begin
            @(negedge clk);dut.phase=mode;
            pixel(0,0,0,1);pixel(0,0,0,0);pixel(0,0,0,0);
            if(mode==1)begin file=$fopen("a_display_scaled_VALID_SYNTHETIC.ppm","wb");$fwrite(file,"P6\n1280 600\n255\n");end
            for(integer y=0;y<H;y++)begin
                for(integer x=0;x<W;x++)pixel(x,y,1,0);
                pixel(0,y,0,0);pixel(0,y,0,0);
            end
            pixel(0,0,0,0);
            if(mode==1)$fclose(file);
        end
        $display("PASS tb_a_hdmi_display_exercise six states, scaled OSD, sync RAM prefetch, %0d pixels",checks);$finish;
    end
    initial begin #60000000;$fatal(1,"timeout");end
endmodule
