"""Finite real dual-sensor diagnostic, opt-in; no Flash or buzzer ON operation."""
import argparse
from collections import Counter
import ctypes as C
from dataclasses import asdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parents[1]
sys.path.insert(0,str(BASE/'standalone_sensor_fast/host'))
from fast_bridge import FastBridge, BoardError
from d2xx_transport import D2xxTransport
from thermal_scheduler import CaptureError, FrameReader, PairAssembler, age, refresh_control
from thermal_calculate import Calculator, assess_plausibility, write_u16

class Environment(C.Structure):
    _fields_=[(k,C.c_uint32) for k in ('abi_version','sample_id','timestamp_ms','valid_flags','error_bits')]+[('temperature_centi_c',C.c_int32),('humidity_centi_percent',C.c_uint32)]
CLOCK=C.CFUNCTYPE(C.c_uint32)
BUS=C.CFUNCTYPE(C.c_int,C.c_uint8,C.POINTER(C.c_uint8),C.c_uint32,C.POINTER(C.c_uint8),C.c_uint32,C.c_uint32)

def save(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def crc8(data):
    crc=255
    for b in data:
        crc^=b
        for _ in range(8):crc=((crc<<1)^0x31 if crc&128 else crc<<1)&255
    return crc

class Sensor:
    """Unmodified team C driver; time callback reads the real FPGA ms counter."""
    def __init__(self,bridge):
        self.bridge=bridge
        self.callback_error=None
        self.transactions=[]
        self.dll=C.CDLL(str(ROOT/'sht_adapter.dll'))
        self.clock=CLOCK(self.now)
        self.bus=BUS(self.transfer)
        self.dll.follow_bind.argtypes=[CLOCK,BUS]
        self.dll.follow_get.argtypes=[C.POINTER(Environment)]
        if self.dll.follow_environment_size()!=C.sizeof(Environment):raise ValueError('C ABI size mismatch')
        if self.dll.follow_bind(self.clock,self.bus):raise ValueError('C driver binding failed')

    def now(self):
        try:
            self.bridge.command(3,budget_ms=200)
        except Exception as exc:
            self.callback_error=repr(exc)
        # Callback exceptions cannot propagate through ctypes. The caller rejects
        # this whole cycle if callback_error was set; no sample is accepted then.
        return self.bridge.last_ms or 0

    def transfer(self,addr,tx,nt,rx,nr,budget):
        begin=time.monotonic();raw=bytes(tx[:nt]);data=b'';error=None;rc=0
        try:
            data=self.bridge.command(1,addr,raw,nr,budget_ms=budget)
            if nr:C.memmove(rx,data,nr)
        except Exception as exc:
            error=repr(exc)
            rc=-6 if str(exc)=='BOARD_STATUS_1' else -5 if isinstance(exc,TimeoutError) or str(exc)=='BOARD_STATUS_2' else -7
        self.transactions.append(dict(address7=addr,tx_hex=raw.hex(),rx_hex=data.hex(),rc=rc,error=error,board_ms=self.bridge.last_ms,host_duration_ms=(time.monotonic()-begin)*1000,budget_ms=budget))
        return rc

    def sample(self):
        self.transactions=[];self.callback_error=None
        rc=self.dll.follow_start()
        deadline=time.monotonic()+.25
        if rc==0:
            while True:
                if time.monotonic()>=deadline:raise TimeoutError('host bound on C poll loop')
                time.sleep(.002)
                rc=self.dll.follow_poll()
                if self.callback_error:rc=-7;break
                if rc!=-2:break
        env=Environment();get_rc=self.dll.follow_get(C.byref(env))
        reads=[t for t in self.transactions if not t['tx_hex'] and len(t['rx_hex'])==12 and t['rc']==0]
        raw=bytes.fromhex(reads[-1]['rx_hex']) if reads else b''
        crc_ok=len(raw)==6 and crc8(raw[:2])==raw[2] and crc8(raw[3:5])==raw[5]
        conversion_ok=crc_ok and env.temperature_centi_c==-4500+(17500*int.from_bytes(raw[:2],'big')+32767)//65535 and env.humidity_centi_percent==(10000*int.from_bytes(raw[3:5],'big')+32767)//65535
        item=dict(rc=rc,get_rc=get_rc,callback_error=self.callback_error,raw_hex=raw.hex(),crc_ok=crc_ok,conversion_ok=conversion_ok,attempts=self.dll.follow_attempts(),transactions=self.transactions,**{k:getattr(env,k) for k,_ in env._fields_})
        item['valid']=rc==get_rc==0 and env.valid_flags==7 and env.error_bits==0 and conversion_ok and self.callback_error is None
        if self.callback_error:item['valid']=False
        return item

def run(bridge,out,seconds,reopen=None,clock=time.perf_counter):
    report=dict(scope='REAL_DUAL_SENSOR_STANDALONE_SOAK',requested_seconds=seconds,clock_scope='same BQFAST01 FPGA observation counter for both sensors; not final C3 shared clock',wrote_flash=False,buzzer_on_commands_sent=0,physical_buzzer_disconnected=True,final_soc_acceptance=False,physical_disconnect_tested=False,cold_boot_silence_verified=False)
    pairs=[];envs=[];rejects=Counter();recoveries=[];original=None;changed=False
    start=clock();next_env=start;progress=start;count=0;warmup=0
    try:
        report['identity']=bridge.identify().decode()
        report['idle_status_start']=bridge.command(3,budget_ms=200)[0]
        report['board_start_ms']=bridge.last_ms
        if report['idle_status_start']!=3:raise BoardError('bus not released/high before soak')
        ee=bridge.read_words(0x2400,832);write_u16(out/'eeprom_u16_be.bin',ee)
        original=bridge.read_words(0x800d,1)[0]
        desired=refresh_control(original,3)
        changed=desired!=original
        report.update(original_control=original,requested_control=desired)
        if changed:bridge.write_word(0x800d,desired)
        if bridge.read_words(0x800d,1)[0]!=desired:raise BoardError('control readback mismatch')
        bridge.write_word(0x8000,0x0030)
        sensor=Sensor(bridge);reader=FrameReader(bridge,clock=time.perf_counter);assembler=PairAssembler(500)
        def recover(reason):
            if reopen is None or len(recoveries)>=10:
                raise BoardError('finite recovery limit reached or reopening unavailable')
            item=dict(reason=repr(reason),board_ms_before=bridge.last_ms,status='ATTEMPTED')
            recoveries.append(item)
            try:
                reopen(bridge)
                item['idle_after']=bridge.command(3,budget_ms=200)[0]
                if item['idle_after']!=3:raise BoardError('bus remains low after exact-channel reopen')
                if bridge.read_words(0x800d,1)[0]!=desired:raise BoardError('MLX configuration changed during recovery')
                item.update(status='RECOVERED_WITHOUT_SRAM_RELOAD',board_ms_after=bridge.last_ms)
            except Exception as exc:
                item.update(status='FAILED',error=repr(exc));raise
            finally:save(out/'transport_recoveries.json',recoveries)
            assembler.reset()
            return Sensor(bridge)
        with (out/'environment_cycles.jsonl').open('w',encoding='utf-8') as envlog, (out/'pair_events.jsonl').open('w',encoding='utf-8') as events:
            while clock()-start<seconds and count<2000:
                if assembler.pending is None and clock()>=next_env:
                    item=sensor.sample();envs.append(item)
                    envlog.write(json.dumps(item)+'\n');envlog.flush()
                    next_env=clock()+1
                    if bridge.failed:
                        sensor=recover('transport failed during retained SHT cycle')
                        continue
                try:frame=reader.capture(budget_ms=min(1200,max(1,(seconds-(clock()-start))*1000)))
                except (CaptureError,TimeoutError) as exc:
                    assembler.reset();rejects[str(exc)]+=1
                    events.write(json.dumps(dict(type='CAPTURE_REJECTED',error=repr(exc),board_ms=bridge.last_ms))+'\n');events.flush()
                    if bridge.failed:sensor=recover(exc)
                    continue
                name=f'subpage_{count:04d}';write_u16(out/(name+'_u16_be.bin'),frame.words)
                detail=asdict(frame);del detail['words']
                detail.update(page=frame.page,control=frame.control,raw_file=name+'_u16_be.bin',warmup=warmup<4)
                save(out/(name+'.json'),detail);count+=1
                if warmup<4:warmup+=1;assembler.reset();continue
                event=assembler.push(frame)
                if event['status']=='PAIRED_FOR_DIAGNOSTIC_ANALYSIS':
                    frames=event.pop('frames')
                    event['pair_id']=len(pairs)
                    event['subpage_files']=[f'subpage_{count-2:04d}_u16_be.bin',name+'_u16_be.bin']
                    event['environment_sample_id']=envs[-1]['sample_id'] if envs and envs[-1]['valid'] else None
                    event['environment_age_ms']=age(frame.checked_completed_ms,envs[-1]['timestamp_ms']) if envs and envs[-1]['valid'] else None
                    save(out/f'pair_{len(pairs):04d}.json',event)
                    pairs.append((frames,event))
                elif event['status']!='WAITING_FOR_OTHER_SUBPAGE':rejects[event['status']]+=1
                events.write(json.dumps(event)+'\n');events.flush()
                if clock()-progress>=15:
                    print(json.dumps(dict(elapsed_s=round(clock()-start,1),pairs=len(pairs),sht_valid=sum(e['valid'] for e in envs),sht_failed=sum(not e['valid'] for e in envs),rejections=dict(rejects))),flush=True)
                    progress=clock()
        report['idle_status_end']=bridge.command(3,budget_ms=200)[0]
        report['board_end_ms']=bridge.last_ms
        report['status']='SOAK_ACQUIRED' if clock()-start>=seconds and report['idle_status_end']==3 else 'INCOMPLETE'
    except Exception as exc:
        report.update(status='ERROR',error=repr(exc))
    finally:
        report['host_acquisition_s']=clock()-start
        report['control_restore']='NOT_NEEDED'
        if changed:
            report['control_restore']='UNCONFIRMED_TRANSPORT_FAILED' if bridge.failed else 'REQUIRED'
            if not bridge.failed:
                try:
                    bridge.write_word(0x800d,original)
                    report['restored_control']=bridge.read_words(0x800d,1)[0]
                    report['control_restore']='VERIFIED' if report['restored_control']==original else 'MISMATCH'
                except Exception as exc:report.update(control_restore='FAILED',restore_error=repr(exc))
        report.update(subpages_saved=count,warmup_subpages_excluded=warmup,pairs=len(pairs),sht_cycles=len(envs),sht_valid=sum(e['valid'] for e in envs),sht_failed=sum(not e['valid'] for e in envs),rejections=dict(rejects),transport_recoveries=recoveries)
        save(out/'acquisition_summary.json',report)
    return report,pairs,envs

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run-hardware',action='store_true');p.add_argument('--seconds',type=float,default=300)
    p.add_argument('--port');p.add_argument('--ftdi-serial')
    args=p.parse_args(argv)
    if not args.run_hardware:
        print(json.dumps(dict(status='OFFLINE_PLAN_ONLY',hardware_accessed=False)));return 0
    if not args.port or not args.ftdi_serial or not 5<=args.seconds<=600:p.error('explicit UART mapping and 5..600 finite seconds required')
    calc=Calculator()
    out=BASE/'logs'/datetime.now().strftime('dual_soak_%Y%m%d_%H%M%S_%f');out.mkdir()
    print('OUTPUT '+str(out),flush=True)
    with (out/'uart_transactions.jsonl').open('w',encoding='utf-8') as log:
        bridge=FastBridge(D2xxTransport.open(args.ftdi_serial,args.port),log,clock=time.perf_counter)
        def reopen(b):
            b.transport.close()
            b.transport=D2xxTransport.open(args.ftdi_serial,args.port)
            b.failed=False
            # Keep sequence and previous board timestamp, rejecting counter resets.
            b.identify()
        try:report,pairs,envs=run(bridge,out,args.seconds,reopen=reopen)
        finally:bridge.close()
    report.update(port=args.port,ftdi_serial=args.ftdi_serial,hardware_accessed=True)
    plausible=0;calculation_errors=[]
    ee=list(__import__('struct').unpack('>832H',(out/'eeprom_u16_be.bin').read_bytes())) if pairs else []
    for i,(frames,event) in enumerate(pairs):
        try:
            temp=calc.pair(ee,[f.words for f in frames]);temp['plausibility']=assess_plausibility(temp)
            if temp['plausibility']['status']=='PLAUSIBILITY_CHECK_PASSED':plausible+=1
            save(out/f'temperature_{i:04d}.json',temp)
        except Exception as exc:calculation_errors.append(dict(pair=i,error=repr(exc)))
    ages=[e['observed_age_ms'] for _,e in pairs]
    valid_envs=[e for e in envs if e['valid']]
    report.update(plausible_pairs=plausible,calculation_errors=calculation_errors,observed_pair_age_ms=dict(min=min(ages),max=max(ages),mean=statistics.mean(ages)) if ages else None)
    for key in ('temperature_centi_c','humidity_centi_percent'):
        values=[e[key] for e in valid_envs]
        report[key]=dict(min=min(values),max=max(values),mean=statistics.mean(values)) if values else None
    good=report['status']=='SOAK_ACQUIRED' and report['pairs']>=max(10,args.seconds*.9) and report['sht_valid']>=max(3,args.seconds/3) and report['sht_failed']==0 and plausible==len(pairs) and not report['transport_recoveries'] and report['control_restore'] in ('VERIFIED','NOT_NEEDED')
    report['result']='PASS_STANDALONE_DUAL_SENSOR_SOAK' if good else 'NOT_PASSED'
    report['full_requested_duration_completed']=report['status']=='SOAK_ACQUIRED'
    if report['full_requested_duration_completed'] and report['transport_recoveries']:
        report['result']='COMPLETED_WITH_RECORDED_RECOVERED_TRANSPORT_ERRORS'
    report['files_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.iterdir()) if f.is_file() and f.name!='summary.json'}
    save(out/'summary.json',report)
    print(json.dumps(dict(output=str(out),**{k:v for k,v in report.items() if k!='files_sha256'}),indent=2),flush=True)
    return 0 if good else 1

if __name__=='__main__':raise SystemExit(main())
