#include "b4_publish_gate.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); return 1; } } while (0)

static coop_environment_t env(uint32_t ts, int32_t t, uint32_t h) {
    coop_environment_t s; memset(&s, 0, sizeof(s));
    s.abi_version = COOP_ABI_VERSION; s.timestamp_ms = ts;
    s.temperature_centi_c = t; s.humidity_centi_percent = h;
    s.valid_flags = COOP_SAMPLE_VALID; return s;
}

static void thermal_full(coop_thermal_t *s) {
    unsigned i; memset(s, 0, sizeof(*s));
    s->abi_version = COOP_ABI_VERSION; s->valid_flags = COOP_SAMPLE_COMPLETE | COOP_SAMPLE_CONVERTED;
    s->timestamp_ms = 1000;
    for (i = 0; i < 768; ++i) {
        s->temperature_centi_c[i] = 2537;
        s->pixel_valid_bits[i / 8u] |= (uint8_t)(1u << (i % 8u));
    }
}

int main(void) {
    b4_publish_config_t c; b4_publish_state_t st; coop_environment_t e, out; coop_thermal_t th, th_out; uint16_t n; uint32_t r;
    b4_publish_config_default(&c); b4_publish_reset(&st);
    e = env(1000, 2275, 6910);
    CHECK(b4_publish_environment(&st, &e, 1100, &c, &out, &r) == COOP_OK && out.timestamp_ms == 1000 && r == 0);
    e = env(2000, 9000, 6910);
    CHECK(b4_publish_environment(&st, &e, 2100, &c, &out, &r) == COOP_ESTATE && (r & B4_GATE_REASON_QUALITY_MASK));
    e = env(2000, 2280, 6920);
    CHECK(b4_publish_environment(&st, &e, 2100, &c, &out, &r) == COOP_OK && out.temperature_centi_c == 2280);
    e = env(2000, 2281, 6921);
    CHECK(b4_publish_environment(&st, &e, 2200, 0, &out, &r) == COOP_EINVAL); /* invalid config pointer */
    e = env(3000, 2282, 6922);
    CHECK(b4_publish_environment(&st, &e, 5201, &c, &out, &r) == COOP_ETIMEOUT && (r >> 16) & B4_TEMPORAL_REASON_TOO_OLD);
    thermal_full(&th);
    CHECK(b4_publish_thermal(&th, 1100, &c, &th_out, &n, &r) == COOP_OK && n == 768);
    th.pixel_valid_bits[620 / 8u] &= (uint8_t)~(1u << (620 % 8u)); th.error_bits = COOP_ERROR_PIXEL_QUALITY;
    CHECK(b4_publish_thermal(&th, 1100, &c, &th_out, &n, &r) == COOP_OK && n == 767 && th_out.error_bits == COOP_ERROR_PIXEL_QUALITY);
    th.timestamp_ms = 1000;
    CHECK(b4_publish_thermal(&th, 2001, &c, &th_out, &n, &r) == COOP_ETIMEOUT && ((r >> 16) & B4_TEMPORAL_REASON_TOO_OLD));
    memset(th.pixel_valid_bits, 0, sizeof(th.pixel_valid_bits));
    CHECK(b4_publish_thermal(&th, 1100, &c, &th_out, &n, &r) == COOP_ESTATE && (r & B4_GATE_REASON_QUALITY_MASK));
    printf("PASS B4 publish gate: %u assertions; synthetic fixtures only\n", checks);
    return 0;
}

