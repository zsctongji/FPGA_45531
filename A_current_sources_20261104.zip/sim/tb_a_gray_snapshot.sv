`timescale 1ns/1ps
module tb_a_gray_snapshot;
    reg pc=0,rc=0;always #5 pc=~pc;always #7 rc=~rc;
    reg rst=0,vs=0,de=0,request=0;
    reg [7:0] gray=0;reg [15:0] addr=0;
    wire done;wire [7:0] data,flags;
    wire [31:0] fid,stamp,sum,changed,diff;
    wire [15:0] x0,y0,x1,y1;
    a_gray_snapshot #(.PIX_HZ(100000),.WIDTH(8),.HEIGHT(4),.STEP(2)) dut(
        .pixel_clk(pc),.read_clk(rc),.rst_n(rst),.in_vs(vs),.in_de(de),.in_gray(gray),
        .request_toggle(request),.read_address(addr),.read_data(data),.done_toggle(done),
        .frame_id(fid),.timestamp_ms(stamp),.checksum(sum),.changed_count(changed),.difference_sum(diff),
        .min_x(x0),.min_y(y0),.max_x(x1),.max_y(y1),.flags(flags));
    task boundary;begin @(negedge pc);vs=1;de=0;repeat(6)@(negedge pc);vs=0;end endtask
    task frame(input integer value);begin
        for(integer y=0;y<4;y++)begin
            for(integer x=0;x<8;x++)begin @(negedge pc);de=1;gray=value;end
            @(negedge pc);de=0;repeat(2)@(negedge pc);
        end
        boundary();
    end endtask
    task check(input integer value);begin
        for(integer i=0;i<16;i++)begin
            @(negedge rc);addr=i;@(posedge rc);#1;
            if(data!==(i>=4&&i<12?value:0))$fatal(1,"owned RAM / padding %d %d",i,data);
        end
    end endtask
    initial begin
        repeat(5)@(negedge pc);rst=1;boundary();request=1;repeat(5)@(negedge pc);frame(10);
        wait(done==1);if(sum!=80||flags!=1||fid!=0)$fatal(1,"baseline metadata");check(10);
        frame(90);check(10); // continuous video must not overwrite leased image
        request=0;repeat(6)@(negedge pc);frame(150);wait(done==0);
        if(sum!=1200||changed!=8||diff!=480||flags!=11||x0!=0||x1!=3||y0!=0||y1!=1||fid!=2)
            $fatal(1,"same-frame motion or request reuse %d %d %d %d %d",sum,changed,diff,flags,fid);
        check(150);
        $display("PASS tb_a_gray_snapshot dual-clock ownership, frozen image, padding, same-frame motion");$finish;
    end
    initial begin #100000;$fatal(1,"timeout");end
endmodule
