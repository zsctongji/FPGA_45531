"""SRAM stream using a single native D2XX bit-sequence type; checks USER_MODE."""
import sys,json,time,hashlib
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
EFX=Path(r'D:\Ti60B\tools\efinity\2026.1')
sys.path[:0]=[str(EFX/'pgm'/'bin'),str(EFX/'debugger'/'bin')]
from efx_pgm.hiftdi.jtag import JtagEngine
from efx_pgm.hiftdi.bits import BitSequence
from efx_pgm.prog_detector import TiProgStateDetector
from efx_pgm.device_utils import DeviceUtils
artifact=ROOT/'logs'/'vendor_original_led.hex'
frequency=float(sys.argv[1]) if len(sys.argv)>1 else 1000000
j=JtagEngine(trst=False,frequency=frequency)
r={'at':datetime.now().astimezone().isoformat(),'artifact':str(artifact),'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'wrote_flash':False,'frequency':frequency,'path':'native_d2xx_lsb_bytes'}
def instruction(n):j.write_ir(BitSequence(n,length=5))
def status():
 instruction(12);v=j.read_dr(32);d=TiProgStateDetector(DeviceUtils().get_info_by_idcode(0x10660a79));b=repr(v)[::-1];return {'state':d.decode_prog_state(b),'registers':d.get_register_values(b),'raw':hex(int(v))}
try:
 j.configure('hiftdi://0x0403:0x6011/1');j.reset();code=int(j.read_dr(32));r['idcode']=hex(code)
 if code!=0x10660a79:raise RuntimeError('Unexpected ID')
 instruction(4);j.go_idle();j.sync();time.sleep(.02);j.reset();instruction(4);j.go_idle();j.sync();time.sleep(.02)
 j.change_state('shift_dr')
 data=bytes(20)+bytes(int(line[:2],16) for line in artifact.read_text().splitlines())+bytes(512)
 for i in range(0,len(data),256):
  part=data[i:i+256];bits=BitSequence(bytes_=part)
  j.write(bits,use_last=False);j.sync()
 j.sync();time.sleep(.2)
 instruction(7);j.write_dr(BitSequence(0,length=100));j.go_idle();j.sync();time.sleep(.3)
 r['configuration']=status()
except Exception as e:r['error']=repr(e)
finally:j.reset();j.close()
(ROOT/'logs'/('native_sram_lsb_'+str(int(frequency))+'.json')).write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
