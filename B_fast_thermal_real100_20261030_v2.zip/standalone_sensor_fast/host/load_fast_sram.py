"""Verify the exact fast diagnostic image; program SRAM only with --run-hardware."""
import argparse
import contextlib
from datetime import datetime
import hashlib
import io
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
EXPECTED_BIT_SHA256="3319b345db801c420d0e3df40b92b8b55fc7f61ed70e40f0ba9bcdb15f4ba077"
EXPECTED_PINS={"B3":("sensor_scl","Bidirectional"),"C3":("sensor_sda","Bidirectional"),
               "B5":("buzzer_sig","Output"),"R4":("uart_rx","Input"),"R14":("uart_tx","Output")}


def preflight(root=ROOT):
    import csv
    root=Path(root)
    bit=root/"outflow/B_sensor_fast.bit"
    actual=hashlib.sha256(bit.read_bytes()).hexdigest()
    if actual!=EXPECTED_BIT_SHA256:raise RuntimeError("bitstream hash mismatch; not programming")
    evidence=json.loads((root/"logs/build_evidence.json").read_text(encoding="utf-8"))
    if evidence["status"]!="OFFLINE_BUILD_VERIFIED":raise RuntimeError("build not verified")
    for relative,expected in evidence["files_sha256"].items():
        if hashlib.sha256((root/relative).read_bytes()).hexdigest()!=expected:
            raise RuntimeError("build evidence changed: "+relative)
    pinfile=root/"outflow/B_sensor_fast.pinout.csv"
    rows=list(csv.DictReader(line for line in pinfile.read_text().splitlines() if line and not line.startswith("#")))
    for pin,(signal,direction) in EXPECTED_PINS.items():
        matching=[r for r in rows if r["Pin Number"]==pin]
        if len(matching)!=1 or matching[0]["Signal Name"]!=signal or matching[0]["Direction"]!=direction:
            raise RuntimeError("pinout mismatch: "+pin)
        if matching[0]["I/O Bank Voltage"]!="3.3 V":raise RuntimeError("unexpected bank voltage: "+pin)
    top=(root/"src/B_sensor_fast.v").read_text(encoding="utf-8")
    if "assign buzzer_sig=1'b0;" not in top:raise RuntimeError("constant-LOW buzzer check failed")
    return {"status":"OFFLINE_IMAGE_VERIFIED","hardware_accessed":False,"bitstream":str(bit),
            "sha256":actual,"pins":EXPECTED_PINS,"identity_required":"BQFAST01", "wrote_flash":False}


def program(port,report):
    # Efinity modules and USB/serial libraries are imported only after explicit opt-in.
    efinity=Path(r"D:/Ti60B/tools/efinity/2026.1")
    sys.path[:0]=[str(efinity/"pgm/bin"),str(efinity/"debugger/bin"),str(efinity/"debugger/svf_player/bin")]
    from efx_pgm.efx_hw_common.manager import EfxFTDIHwConnectionManager
    from efx_dbg.jcf import JtagChainEngine
    from efx_pgm.ftdi_program import FtdiProgram
    from efx_pgm.efx_hw_common.boards import PinoutProfile
    from efx_pgm.device_utils import DeviceUtils
    from efx_pgm.prog_detector import TiProgStateDetector
    from pyftdi.ftdi import Ftdi
    from serial.tools import list_ports
    from fast_bridge import FastBridge
    engine=None
    log=io.StringIO()
    try:
        ports=[p for p in list_ports.comports() if p.device.upper()==port.upper()]
        if len(ports)!=1 or ports[0].vid!=0x0403 or ports[0].pid!=0x6011:
            raise RuntimeError("confirmed port is not a single FT4232 UART")
        report["port_info"]={k:getattr(ports[0],k,None) for k in ("device","serial_number","description","location","vid","pid")}
        devices=Ftdi.list_devices("ftdi://0x0403:0x6011/?")
        if len(devices)!=1:raise RuntimeError("need exactly one FT4232 target; no programming performed")
        device,interfaces=devices[0]
        if interfaces!=4:raise RuntimeError("unexpected interface count")
        jtag_url=f"ftdi://0x0403:0x6011:{device.bus:x}:{device.address:x}/2"
        auxiliary_url="hiftdi://0x0403:0x6011/0"
        report["jtag_url"]=jtag_url
        report["hardware_accessed"]=True
        provider=EfxFTDIHwConnectionManager.get_controller(jtag_url,EfxFTDIHwConnectionManager.ConnectionType.JTAG,frequency=1000000)
        engine=JtagChainEngine(engine_provider=provider,tap="efx_ti")
        engine.configure(jtag_url);engine.reset()
        code=int(engine.read_dr(32));report["idcode"]=f"0x{code:08X}"
        if code!=0x10660A79:raise RuntimeError("unexpected FPGA IDCODE; not programming")
        pins=PinoutProfile();pins.JTAG_SET="FTDI_ADBUS7"
        args=SimpleNamespace(input_file=report["bitstream"],output_file=None,mode="jtag",urls=[auxiliary_url,jtag_url,None,None],num=1,pinout=pins)
        programmer=FtdiProgram(args,jtag_program_freq=1000000)
        programmer.creset_before_jtag_config=True
        report["programming_attempted"]=True
        with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
            programmer._jtag_program(engine)
        engine.configure(jtag_url);engine.reset()
        code=int(engine.read_dr(32))
        detector=TiProgStateDetector(DeviceUtils().get_info_by_idcode(code))
        samples=[]
        for _ in range(3):
            bits=detector.read_bsr(engine)
            samples.append(detector.decode_prog_state(bits));time.sleep(.05)
        report["configuration_samples"]=samples
        if any(sample!="USER_MODE" for sample in samples):raise RuntimeError("SRAM did not enter USER_MODE")
        engine.reset();engine.close();engine=None
        bridge=FastBridge.open(port,log)
        try:
            report["identity"]=bridge.identify().decode("ascii")
            report["status_bytes"]=[bridge.command(3,budget_ms=200)[0] for _ in range(3)]
            if any(value&4 for value in report["status_bytes"]):raise RuntimeError("buzzer logic high")
        finally:bridge.close()
        report["status"]="FAST_SRAM_IDENTITY_AND_LOGIC_LOW_VERIFIED"
    finally:
        if engine:
            try:engine.reset();engine.close()
            except Exception as exc:report["cleanup_error"]=repr(exc)
        report["programmer_and_uart_log"]=log.getvalue()


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-hardware",action="store_true")
    parser.add_argument("--port",help="confirmed single FT4232 UART; never tries other ports")
    args=parser.parse_args(argv)
    if args.run_hardware and not args.port:parser.error("--run-hardware requires --port")
    report=preflight()
    if not args.run_hardware:
        print(json.dumps(report,indent=2));return 0
    report.update(at=datetime.now().astimezone().isoformat(),operation="SRAM_ONLY",
                  buzzer_on_commands_sent=0,cold_boot_silence_verified=False,
                  physical_sound_verified=False,programming_attempted=False)
    try:program(args.port,report)
    except Exception as exc:report.update(status="ERROR",error=repr(exc))
    path=ROOT/"logs"/datetime.now().strftime("sram_load_%Y%m%d_%H%M%S_%f.json")
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"record":str(path),**report},ensure_ascii=False,indent=2))
    return 0 if report["status"]=="FAST_SRAM_IDENTITY_AND_LOGIC_LOW_VERIFIED" else 1


if __name__=="__main__":raise SystemExit(main())
