"""Audit saved real-board logs; no hardware access and no new measurements."""
import ctypes as C, hashlib, json, math, statistics, struct
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
S=BASE/'standalone_sensor/logs/sht30_real_20261029_041037'
M=BASE/'standalone_sensor/logs/mlx90640_real_20261029_042917'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def crc8(raw):
 c=255
 for b in raw:
  c^=b
  for _ in range(8):c=((c<<1)^0x31)&255 if c&128 else (c<<1)&255
 return c
report={'audit_date':'2026-10-30','scope':'OFFLINE_AUDIT_OF_SAVED_REAL_BOARD_LOGS','new_board_measurements':0,'hardware_access':False,'sources':{},'checks':[]}
def check(name,ok,detail=''):
 report['checks'].append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok:raise RuntimeError(name+': '+str(detail))
rows=[json.loads(x) for x in (S/'sht30_cycles.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
raw_uart=[json.loads(x) for x in (S/'uart_transactions.jsonl').read_text().splitlines() if x.strip()]
valid=[r for r in rows if r['valid']]
check('SHT30 cycle/sample counts',len(rows)==104 and len(valid)==100)
check('SHT30 sample ids unique',len({r['sample_id'] for r in rows})==len(rows))
for r in valid:
 raw=bytes.fromhex(r['raw_hex'])
 check('SHT CRC and conversion sample '+str(r['sample_id']),len(raw)==6 and crc8(raw[:2])==raw[2] and crc8(raw[3:5])==raw[5] and -4500+(17500*int.from_bytes(raw[:2],'big')+32767)//65535==round(r['temperature_c']*100) and (10000*int.from_bytes(raw[3:5],'big')+32767)//65535==round(r['humidity_percent']*100))
 candidates=[t for t in raw_uart if t.get('status')==0 and t.get('board_ms')==r['board_timestamp_ms']]
 check('SHT raw UART cross-check sample '+str(r['sample_id']),any(bytes.fromhex(t['response_hex'])[9:-1]==raw for t in candidates))
check('SHT forward board timestamps',all(0<(valid[i]['board_timestamp_ms']-valid[i-1]['board_timestamp_ms'])&0xffffffff<0x80000000 for i in range(1,len(valid))))
summary=json.loads((S/'summary.json').read_text())
check('SHT saved SHA256',all(sha(S/name)==digest for name,digest in summary['sha256'].items()))
report['sht30']={'status':'CONFIRMED_100_REAL_VALID_SAMPLES','cycles':len(rows),'valid_samples':len(valid),'failed_cycles':len(rows)-len(valid),'failed_cycle_rcs':[r['rc'] for r in rows if not r['valid']],'crc_errors_in_valid_samples':0,'timestamp_source':'FPGA board_ms; host driver timestamps also stored','temperature_c':{'min':min(r['temperature_c'] for r in valid),'max':max(r['temperature_c'] for r in valid),'mean':statistics.mean(r['temperature_c'] for r in valid)},'humidity_percent':{'min':min(r['humidity_percent'] for r in valid),'max':max(r['humidity_percent'] for r in valid),'mean':statistics.mean(r['humidity_percent'] for r in valid)}}
U16=C.c_uint16;F=C.c_float;U8=C.c_uint8
ee=(U16*832)(*struct.unpack('>832H',(M/'eeprom_u16_be.bin').read_bytes()))
f0=(U16*834)(*struct.unpack('>834H',(M/'frame0_u16_be.bin').read_bytes()));f1=(U16*834)(*struct.unpack('>834H',(M/'frame1_u16_be.bin').read_bytes()))
frames=[f0,f1]
check('MLX distinct subpages',set([int(f0[833]),int(f1[833])])=={0,1})
check('MLX matching modes',int(f0[832])==int(f1[832]))
tr=json.loads((M/'transactions.json').read_text())
# Every saved response must match a successful UART transaction with its payload and FPGA timestamp.
wire=[json.loads(x) for x in (M/'uart_transactions.jsonl').read_text().splitlines() if x.strip()]
for t in tr:
 check('MLX UART cross-check '+str(t['board_ms']),t['rc']==0 and any(w.get('status')==0 and w.get('board_ms')==t['board_ms'] and bytes.fromhex(w['response_hex'])[9:-1].hex()==t['rx_hex'] for w in wire))
eeprom=b''.join(bytes.fromhex(t['rx_hex']) for t in tr if t['tx_hex'] and 0x2400<=int(t['tx_hex'],16)<0x2740 and len(t['tx_hex'])==4)
check('MLX EEPROM raw transaction bytes',eeprom==(M/'eeprom_u16_be.bin').read_bytes())
groups=[];g=None
for t in tr:
 if t['tx_hex']=='80000030':
  g={'clear_ms':t['board_ms'],'words':bytearray(),'last_ms':None};groups.append(g)
 elif g is not None and len(t['tx_hex'])==4:
  reg=int(t['tx_hex'],16)
  if 0x400<=reg<=0x73f:g['words'].extend(bytes.fromhex(t['rx_hex']));g['last_ms']=t['board_ms']
  elif reg==0x800d:g['control']=int(t['rx_hex'],16);g['end_ms']=t['board_ms']
check('MLX frame groups',len(groups)==2)
for i,g in enumerate(groups):
 check('MLX RAM bytes match saved frame '+str(i),bytes(g['words'])==(M/('frame%d_u16_be.bin'%i)).read_bytes()[:1664])
 check('MLX control matches saved frame '+str(i),g['control']==frames[i][832])
dll=C.CDLL(str(ROOT/'recalculate_recorded_mlx.dll'))
fn=dll.audit_calculate;fn.argtypes=[C.POINTER(U16),C.POINTER(U16),C.POINTER(U16),C.POINTER(F),C.POINTER(U8),C.POINTER(U16),C.POINTER(F),C.POINTER(F)];fn.restype=C.c_int
out=(F*1536)();q=(U8*1536)();bad=(U16*10)();ambient=(F*2)();supply=(F*2)()
rc=fn(ee,f0,f1,out,q,bad,ambient,supply);check('MLX EEPROM extraction and official recalculation',rc==0)
combined=[None]*768;reason=['MISSING']*768;origin=[None]*768
for j in range(2):
 for i in range(768):
  quality=q[j*768+i]
  if quality==0:continue
  check('MLX unique subpage ownership '+str(i),origin[i] is None)
  origin[i]=j
  reason[i]='VALID' if quality==1 else 'EEPROM_BAD_PIXEL' if quality==2 else 'NONFINITE'
  if quality==1:combined[i]=float(out[j*768+i])
good=[x for x in combined if x is not None]
bad_indices=[int(x) for x in bad[:5] if x!=0xffff];outliers=[int(x) for x in bad[5:] if x!=0xffff]
check('MLX all positions accounted for',all(x is not None for x in origin))
check('MLX bad pixel excluded',all(combined[i] is None for i in bad_indices+outliers))
quality=[1 if x is not None else 0 for x in combined];bits=bytearray(96)
for i,v in enumerate(quality):
 if v:bits[i//8]|=1<<(i%8)
pair_delta=groups[1]['end_ms']-groups[0]['end_ms']
report['mlx90640']={'status':'RAW_EEPROM_AND_TWO_SUBPAGES_CONFIRMED_QUALITY_WARNING','calibration_rc':rc,'controls':[hex(int(f[832])) for f in frames],'modes':['chess' if f[832]&0x1000 else 'interleaved' for f in frames],'subpages':[int(f[833]) for f in frames],'grid_positions':768,'valid_pixels':len(good),'invalid_pixels':768-len(good),'broken_pixels_zero_based':bad_indices,'outlier_pixels_zero_based':outliers,'nonfinite_pixels':[i for i,r in enumerate(reason) if r=='NONFINITE'],'temperature_c_valid_only':{'min':min(good),'max':max(good),'mean':statistics.mean(good)},'ambient_c':[float(x) for x in ambient],'supply_v_from_sensor':[float(x) for x in supply],'emissivity_assumed':0.95,'reflected_temperature_assumed':'ambient minus 8 C; no independent radiometric calibration performed','subpage_read_duration_ms':[g['end_ms']-g['clear_ms'] for g in groups],'subpage_completion_separation_ms':pair_delta,'team_500ms_age_limit_satisfied_by_completion_separation':pair_delta<=500,'end_to_end_shared_clock_validated':False,'original_summary_is_final_acceptance':False}
(ROOT/'mlx_corrected_grid.json').write_text(json.dumps({'scope':'OFFLINE_RECALCULATION_OF_REAL_RAW_DATA','width':32,'height':24,'temperature_c':combined,'pixel_reason':reason,'pixel_valid_bits_hex':bits.hex()},allow_nan=False,indent=2),encoding='utf-8')
report['corrections']=['Original diagnostic C arrays were not initialized before the library wrote only the active half; old summary counted filtered array contents rather than actual pixel ownership.','Original temperature list discarded indices and omitted mode selection; its 768/768 claim and 0.066 C minimum are superseded.','Original diagnostic ignored the requested 20ms transfer budget and did pair assembly after both captures using host time. Those logs do not validate final real-time deadlines or the shared clock.','Recalculation excludes EEPROM bad pixels and preserves 32x24 positions, nulls and a 96-byte validity mask. This is analysis of saved real measurements, not another board measurement.']
for folder in [S,M]:
 for p in folder.iterdir():
  if p.is_file():report['sources'][str(p)]=sha(p)
report['source_api_sha256']=sha(Path(r'D:/Ti60B/b_delivery/third_party/mlx90640/functions/MLX90640_API.c'))
report['status']='AUDIT_COMPLETE_WITH_MLX_ACCEPTANCE_CORRECTION'
(ROOT/'audit_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['checks','sources']},ensure_ascii=False,indent=2))
