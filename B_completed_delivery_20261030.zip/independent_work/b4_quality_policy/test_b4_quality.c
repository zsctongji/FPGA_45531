#include "b4_quality_policy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); return 1; } } while (0)

static int test_environment(void) {
    b4_quality_policy_t p; coop_environment_t s; uint32_t r;
    b4_quality_policy_default(&p); memset(&s, 0, sizeof(s));
    s.valid_flags = COOP_SAMPLE_VALID; s.temperature_centi_c = 2276; s.humidity_centi_percent = 6911;
    CHECK(b4_quality_environment(&s, &p, &r) == COOP_OK && r == 0);
    s.temperature_centi_c = 9000;
    CHECK(b4_quality_environment(&s, &p, &r) == COOP_ESTATE && (r & B4_QUALITY_REASON_RANGE));
    s.temperature_centi_c = 2276; s.error_bits = COOP_ERROR_CRC;
    CHECK(b4_quality_environment(&s, &p, &r) == COOP_ESTATE && (r & B4_QUALITY_REASON_ERROR));
    s.error_bits = 0; s.valid_flags = COOP_SAMPLE_COMPLETE;
    CHECK(b4_quality_environment(&s, &p, &r) == COOP_ESTATE && (r & B4_QUALITY_REASON_FLAGS));
    return 0;
}

static int test_thermal(void) {
    b4_quality_policy_t p; coop_thermal_t s; uint32_t r; uint16_t n; unsigned i;
    b4_quality_policy_default(&p); memset(&s, 0, sizeof(s));
    s.valid_flags = COOP_SAMPLE_COMPLETE | COOP_SAMPLE_CONVERTED;
    for (i = 0; i < 768; ++i) { s.temperature_centi_c[i] = 2537; s.pixel_valid_bits[i / 8u] |= (uint8_t)(1u << (i % 8u)); }
    CHECK(b4_quality_thermal(&s, &p, &n, &r) == COOP_OK && n == 768 && r == 0);
    s.pixel_valid_bits[620 / 8u] &= (uint8_t)~(1u << (620 % 8u));
    s.error_bits = COOP_ERROR_PIXEL_QUALITY;
    CHECK(b4_quality_thermal(&s, &p, &n, &r) == COOP_OK && n == 767 && (r & B4_QUALITY_REASON_BAD_PIXEL));
    memset(s.pixel_valid_bits, 0, 10);
    CHECK(b4_quality_thermal(&s, &p, &n, &r) == COOP_ESTATE && (r & B4_QUALITY_REASON_TOO_FEW));
    memset(&s, 0, sizeof(s)); s.valid_flags = COOP_SAMPLE_VALID;
    for (i = 0; i < 768; ++i) { s.temperature_centi_c[i] = 2537; s.pixel_valid_bits[i / 8u] |= (uint8_t)(1u << (i % 8u)); }
    s.temperature_centi_c[17] = 31000;
    CHECK(b4_quality_thermal(&s, &p, &n, &r) == COOP_ESTATE && (r & B4_QUALITY_REASON_RANGE));
    return 0;
}

int main(void) {
    CHECK(test_environment() == 0); CHECK(test_thermal() == 0);
    printf("PASS B4 quality policy: %u assertions; synthetic fixtures only\n", checks);
    return 0;
}

