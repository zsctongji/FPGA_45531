module b_i2c_transaction #(
 parameter integer CLK_HZ=50000000, I2C_HZ=100000, TIMEOUT_CYCLES=2500000
)(input wire clk,rst,start,input wire [6:0] address,
 input wire [2:0] tx_count,input wire [6:0] rx_count,input wire [31:0] tx_data,
 input wire scl_in,sda_in,output reg scl_low,sda_low,
 output reg busy,done,output reg [7:0] status,output reg [511:0] rx_data);
localparam integer DIVIDER=CLK_HZ/(I2C_HZ*4);
localparam IDLE=0,START0=1,START1=2,START2=3,SEND_SETUP=4,SEND_RISE=5,SEND_HIGH=6,SEND_FALL=7,
 ACK_SETUP=8,ACK_RISE=9,ACK_SAMPLE=10,ACK_FALL=11,READ_SETUP=12,READ_RISE=13,READ_SAMPLE=14,READ_FALL=15,
 RACK_SETUP=16,RACK_RISE=17,RACK_HIGH=18,RACK_FALL=19,STOP_LOW=20,STOP_RISE=21,STOP_HIGH=22,STOP_RELEASE=23,FINISH=24;
reg [4:0] state=IDLE; reg [15:0] divider=0; reg [31:0] elapsed=0;
reg [7:0] byte_value=0,read_value=0; reg [2:0] bit_index=0,tx_index=0;
reg [6:0] rx_index=0,addr_saved=0,rx_saved=0; reg [2:0] tx_saved=0;
reg [31:0] data_saved=0; reg address_phase=0,read_mode=0;
always @(posedge clk) begin
 done<=0;
 if(rst) begin state<=IDLE;busy<=0;done<=0;status<=0;scl_low<=0;sda_low<=0;divider<=0;elapsed<=0;rx_data<=0;end
 else if(state==IDLE) begin
   busy<=0;scl_low<=0;sda_low<=0;divider<=0;elapsed<=0;
   if(start) begin
     if(tx_count>4 || rx_count>64 || address<7'h08 || address>7'h77 || (tx_count==0 && rx_count==0)) begin status<=3;done<=1;end
     else begin busy<=1;status<=0;rx_data<=0;addr_saved<=address;tx_saved<=tx_count;rx_saved<=rx_count;data_saved<=tx_data;
       tx_index<=0;rx_index<=0;address_phase<=1;read_mode<=(tx_count==0);state<=START0;end
   end
 end else if(elapsed>=TIMEOUT_CYCLES) begin
   state<=IDLE;scl_low<=0;sda_low<=0;busy<=0;done<=1;status<=2;
 end else begin
   elapsed<=elapsed+1;
   if(divider==DIVIDER-1) begin divider<=0;
    case(state)
     START0: begin scl_low<=0;sda_low<=0;if(scl_in && sda_in)state<=START1;end
     START1: begin scl_low<=0;sda_low<=1;state<=START2;end
     START2: begin scl_low<=1;byte_value<={addr_saved,read_mode};bit_index<=7;address_phase<=1;state<=SEND_SETUP;end
     SEND_SETUP: begin scl_low<=1;sda_low<=!byte_value[bit_index];state<=SEND_RISE;end
     SEND_RISE: begin scl_low<=0;if(scl_in)state<=SEND_HIGH;end
     SEND_HIGH: state<=SEND_FALL;
     SEND_FALL: begin scl_low<=1;if(bit_index==0)state<=ACK_SETUP;else begin bit_index<=bit_index-1;state<=SEND_SETUP;end end
     ACK_SETUP: begin sda_low<=0;scl_low<=1;state<=ACK_RISE;end
     ACK_RISE: begin scl_low<=0;if(scl_in)state<=ACK_SAMPLE;end
     ACK_SAMPLE: begin if(sda_in)begin status<=1;state<=STOP_LOW;end else state<=ACK_FALL;end
     ACK_FALL: begin scl_low<=1;
       if(address_phase && read_mode)begin bit_index<=7;read_value<=0;state<=READ_SETUP;end
       else if(address_phase)begin address_phase<=0;byte_value<=data_saved[7:0];bit_index<=7;state<=SEND_SETUP;end
       else if(tx_index+1<tx_saved)begin tx_index<=tx_index+1;byte_value<=data_saved[(tx_index+1)*8 +:8];bit_index<=7;state<=SEND_SETUP;end
       else if(rx_saved!=0)begin read_mode<=1;state<=START0;end
       else state<=STOP_LOW;
     end
     READ_SETUP: begin scl_low<=1;sda_low<=0;state<=READ_RISE;end
     READ_RISE: begin scl_low<=0;if(scl_in)state<=READ_SAMPLE;end
     READ_SAMPLE: begin read_value<={read_value[6:0],sda_in};state<=READ_FALL;end
     READ_FALL: begin scl_low<=1;if(bit_index==0)begin rx_data[rx_index*8 +:8]<=read_value;state<=RACK_SETUP;end
       else begin bit_index<=bit_index-1;state<=READ_SETUP;end end
     RACK_SETUP: begin scl_low<=1;sda_low<=(rx_index+1<rx_saved);state<=RACK_RISE;end
     RACK_RISE: begin scl_low<=0;if(scl_in)state<=RACK_HIGH;end
     RACK_HIGH: state<=RACK_FALL;
     RACK_FALL: begin scl_low<=1;if(rx_index+1<rx_saved)begin rx_index<=rx_index+1;bit_index<=7;read_value<=0;state<=READ_SETUP;end else state<=STOP_LOW;end
     STOP_LOW: begin scl_low<=1;sda_low<=1;state<=STOP_RISE;end
     STOP_RISE: begin scl_low<=0;if(scl_in)state<=STOP_HIGH;end
     STOP_HIGH: state<=STOP_RELEASE;
     STOP_RELEASE: begin scl_low<=0;sda_low<=0;state<=FINISH;end
     FINISH: begin state<=IDLE;busy<=0;done<=1;end
     default: begin state<=IDLE;scl_low<=0;sda_low<=0;busy<=0;done<=1;status<=3;end
    endcase
   end else divider<=divider+1;
 end
end
endmodule
