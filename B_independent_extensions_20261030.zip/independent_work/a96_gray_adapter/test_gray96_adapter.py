import importlib.util
import json
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("gray96_adapter", ROOT / "gray96_adapter.py")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


class GrayAdapterTests(unittest.TestCase):
    def test_zero_padding_and_row_order(self):
        src = bytes((row * 3 + col) & 0xFF for row in range(54) for col in range(96))
        out = module.pad_gray54(src)
        self.assertEqual(len(out), 9216)
        self.assertEqual(out[:21 * 96], b"\x00" * (21 * 96))
        self.assertEqual(out[21 * 96:75 * 96], src)
        self.assertEqual(out[75 * 96:], b"\x00" * (21 * 96))

    def test_all_values_are_preserved(self):
        src = bytes(range(256)) * (module.SOURCE_BYTES // 256) + bytes(range(module.SOURCE_BYTES % 256))
        self.assertEqual(module.pad_gray54(src)[21 * 96:75 * 96], src)

    def test_bad_source_length_rejected(self):
        for size in (0, 1, module.SOURCE_BYTES - 1, module.SOURCE_BYTES + 1):
            with self.subTest(size=size):
                with self.assertRaises(module.FrameError):
                    module.pad_gray54(bytes(size))

    def test_int8_preprocess_is_pixel_minus_128(self):
        gray = bytes((0, 1, 127, 128, 255)) + bytes(9211)
        tensor = module.gray_to_vendor_int8(gray)
        self.assertEqual(tuple(tensor[:5]), (128, 129, 255, 0, 127))

    def test_motion_bbox_maps_only_y(self):
        self.assertEqual(module.map_motion_bbox((0, 0, 95, 53)), (0, 21, 95, 74))
        self.assertIsNone(module.map_motion_bbox(None))

    def test_motion_bbox_rejects_wrong_grid(self):
        for bbox in [(-1, 0, 1, 1), (0, 0, 96, 1), (0, 54, 1, 54), (5, 4, 3, 6)]:
            with self.subTest(bbox=bbox):
                with self.assertRaises(module.FrameError):
                    module.map_motion_bbox(bbox)

    def test_prepare_metadata_and_hashes(self):
        src = bytes((i * 17 + 5) & 0xFF for i in range(module.SOURCE_BYTES))
        frame = module.prepare_frame(src, event_id=7, frame_id=9, capture_ms=0xFFFFFFFF,
                                     motion_bbox_96x54=(2, 3, 10, 20))
        self.assertEqual(frame.policy_id, module.POLICY_ID)
        self.assertEqual(frame.gray_fnv1a, module.fnv1a32(frame.gray8))
        self.assertEqual(frame.gray_sum32, module.sum32(frame.gray8))
        self.assertEqual(frame.metadata()["motion_bbox_96x96"], [2, 24, 10, 41])

    def test_uint32_metadata_bounds(self):
        src = bytes(module.SOURCE_BYTES)
        with self.assertRaises(module.FrameError):
            module.prepare_frame(src, event_id=-1, frame_id=0, capture_ms=0)
        with self.assertRaises(module.FrameError):
            module.prepare_frame(src, event_id=0, frame_id=0x100000000, capture_ms=0)

    def test_fixture_is_stable(self):
        src = bytes((i * 17 + 5) & 0xFF for i in range(module.SOURCE_BYTES))
        frame = module.prepare_frame(src, event_id=7, frame_id=9, capture_ms=1234)
        self.assertEqual(frame.gray_fnv1a, 0xE0A98505)
        self.assertEqual(frame.gray_sum32, 0x000A1320)


if __name__ == "__main__":
    unittest.main(verbosity=2)




