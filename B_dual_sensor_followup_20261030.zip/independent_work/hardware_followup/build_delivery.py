"""Package only the completed B follow-up, including failed runs and provenance."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
stage=BASE/'artifacts'/('B_dual_sensor_followup_stage_'+stamp)
stage.mkdir()
chosen=set()
def add(path):
    if path.is_dir():
        for f in path.rglob('*'):
            if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':chosen.add(f)
    elif path.is_file():chosen.add(path)
    else:raise FileNotFoundError(path)

add(ROOT)
add(BASE/'independent_work/c3_driver_host/vendor')
for name in ('test_sht30_driver.c','run_driver_checks.py','README.md'):add(BASE/'independent_work/c3_driver_host'/name)
fast=BASE/'standalone_sensor_fast'
for name in ('fast_bridge.py','d2xx_transport.py','thermal_scheduler.py','thermal_calculate.py','thermal_algorithm.dll','build_algorithm.py','load_fast_sram.py'):add(fast/'host'/name)
for name in ('native','vendor','tests'):add(fast/name)
evidence=json.loads((fast/'logs/build_evidence.json').read_text(encoding='utf-8'))
for relative in evidence['files_sha256']:add(fast/relative)
add(fast/'logs/build_evidence.json')
add(fast/'logs/sram_load_20261030_201540_106778.json')
for prefix in ('dual_soak_','followup_probe_','recovery_check_'):
    for path in (BASE/'logs').glob(prefix+'20261030*'):add(path)
for name in ('B_dual_sensor_followup_audit_20261030.json','B_双传感器实测与待C联调_20261030.md'):add(BASE/'records'/name)
for path in sorted(chosen):
    relative=path.relative_to(BASE);target=stage/relative
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
readme=stage/'README.md'
readme.write_text((ROOT/'README.md').read_text(encoding='utf-8'),encoding='utf-8')
manifest=dict(scope='B_COMPLETED_DUAL_SENSOR_FOLLOWUP',created_at=datetime.now().astimezone().isoformat(),hardware_data_included=True,final_soc_acceptance=False,files_sha256={str(f.relative_to(stage)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(stage.rglob('*')) if f.is_file()})
(stage/'FOLLOWUP_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=BASE/'artifacts/B_dual_sensor_followup_20261030.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted(stage.rglob('*')):
        if f.is_file():z.write(f,f.relative_to(stage))
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.sha256.txt').write_text(digest+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps(dict(stage=str(stage),archive=str(archive),sha256=digest,files=len(manifest['files_sha256']),bytes=archive.stat().st_size),indent=2))
