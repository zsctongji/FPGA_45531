"""Check frozen bundle hashes and host tests without importing hardware drivers."""
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parent


def main():
    manifest=json.loads((ROOT/"bundle_manifest.json").read_text(encoding="utf-8"))
    for relative,digest in manifest["files_sha256"].items():
        path=(ROOT/relative).resolve()
        if not path.is_relative_to(ROOT):raise RuntimeError("manifest path escapes bundle")
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise RuntimeError("bundle hash mismatch: "+relative)
    sys.path.insert(0,str(ROOT/"host"))
    from load_fast_sram import preflight
    preflight(ROOT)
    output=io.StringIO()
    suite=unittest.defaultTestLoader.discover(str(ROOT/"host"),pattern="test_*.py")
    result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
    # No actual serial, D2XX or Efinity driver is needed for the offline workflow.
    drivers=[name for name in ("serial","ftd2xx","pyftdi.ftdi","efx_pgm.ftdi_program") if name in sys.modules]
    report={"scope":"OFFLINE_BUNDLE_VERIFICATION","status":"PASS" if result.wasSuccessful() and not drivers else "FAIL",
            "hardware_accessed":False,"hardware_drivers_imported":drivers,
            "manifest_files":len(manifest["files_sha256"]),"tests_run":result.testsRun,
            "failures":len(result.failures),"errors":len(result.errors),
            "performance_measured_on_board":False,"final_soc_release":"BLOCKED_BY_EVIDENCE"}
    print(output.getvalue())
    print(json.dumps(report,indent=2))
    return 0 if report["status"]=="PASS" else 1


if __name__=="__main__":raise SystemExit(main())
