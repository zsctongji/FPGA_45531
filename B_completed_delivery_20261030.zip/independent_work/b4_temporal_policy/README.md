# B4 temporal policy

The state machine rejects future, stale, too-old, errored, and implausibly jumping environment samples. It uses modulo-2^32 timestamps so a normal counter wrap is accepted. Rejected samples do not replace the last accepted baseline; calling reset after a bus/reconnection fault permits the next verified sample to establish a new baseline.

The tests are synthetic only and do not represent a board measurement.
