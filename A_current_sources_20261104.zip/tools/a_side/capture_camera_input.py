"""Record A2V1/A2D1 camera-ingress UART telemetry; never transmit to the board."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import struct
import subprocess
import sys
import time
from measure_video import analyse

ROOT=Path(__file__).resolve().parents[2]
RECORD=struct.Struct('<4sIIHHBBHIIII')
DEBUG_RECORD=struct.Struct('<4sIIHHBBHIIIHHIII')
MAGIC=b'A2V1'
DEBUG_MAGIC=b'A2D1'
CAMERA_REGISTERS=[0x3107,0x3108,0x3208,0x3209,0x320a,0x320b,0x320c,0x320d,
                  0x320e,0x320f,0x3e00,0x3e01,0x3e02,0x301f,0x36e9,0x37f9]


class Decoder:
    def __init__(self):
        self.buffer=bytearray()
        self.stats=Counter()

    def feed(self,data):
        self.buffer.extend(data)
        records=[]
        while self.buffer:
            positions=[p for magic in (MAGIC,DEBUG_MAGIC) if (p:=self.buffer.find(magic))>=0]
            if not positions:
                discard=max(0,len(self.buffer)-3)
                self.stats['noise_bytes']+=discard
                del self.buffer[:discard]
                break
            offset=min(positions)
            if offset:
                self.stats['noise_bytes']+=offset
                del self.buffer[:offset]
            extended=self.buffer[:4]==DEBUG_MAGIC
            layout=DEBUG_RECORD if extended else RECORD
            if len(self.buffer)<layout.size:break
            packet=bytes(self.buffer[:layout.size])
            values=layout.unpack(packet)
            if (sum(packet[:-4])!=values[-1] or values[5] not in (0,1) or values[6]&~6
                    or (values[6]&4 and values[7]>>8>=len(CAMERA_REGISTERS))):
                self.stats['invalid']+=1
                del self.buffer[0]
                continue
            del self.buffer[:layout.size]
            _,frame,ms,width,height,complete,flags,debug,frames,malformed,drops=values[:11]
            records.append(dict(frame_id=frame,timestamp_ms=ms,width=width,height=height,
                complete=complete,clock_source='camera_input',evidence='hardware',
                raw_csi_debug=values[11] if extended else (debug if not flags&4 else None),
                raw_csi_seen=values[12] if extended else None,
                raw_csi_rising_cycles=values[13] if extended else None,
                raw_csi_window_cycles=values[14] if extended else None,
                protocol=packet[:4].decode('ascii'),source_boundaries=frames,malformed_frames=malformed,
                telemetry_drops=drops,transport_errors_qualified=False,vs_data_high=bool(flags&2),
                camera_register_address=CAMERA_REGISTERS[debug>>8] if flags&4 else None,
                camera_register_value=debug&255 if flags&4 else None))
            self.stats['records']+=1
        return records


def detect_port():
    p=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','RemoteSigned','-File',str(ROOT/'tools/detect_sensor_uart.ps1')],
                     capture_output=True,text=True,timeout=20)
    if p.returncode:raise RuntimeError('Cannot identify unique FT4232 C UART; specify --port. '+p.stderr.strip()[-1000:])
    return json.loads(p.stdout)['port']


def capture(port=None,seconds=65,output=None,probe=False,baud=115200):
    if seconds<=0 or (seconds<60 and not probe):raise ValueError('At least 60 seconds required unless --probe is explicit')
    sys.path.append(str(ROOT/'tools/efinity/2026.1/python311/Lib/site-packages'))
    import serial
    port=port or detect_port()
    output=Path(output) if output else ROOT/'logs/a_side/camera_input'/datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')
    output.mkdir(parents=True,exist_ok=False)
    decoder=Decoder();rows=[];started=time.monotonic();first=last=None
    report=dict(status='RUNNING',port=port,baud=baud,expected_usercode='0x41325631',
                timer='local 50 MHz camera clock, not integrated SoC time',
                transport_errors_qualified=False,board_source_verified=False,probe_only=probe)
    try:
        with serial.Serial(port,baud,timeout=.25) as uart, (output/'raw.bin').open('wb') as raw, (output/'frames.csv').open('w',encoding='utf-8-sig',newline='') as csvfile:
            writer=None
            while time.monotonic()-started<seconds:
                data=uart.read(4096)
                if data:raw.write(data);raw.flush()
                for row in decoder.feed(data):
                    if first is None:first=time.monotonic()
                    last=time.monotonic()
                    if writer is None:writer=csv.DictWriter(csvfile,fieldnames=list(row));writer.writeheader()
                    writer.writerow(row);csvfile.flush();rows.append(row)
                    if len(rows)%30==0:print(f"Camera input: {len(rows)} records, latest frame {row['frame_id']}, {row['width']}x{row['height']}",flush=True)
                if not rows and time.monotonic()-started>10:
                    raise TimeoutError('No A2V1/A2D1 camera record after 10 seconds; verify image, port and baud')
        report['measurement']=analyse(rows)
        report['host_observed_seconds']=last-first if first is not None else 0
        source_seconds=report['measurement']['seconds']
        report['clock_ratio_to_host']=source_seconds/(last-first) if last>first else None
        report['telemetry_drops_changed']=rows[-1]['telemetry_drops']!=rows[0]['telemetry_drops']
        report['camera_registers']={f"0x{row['camera_register_address']:04X}":f"0x{row['camera_register_value']:02X}"
                                    for row in rows if row['camera_register_address'] is not None}
        registers={int(k,16):int(v,16) for k,v in report['camera_registers'].items()}
        sane=len(registers)==16 and len(set(registers.values()))>=3
        report['camera_registers_sanity']='PLAUSIBLE_NEEDS_DEVICE_REVIEW' if sane else 'NOT_VALIDATED'
        debug_rows=[row for row in rows if row['protocol']=='A2D1']
        report['extended_diagnostics_records']=len(debug_rows)
        report['raw_csi_seen_or']=hex(__import__('functools').reduce(int.__or__,(r['raw_csi_seen'] for r in debug_rows),0))
        report['raw_csi_fault_interpretation']='UNQUALIFIED_RAW_BITS_NOT_SOT_COUNTS'
        if sane:
            report['camera_chip_id']=f"0x{registers[0x3107]*256+registers[0x3108]:04X}"
            report['camera_timing_raw']={name:registers[addr]*256+registers[addr+1]
                for name,addr in [('width',0x3208),('height',0x320a),('hts',0x320c),('vts',0x320e)]}
        report['status']='PROBE_ONLY' if probe else 'CAPTURED_NEEDS_SOURCE_REVIEW'
    except Exception as exc:
        report.update(status='FAIL',error=str(exc))
        raise
    finally:
        report.update(records=len(rows),decoder=dict(decoder.stats),partial_bytes=len(decoder.buffer),
                      host_run_seconds=time.monotonic()-started)
        (output/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(report,ensure_ascii=False,indent=2))
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port');p.add_argument('--seconds',type=float,default=65);p.add_argument('--output')
    p.add_argument('--baud',type=int,default=115200)
    p.add_argument('--probe',action='store_true',help='Short diagnostic run; never acceptance evidence')
    capture(**vars(p.parse_args()))
