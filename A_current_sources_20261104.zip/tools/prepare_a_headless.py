"""Clone accepted A2, preserve its safety/configuration, add owned gray export."""
from pathlib import Path
import re
import shutil
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'projects/11_a_camera_diag'
target=ROOT/'projects/12_a_headless'
if target.exists():raise FileExistsError(target)
ignored={'outflow','work_syn','work_pnr','work_pt','work_sim','work_dbg','__pycache__'}
shutil.copytree(source,target,ignore=lambda d,n:[x for x in n if x in ignored])
names=['a_gray_snapshot.v','a_headless_uart.v','video_a_capture.v','video_grid_sampler.v','frame_motion_stats.v']
for name in names:shutil.copy2(ROOT/'rtl'/name,target/'rtl'/name)
top=target/'rtl/ti60f225_oob_top.v'
s=top.read_text(encoding='utf-8')
start=s.index('camera_input_uart #(')
end=s.index('\n\n',start)
old=s[start:end]
new=old.replace('camera_input_uart #(.CLK_HZ(50000000),.BAUD(115200))','a_headless_uart #(.CLK_HZ(50000000))')
new=new.replace('.raw_debug(mipi_debug_out)', '''.image_done(a_image_done),.image_data(a_image_data),
    .image_id(a_image_id),.image_time(a_image_time),.image_sum(a_image_sum),
    .image_changed(a_image_changed),.image_difference(a_image_diff),
    .image_min_x(a_image_x0),.image_min_y(a_image_y0),.image_max_x(a_image_x1),.image_max_y(a_image_y1),
    .image_flags(a_image_flags),.image_request(a_image_request),.image_address(a_image_address),
    .raw_debug(mipi_debug_out)''')
decl='''wire a_image_done,a_image_request;
wire [7:0] a_image_data,a_image_flags;
wire [15:0] a_image_address,a_image_x0,a_image_y0,a_image_x1,a_image_y1;
wire [31:0] a_image_id,a_image_time,a_image_sum,a_image_changed,a_image_diff;
'''
s=s[:start]+decl+new+s[end:]
anchor='wire preprocess_hs, preprocess_vs, preprocess_de;'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''
// Display/DDR read-side tap: its IDs/time are explicitly separate from CSI A2.
// Both resets must be released before either side can request/own a snapshot.
a_gray_snapshot a_snapshot(
    .pixel_clk(hdmi_tx_slow_clk),.read_clk(i_mipi_rx_pclk),.rst_n(vid_rst_n && w_mipi_rx_pclk_arstn),
    .in_vs(preprocess_vs),.in_de(preprocess_de),.in_gray(preprocess_r),
    .request_toggle(a_image_request),.read_address(a_image_address),.read_data(a_image_data),
    .done_toggle(a_image_done),.frame_id(a_image_id),.timestamp_ms(a_image_time),.checksum(a_image_sum),
    .changed_count(a_image_changed),.difference_sum(a_image_diff),
    .min_x(a_image_x0),.min_y(a_image_y0),.max_x(a_image_x1),.max_y(a_image_y1),.flags(a_image_flags));
''')
top.write_text(s,encoding='utf-8')
xml=target/'ti60f225_oob.xml'
s=xml.read_text(encoding='utf-8')
existing=set(re.findall(r'name="rtl/([^"/]+)"',s))
extra=''.join('        <efx:design_file name="rtl/'+n+'" version="default" library="default" />\n' for n in names if n not in existing)
pos=list(re.finditer(r'        <efx:design_file[^\n]+\n',s))[-1].end()
s=s[:pos]+extra+s[pos:]
s=s.replace('value="0x41325631"','value="0x41335631"')
xml.write_text(s,encoding='utf-8')
sdc=target/'ti60f225_oob.sdc'
with sdc.open('a',encoding='utf-8') as file:
    file.write('''
# A3 CDC: unrelated 50 MHz CSI/UART and 148.5 MHz display clocks.
# Only request/done synchronizers and frozen bundled metadata cross this pair;
# image RAM uses independent read/write clocks under the same ownership lease.
set_clock_groups -asynchronous -group {i_mipi_rx_pclk} -group {hdmi_tx_slow_clk}
''')
print(target)
