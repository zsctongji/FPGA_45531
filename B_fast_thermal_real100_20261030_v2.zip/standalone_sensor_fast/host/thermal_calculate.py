"""Recalculate preserved raw pages with the bundled Melexis algorithm, offline."""
import ctypes
import math
from pathlib import Path
import struct

from thermal_scheduler import validate_frame


def assess_plausibility(calculated):
    """Broad diagnostic sanity limits, not calibration or device specifications."""
    reasons = []
    for key, lower, upper in (("supply_v", 2.5, 4.0), ("ambient_c", -50.0, 100.0)):
        values = calculated[key]
        if len(values) != 2 or any(not math.isfinite(v) or not lower <= v <= upper for v in values):
            reasons.append("DERIVED_" + key.upper() + "_IMPLAUSIBLE")
    return {"status": "PLAUSIBILITY_CHECK_PASSED" if not reasons else "REJECTED",
            "reasons": reasons, "policy_supply_v": [2.5, 4.0],
            "policy_ambient_c": [-50.0, 100.0],
            "policy_scope": "broad standalone diagnostic limits; not an accuracy or calibration certificate"}


def read_u16(path, count):
    raw = Path(path).read_bytes()
    if len(raw) != count * 2:
        raise ValueError(f"{path}: expected {count*2} bytes, got {len(raw)}")
    return list(struct.unpack(">" + str(count) + "H", raw))


def write_u16(path, words):
    Path(path).write_bytes(struct.pack(">" + str(len(words)) + "H", *words))


class Calculator:
    def __init__(self, library=None):
        library = library or Path(__file__).with_name("thermal_algorithm.dll")
        self.library = ctypes.CDLL(str(Path(library).resolve()))
        self.calculate = self.library.audit_calculate
        self.calculate.argtypes = [ctypes.POINTER(ctypes.c_uint16)]*3 + [
            ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint16), ctypes.POINTER(ctypes.c_float),
            ctypes.POINTER(ctypes.c_float)]
        self.calculate.restype = ctypes.c_int

    def pair(self, eeprom, frames):
        if len(eeprom) != 832 or len(frames) != 2:
            raise ValueError("need 832 EEPROM words and two complete subpages")
        for frame in frames: validate_frame(frame)
        if {f[833] for f in frames} != {0, 1} or frames[0][832] != frames[1][832]:
            raise ValueError("need opposite pages with identical control registers")
        u16, f32, u8 = ctypes.c_uint16, ctypes.c_float, ctypes.c_uint8
        ee = (u16*832)(*eeprom)
        f0, f1 = [(u16*834)(*f) for f in frames]
        temperatures, quality = (f32*1536)(), (u8*1536)()
        bad, ambient, supply = (u16*10)(), (f32*2)(), (f32*2)()
        result = self.calculate(ee, f0, f1, temperatures, quality, bad, ambient, supply)
        if result != 0: raise ValueError("Melexis parameter extraction failed: " + str(result))
        merged, reasons = [None]*768, ["UNASSIGNED"]*768
        owners = [None]*768
        for j in range(2):
            for i in range(768):
                q = quality[j*768+i]
                if not q: continue
                if owners[i] is not None: raise ValueError("overlapping page ownership")
                owners[i] = frames[j][833]
                if q == 1 and math.isfinite(temperatures[j*768+i]):
                    merged[i] = temperatures[j*768+i]
                    reasons[i] = "VALID"
                else:
                    reasons[i] = "EEPROM_BAD_PIXEL" if q == 2 else "NONFINITE_CALCULATION"
        if any(owner is None for owner in owners): raise ValueError("missing page ownership")
        valid = [x for x in merged if x is not None]
        if not valid: raise ValueError("no finite valid pixels")
        mask = bytearray(96)
        for i, value in enumerate(merged):
            if value is not None: mask[i//8] |= 1 << (i%8)
        return {"scope":"OFFLINE_RECALCULATION_OF_CAPTURED_RAW_DATA", "width":32,"height":24,
                "temperature_c":merged, "pixel_reason":reasons, "page_owner":owners,
                "pixel_valid_bits_hex":mask.hex(), "valid_pixel_count":len(valid),
                "bad_pixel_indices":[x for x in bad if x < 768],
                "minimum_c":min(valid),"maximum_c":max(valid),"mean_c":sum(valid)/len(valid),
                "ambient_c":list(ambient), "supply_v":list(supply),
                "emissivity":.95,"reflected_temperature":"ambient minus 8 C",
                "independent_radiometric_calibration":False}
