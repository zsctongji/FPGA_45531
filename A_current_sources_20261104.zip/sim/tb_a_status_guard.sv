`timescale 1ns/1ps
module tb_a_status_guard;
    reg [31:0] now_ms=1000,v=500,t=0,e=0;
    reg [2:0] valid=7,fault=0;
    wire [2:0] usable,stale,missing;
    a_status_guard dut(.now_ms(now_ms),.visual_timestamp_ms(v),.thermal_timestamp_ms(t),
        .environment_timestamp_ms(e),.valid_mask(valid),.fault_mask(fault),
        .usable_mask(usable),.stale_mask(stale),.missing_mask(missing));
    initial begin
        #1;if(usable!=7||stale!=0||missing!=0)$fatal(1,"boundary inclusive");
        now_ms=1001;#1;if(usable!=4||stale!=3)$fatal(1,"expired gate");
        fault=2;valid=3;#1;if(usable!=0||stale!=1||missing!=4)$fatal(1,"fault priority / missing");
        now_ms=16;v=32'hfffffff0;t=17;e=16;valid=7;fault=0;
        #1;if(usable!=5||stale!=2)$fatal(1,"wrap and future timestamp");
        $display("PASS tb_a_status_guard age thresholds, fault priority, missing, wrap, future timestamp");$finish;
    end
endmodule
