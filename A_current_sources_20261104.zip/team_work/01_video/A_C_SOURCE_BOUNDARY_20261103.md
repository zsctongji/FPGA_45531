# A/C 单像素源与显示边界交接

适配目标来自共享分支 6c11cca 的 `SOURCE_VIDEO_CAPTURE.md`、`VIDEO_FRAMEBUFFER_HANDOFF.md` 和 `PIN_OWNERSHIP_20261031.md`。本文件为接入约束及未决事项，不是整机约束文件。

## 唯一的逻辑交接面

| C 端口 | A 必须交付 |
|---|---|
| c2_video_clk | 真正的源单像素处理时钟，不能填 HDMI 读出时钟后称源端 |
| c2_pixel_gray[7:0] | 一拍一像素 unsigned GRAY8，按行顺序、与DE同拍 |
| c2_pixel_vs/de | VS高有效且在消隐上升；每行DE连续覆盖1920像素、共1080行；若前级灰度有流水延迟，VS/DE必须一并延迟 |
| c2_shared_video_ms/valid | 由 C 唯一计时源一致跨域到视频域；首个有效DE锁存；不能复用A诊断本地计时冒充共时 |
| c2_display_rgb / c2_out_vs/de/hs | C 单像素RGB读回及配套时序整体延迟1拍；A在此后接同帧状态与TMDS边界 |

## 厂家现有信号的真实含义

`projects/13_a_display_test/rtl/ti60f225_oob_top.v` 的源 CSI 数据为40位，每拍4个RAW10。旧写DDR入口取 `[39:32] [29:22] [19:12] [9:2]` 的高8位，属于 Bayer 采样值，不是四个已完成色彩转换的 GRAY8 像素。

旧DDR读端 `{ch0_b,ch0_g}` 是打包RAW；`debayer_top_2to1` 后的 `rgb_datax2` 才是两份BGR24。现有 `a_gray_snapshot` 在 `hdmi_tx_slow_clk` 的显示/DDR读出域取灰度，因此五张历史真图的 `source_frame_id=null`、`shared_soc_time=false` 继续保留。不能将其直接改名为 CSI 源帧。

### 必须联合确定的实现

- 源端去马赛克/灰度转换应在唯一 C DDR 写入口之前。现存厂家去马赛克位于旧DDR之后，直接复用将保留第二套DDR路径，违背单控制器设计。
- 四像素/拍到单像素/拍须核算瞬时输入速率、缓冲、输出时钟和整行DE连续性；不能只拿30fps平均速率证明不会溢出。未选定适配方案前，不把任意FIFO当作完整解决方案。
- 若最终显示沿用单像素TMDS链路，可直接在 C 单像素RGB/延迟时序之后接A叠加；若选择双像素编码链路，应另做1→2打包与相应时序，明确低/高像素顺序。
- C 的完整视频/AI必须看到同一组源像素；首DE时间、帧号、几何与最终BRESP发布屏障保持不变。

## 物理资源必须保留的待定项

1. B3/GPIOL_04/J28.37、C3/GPIOL_06/J28.39：最终由 C3 的开漏 SCL/SDA 唯一拥有。A旧LCD输出移除；输入释放不等于已接控制器。
2. B5/GPIOL_10/J28.38：蜂鸣器只保留一个最终所有者，不能并联A常量和C输出。
3. P13/GPIOR_27：A led[0] 与 C i_arstn 冲突。必须依据真实板图选择唯一功能，不能自动重分配复位脚。
4. PLL_TL0、PLL_BR0 重叠，Bank2B/3A声明差异：由 A/C 对照真实电源、复位、路由、频率和SDC合并；不套用任一旧工程默认值。
5. 物理地址未验收前 `c2_map_enable=0`；C3 pad 未验收前板级包装明确 `c3_io_enable=0`。源码存在接口不等于可以下载。

当前不生成声称“可直接烧录的最终整机bit文件”。未解决项要在唯一 Interface Designer / SDC 中闭环，再做接口检查、P&R、时序/CDC与实物验收。
