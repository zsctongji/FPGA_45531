# B 独立扩展交付包（2026-10-30 交付标识）

本包扩展此前B完成包，包含独立图像校验、B6D0草案接收、原SHT30 C驱动主机验证。

1. independent_work/a96_gray_adapter：96×54→96×96上下零补边、框坐标映射、当前vendor模型int8转换，9项测试；策略仍需A/C最终验收。
2. independent_work/network_draft_v0：补齐draft_receiver.py，14项增强接收器测试；12项既有C分包fixture测试。保留现有B6D0草案，没有新增正式协议。
3. independent_work/c3_driver_host：编译原C驱动和HAL包装层，16个场景、361条断言；不使用另一份Python采样逻辑替代驱动。
4. records_B_独立可完成任务清单_20261030.md：交接范围、已有硬件证据及后续工作。

在解压根目录运行：

python -B verify_extensions.py --report local_verification.json

需要 Python 3.10+ 和主机GCC/Clang（C11）；编译器可用 --cc 路径指定。脚本先检查逐文件SHA256，再跑35项Python测试和16个C场景。生成报告应写入新文件，不覆盖包内受manifest保护的文件。

所有本轮测试为OFFLINE_HOST_ONLY，hardware_accessed=false。不连接板卡，不访问串口，不写Flash，不发蜂鸣器命令。合成图像/主机故障注入不能计入真实传感器采样、摄像头、DDR、网络或整机验收。原C源码为指定本地快照，散列随包。

与前一版待提交草包相比：补齐接收器依赖、修复回绕淘汰和重复续命、增加近期整帧抑制；用真实原C驱动测试取代Python回放器的驱动验收表述；排除pycache和可执行文件。
