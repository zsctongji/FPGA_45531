`timescale 1ns/1ps
module tb_camera_input_monitor;
    reg clk=0; always #5 clk=~clk;
    reg rst_n=0,vs=0,de=0;
    reg [31:0] now_ms=0;
    reg [15:0] errors=0;
    wire valid,complete;
    wire [31:0] fid,stamp,total,malformed;
    wire [15:0] width,height,faults;
    camera_input_monitor #(.EXPECTED_WIDTH(8),.EXPECTED_HEIGHT(3)) dut(
        .clk(clk),.rst_n(rst_n),.in_vs(vs),.in_de(de),.now_ms(now_ms),
        .transport_errors(errors),.record_valid(valid),.record_complete(complete),
        .record_frame_id(fid),.record_timestamp_ms(stamp),.record_width(width),
        .record_height(height),.record_errors(faults),.source_frames(total),.malformed_frames(malformed));
    task tick; begin @(posedge clk); #1; end endtask
    task boundary; begin @(negedge clk);vs=1;de=0;tick();end endtask
    task line(input integer beats); integer i;begin
        @(negedge clk);vs=0;de=1;
        for(i=0;i<beats;i=i+1) begin tick();if(i+1<beats)@(negedge clk);end
        @(negedge clk);de=0;tick();
    end endtask
    task expect_record(input integer id,input integer ok,input integer w,input integer h);
        begin
            if(!valid || fid!==id || complete!==ok[0] || width!==w || height!==h)
                $fatal(1,"record id=%d complete=%b width=%d height=%d",fid,complete,width,height);
        end
    endtask
    integer i;
    initial begin
        tick();@(negedge clk);rst_n=1;
        boundary();if(valid)$fatal(1,"startup must not publish a phantom frame");
        now_ms=32'hfffffff0;line(2);now_ms=1;line(2);line(2);
        boundary();expect_record(0,1,8,3);
        if(stamp!==32'hfffffff0 || total!=2 || malformed!=0)$fatal(1,"first pixel metadata");
        now_ms=17;line(1);line(2);line(2);
        boundary();expect_record(1,0,8,3);
        line(2);line(2); // missing line
        boundary();expect_record(2,0,8,2);
        @(negedge clk);vs=0;tick();boundary();expect_record(3,0,0,0);
        line(2);errors=16'h0040;tick();errors=0;line(2);line(2);
        boundary();expect_record(4,0,8,3);
        if(faults!=16'h0040)$fatal(1,"transport error lost");
        line(2);line(2);line(2);line(2);
        boundary();expect_record(5,0,8,4);
        line(2);line(2);
        // Final line ends on the VS boundary, without a separate DE-fall cycle.
        @(negedge clk);de=1;tick();tick();boundary();expect_record(6,1,8,3);
        if(malformed!=5)$fatal(1,"malformed count");
        // No consumer feedback exists: records keep flowing after bad frames.
        for(i=0;i<4;i=i+1)begin line(2);line(2);line(2);boundary();expect_record(7+i,1,8,3);end
        @(negedge clk);rst_n=0;tick();
        if(valid || total || malformed)$fatal(1,"reset");
        $display("PASS tb_camera_input_monitor: 4 pixels/beat, metadata wrap, malformed/transport recovery");
        $finish;
    end
endmodule
