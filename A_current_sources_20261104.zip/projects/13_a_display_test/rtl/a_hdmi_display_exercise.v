// Real camera underneath an explicitly labelled display-interface exercise.
// B/C values and decisions are fixtures, never claimed as live sensing or AI.
// A synchronous thermal ROM is prefetched with the RGB/control delay matched.
module a_hdmi_display_exercise #(
    parameter CLK_HZ=148500000,WIDTH=1920,HEIGHT=1080,PHASE_MS=10000,UI_SCALE=3,
    parameter HEAT_FILE="a_display_thermal.mem"
)(
    input wire clk,rst_n,in_hs,in_vs,in_de,
    input wire [23:0] in_rgb,
    output wire out_hs,out_vs,out_de,
    output wire [23:0] out_rgb,
    output reg [2:0] phase
);
    reg [31:0] tick,now_ms,phase_time,fid;
    reg vs_prev,de_prev;
    reg [2:0] frame_phase;
    reg [15:0] ux,uy;
    reg [7:0] xr,yr;
    reg hs_d,vs_d,de_d;
    reg [23:0] rgb_d;
    reg [7:0] thermal[0:767],heat_q;
    initial $readmemh(HEAT_FILE,thermal);
    wire inside_heat=ux>=16&&ux<144&&uy>=80&&uy<176;
    wire [9:0] address=inside_heat?((uy-80)/4)*32+(ux-16)/4:0;
    always @(posedge clk)heat_q<=thermal[address];
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            tick<=0;now_ms<=0;phase_time<=0;phase<=0;frame_phase<=0;fid<=0;
            vs_prev<=0;de_prev<=0;ux<=0;uy<=0;xr<=0;yr<=0;
            hs_d<=0;vs_d<=0;de_d<=0;rgb_d<=0;
        end else begin
            hs_d<=in_hs;vs_d<=in_vs;de_d<=in_de;rgb_d<=in_rgb;
            vs_prev<=in_vs;de_prev<=in_de;
            if(tick==CLK_HZ/1000-1)begin
                tick<=0;now_ms<=now_ms+1;
                if(phase_time==PHASE_MS-1)begin phase_time<=0;phase<=phase==5?0:phase+1'b1;end
                else phase_time<=phase_time+1'b1;
            end else tick<=tick+1'b1;
            if(in_vs&&!vs_prev)begin
                frame_phase<=phase;fid<=fid+1'b1;ux<=0;uy<=0;xr<=0;yr<=0;
            end else if(in_de)begin
                if(xr==UI_SCALE-1)begin xr<=0;ux<=ux+1'b1;end else xr<=xr+1'b1;
            end else if(de_prev)begin
                ux<=0;xr<=0;
                if(yr==UI_SCALE-1)begin yr<=0;uy<=uy+1'b1;end else yr<=yr+1'b1;
            end
        end
    end
    wire [2:0] valid=frame_phase==0?3'b0:3'b111;
    wire [2:0] fault=frame_phase==3?3'b111:3'b0;
    wire [31:0] stamp=now_ms-(frame_phase==2?32'd5001:32'd0);
    wire [31:0] result_fid=frame_phase==5?fid-2:fid;
    wire [6:0] px=fid[8:2]<96?fid[8:2]:7'd95;
    video_a_result_display #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.UI_SCALE(UI_SCALE),.DIAGNOSTIC_TEST(1)) display(
        .clk(clk),.rst_n(rst_n),.in_hs(hs_d),.in_vs(vs_d),.in_de(de_d),.in_rgb(rgb_d),
        .now_ms(now_ms),.visual_timestamp_ms(stamp),.thermal_timestamp_ms(stamp),.environment_timestamp_ms(stamp),
        .valid_mask(valid),.fault_mask(fault),.diagnostic_phase(frame_phase),
        .alarm_active(frame_phase==4),.prediction_valid(frame_phase==4||frame_phase==5),
        .person_score(8'd192),.event_score(8'd128),.event_type(8'd1),
        .temperature_centi(16'sd2547),.humidity_centi(16'd5594),
        .prediction_x(px),.prediction_y(7'd27),.status_frame_id(result_fid),.display_frame_id(fid),
        .heat_pixel_valid(1'b1),.heat_level(heat_q),.heat_address(),.heat_request(),
        .out_hs(out_hs),.out_vs(out_vs),.out_de(out_de),.out_rgb(out_rgb));
endmodule
