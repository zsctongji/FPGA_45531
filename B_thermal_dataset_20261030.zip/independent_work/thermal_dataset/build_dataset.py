"""Export saved real MLX pairs for offline C ABI replay. Never opens hardware."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics
import struct
import sys

BASE = Path(__file__).resolve().parents[2]
DEFAULT_RUN = BASE / "standalone_sensor_fast/logs/real_fast_20261030_184934_752153"
sys.path.insert(0, str(BASE / "standalone_sensor_fast/host"))
sys.path.insert(0, str(BASE / "independent_work/offline_acceptance"))
from thermal_calculate import Calculator, assess_plausibility, read_u16
from thermal_features import analyze, validate_grid
from gate_host import Gate, build_library

ABI = 0x10000
RECORD = struct.Struct("<6I768h96s")  # offline now_ms prefix + coop_thermal_t
HALF = 0x80000000


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n", encoding="utf-8")


def child(folder, name):
    require(isinstance(name, str), "source name must be text")
    path = (folder / name).resolve()
    require(path.is_relative_to(folder.resolve()), "source escapes capture directory")
    return path


def age_ms(now, then):
    for value in (now, then):
        require(type(value) is int and 0 <= value <= 0xffffffff, "expected uint32 clock")
    age = (now - then) & 0xffffffff
    require(age < HALF, "future or ambiguous timestamp")
    return age


def encode_grid(grid):
    values, mask = validate_grid(grid)
    encoded = []
    for value in values:
        centi = 0 if value is None else round(value * 100)
        require(-32768 <= centi <= 32767, "temperature exceeds int16 centi-C")
        encoded.append(centi)
    return encoded, mask


def build(run, output, compiler=None):
    run, output = Path(run).resolve(), Path(output).resolve()
    require(not output.is_relative_to(run), "output cannot overwrite captured evidence")
    summary = load(run / "summary.json")
    require(summary["scope"] == "STANDALONE_MLX_DIAGNOSTIC", "unexpected capture scope")
    require(summary["accepted_pairs"] == summary["plausible_temperature_pairs"] == 100,
            "this frozen dataset requires 100 pairs")
    require(summary["control_restore"] == "VERIFIED" and
            summary["original_control"] == summary["restored_control"] == 0x1901,
            "original control restoration evidence is missing")
    for name, digest in summary["files_sha256"].items():
        require(sha(child(run, name)) == digest, "source hash mismatch: " + name)
    pair_paths = sorted(run.glob("pair_*.json"))
    require(len(pair_paths) == 100, "unexpected pair file count")
    output.mkdir(parents=True, exist_ok=True)
    library, c_build = build_library(output / "build", compiler)
    calculator = Calculator()
    eeprom = read_u16(run / "eeprom_u16_be.bin", 832)
    records, rows, used, payloads = [], [], set(), bytearray()
    source_id = "mlx90640:" + run.name + ":" + sha(run / "summary.json")[:16]
    with Gate(library) as gate:
        for index, pair_path in enumerate(pair_paths):
            require(pair_path.name == f"pair_{index:03d}.json", "pair index gap")
            pair = load(pair_path)
            names = pair["subpage_files"]
            require(len(names) == 2 and len(set(names)) == 2, "pair repeats a subpage")
            require(not used.intersection(names), "subpage reused across samples")
            used.update(names)
            pages, metadata = [], []
            for name in names:
                raw = child(run, name)
                meta_path = raw.with_name(raw.name.replace("_u16_be.bin", ".json"))
                require(raw.name.endswith("_u16_be.bin") and meta_path.name != raw.name,
                        "unexpected raw page name")
                meta = load(meta_path)
                require(meta["sampling_phase"] == "MEASUREMENT", "warmup cannot be exported")
                require(meta["raw_file"] == name, "page metadata mismatch")
                words = read_u16(raw, 834)
                require(words[833] == meta["page"] and words[832] == meta["control"],
                        "page ID or control mismatch")
                require(age_ms(meta["clear_completed_ms"], meta["ready_observed_ms"]) <= 500 and
                        age_ms(meta["read_completed_ms"], meta["clear_completed_ms"]) <= 500 and
                        age_ms(meta["checked_completed_ms"], meta["read_completed_ms"]) <= 500,
                        "invalid per-page clock ordering")
                pages.append(words)
                metadata.append(meta)
            first, second = metadata
            timestamp, now = first["ready_observed_ms"], second["checked_completed_ms"]
            age = age_ms(now, timestamp)
            require(age == pair["observed_age_ms"] and age <= 500, "pair deadline mismatch")
            grid = calculator.pair(eeprom, pages)
            saved_grid = load(run / f"temperature_{index:03d}.json")
            for key, value in grid.items():
                require(saved_grid[key] == value, "saved/recalculated temperature mismatch: " + key)
            plausible = assess_plausibility(grid)
            require(saved_grid["plausibility"] == plausible and
                    plausible["status"] == "PLAUSIBILITY_CHECK_PASSED", "implausible auxiliary data")
            values, mask = encode_grid(grid)
            require(grid["valid_pixel_count"] == 767 and grid["temperature_c"][620] is None,
                    "frozen capture validity changed")
            # These flags describe a reconstructed host probe, not a board publication.
            args = dict(sample_id=index, timestamp_ms=timestamp, flags=3, errors=64,
                        temperatures=values, mask=mask)
            probes = {
                "at_saved_final_check": gate.thermal(now_ms=now, **args),
                "at_age_500ms": gate.thermal(now_ms=(timestamp + 500) & 0xffffffff, **args),
                "at_age_501ms": gate.thermal(now_ms=(timestamp + 501) & 0xffffffff, **args),
                "future_sample": gate.thermal(now_ms=(timestamp - 1) & 0xffffffff, **args),
            }
            require(all(p["copy_or_rejection_preserved"] for p in probes.values()),
                    "C gate modified a rejected output")
            require(probes["at_saved_final_check"]["rc"] == 0 and
                    probes["at_age_500ms"]["rc"] == 0 and
                    probes["at_age_501ms"]["rc"] == -5 and
                    probes["future_sample"]["rc"] == -5, "C gate age boundary changed")
            features = analyze(grid)
            record = {
                "schema": "B_THERMAL_REPLAY_V1", "capture_id": source_id,
                "sample_id": index, "origin": "SAVED_REAL_Ti60F225_MLX90640_CAPTURE",
                "new_board_measurement": False,
                "clock_domain": "BQFAST01_STANDALONE_BOARD_MS_NOT_FINAL_SOC",
                "timestamp_ms": timestamp, "reconstructed_probe_now_ms": now,
                "observed_pair_age_ms": age,
                "remaining_500ms_budget_at_saved_final_check_ms": 500-age,
                "timestamp_semantics": "first ready observed to second final check; not exposure age",
                "source_pair": pair_path.name, "source_subpages": names,
                "source_pair_sha256": sha(pair_path),
                "source_subpage_sha256": [sha(run/name) for name in names],
                "source_temperature_sha256": sha(run/f"temperature_{index:03d}.json"),
                "width": 32, "height": 24,
                "temperature_c": grid["temperature_c"], "pixel_reason": grid["pixel_reason"],
                "pixel_valid_bits_hex": mask.hex(),
                "reconstructed_abi": {"abi_version": ABI, "sample_id": index,
                    "timestamp_ms": timestamp, "valid_flags": 3, "error_bits": 64,
                    "temperature_centi_c": values, "pixel_valid_bits_hex": mask.hex(),
                    "not_observed_board_publication": True},
                "host_c_gate_probes": probes, "thermal_candidates": features,
                "final_soc_shared_clock_validated": False,
                "human_or_fall_detection_validated": False,
            }
            records.append(record)
            payloads.extend(RECORD.pack(now, ABI, index, timestamp, 3, 64, *values, mask))
            stats = features["statistics_valid_only"]
            rows.append(dict(sample_id=index, timestamp_ms=timestamp, probe_now_ms=now,
                             observed_pair_age_ms=age, remaining_budget_ms=500-age,
                             valid_pixels=767, min_c=stats["min_c"], max_c=stats["max_c"],
                             mean_c=stats["mean_c"], median_c=stats["median_c"],
                             candidate_components=len(features["candidates"]),
                             host_gate_rc=probes["at_saved_final_check"]["rc"]))
    require(len(used) == 200, "need 200 unique measured subpages")
    with (output/"thermal_records.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
        for record in records:
            stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False, separators=(",", ":"))+"\n")
    with (output/"thermal_metrics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (output/"thermal_probe_records.bin").write_bytes(payloads)
    ages = [r["observed_pair_age_ms"] for r in rows]
    report = {"schema": "B_THERMAL_DATASET_REPORT_V1", "execution_status": "PASS",
        "hardware_accessed": False, "new_board_measurements": 0,
        "capture_id": source_id, "source_summary_sha256": sha(run/"summary.json"),
        "source_files_verified": len(summary["files_sha256"]),
        "temperature_pairs_recalculated": len(records), "unique_measured_subpages": len(used),
        "warmup_exported": 0, "valid_pixels_per_pair": 767, "invalid_index_zero_based": 620,
        "observed_pair_age_ms": {"min": min(ages), "max": max(ages), "mean": statistics.mean(ages)},
        "remaining_budget_ms_at_saved_final_check": {"min": 500-max(ages), "max": 500-min(ages)},
        "host_c_gate_accepted_at_saved_final_check": 100,
        "host_c_gate_accepts_at_500ms": 100, "host_c_gate_rejects_at_501ms": 100,
        "host_c_gate_rejects_future_sample": 100,
        "c_policy_build": c_build,
        "reconstructed_abi_flags": 3, "reconstructed_abi_errors": 64,
        "binary": {"format": "offline <u32 now_ms> + little-endian coop_thermal_t",
                   "record_bytes": RECORD.size, "records": 100,
                   "not_a_network_protocol": True,
                   "invalid_slots": "zero placeholder with mask bit 0; never a temperature estimate",
                   "rounding": "Python round ties-to-even to centi-C"},
        "full_system_release_allowed": False,
        "remaining_joint_evidence": ["final SoC I2C and deadlines", "same-session real video",
            "final shared clock", "sensor/video spatial orientation", "real event/network/alarm integration"],
        "features": "exploratory temperature regions; no person/fall labels or classifier validation",
        "output_files_sha256": {name: sha(output/name) for name in
            ("thermal_records.jsonl", "thermal_metrics.csv", "thermal_probe_records.bin")}}
    write_json(output/"dataset_report.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, default=DEFAULT_RUN)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("results"))
    parser.add_argument("--cc")
    args = parser.parse_args()
    print(json.dumps(build(args.run, args.output, args.cc), ensure_ascii=False, indent=2))
