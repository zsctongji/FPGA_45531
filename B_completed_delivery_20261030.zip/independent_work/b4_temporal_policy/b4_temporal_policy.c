#include "b4_temporal_policy.h"
#include <stdint.h>

static uint32_t abs_i32(int32_t a, int32_t b) {
    int64_t d = (int64_t)a - (int64_t)b;
    if (d < 0) d = -d;
    return d > 0xffffffffLL ? 0xffffffffu : (uint32_t)d;
}

static int age_valid(uint32_t reference_ms, uint32_t sample_ms, uint32_t max_age_ms) {
    uint32_t age = reference_ms - sample_ms;
    if (age >= 0x80000000u) return 0;
    return age <= max_age_ms;
}

void b4_temporal_config_default(b4_temporal_config_t *config) {
    if (!config) return;
    config->max_age_ms = COOP_ENV_MAX_LAG_MS;
    config->max_temperature_step_centi_c = 1500;
    config->max_humidity_step_centi_percent = 3000;
}

void b4_temporal_reset(b4_temporal_state_t *state) {
    if (!state) return;
    state->initialized = 0;
    state->last_timestamp_ms = 0;
    state->last_temperature_centi_c = 0;
    state->last_humidity_centi_percent = 0;
}

int b4_temporal_accept_environment(b4_temporal_state_t *state,
                                   const coop_environment_t *sample,
                                   uint32_t now_ms,
                                   const b4_temporal_config_t *config,
                                   uint32_t *reason_bits) {
    uint32_t reasons = 0;
    uint32_t age;
    uint32_t delta;
    if (reason_bits) *reason_bits = 0;
    if (!state || !sample || !config || !config->max_age_ms ||
        config->max_age_ms >= 0x80000000u ||
        config->max_temperature_step_centi_c < 0 ||
        config->max_humidity_step_centi_percent > 10000u)
        return COOP_EINVAL;
    if ((sample->valid_flags & COOP_SAMPLE_COMPLETE) == 0 ||
        (sample->valid_flags & COOP_SAMPLE_CONVERTED) == 0)
        reasons |= B4_TEMPORAL_REASON_FLAGS;
    if (sample->error_bits) reasons |= B4_TEMPORAL_REASON_ERROR;
    age = now_ms - sample->timestamp_ms;
    if (!age_valid(now_ms, sample->timestamp_ms, config->max_age_ms)) {
        if (age >= 0x80000000u) reasons |= B4_TEMPORAL_REASON_FUTURE;
        else reasons |= B4_TEMPORAL_REASON_TOO_OLD;
    }
    if (state->initialized) {
        delta = sample->timestamp_ms - state->last_timestamp_ms;
        if (delta == 0 || delta >= 0x80000000u) reasons |= B4_TEMPORAL_REASON_STALE;
        if (abs_i32(sample->temperature_centi_c, state->last_temperature_centi_c) >
            (uint32_t)config->max_temperature_step_centi_c)
            reasons |= B4_TEMPORAL_REASON_TEMP_STEP;
        if (abs_i32((int32_t)sample->humidity_centi_percent,
                    (int32_t)state->last_humidity_centi_percent) >
            config->max_humidity_step_centi_percent)
            reasons |= B4_TEMPORAL_REASON_HUM_STEP;
    }
    if (reason_bits) *reason_bits = reasons;
    if (reasons) return (reasons & (B4_TEMPORAL_REASON_FUTURE | B4_TEMPORAL_REASON_TOO_OLD))
                            ? COOP_ETIMEOUT : COOP_ESTATE;
    state->initialized = 1;
    state->last_timestamp_ms = sample->timestamp_ms;
    state->last_temperature_centi_c = sample->temperature_centi_c;
    state->last_humidity_centi_percent = sample->humidity_centi_percent;
    return COOP_OK;
}
