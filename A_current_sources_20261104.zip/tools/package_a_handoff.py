"""Package A sources, actual headless evidence and explicitly scoped handoff."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def package():
    test = json.loads((ROOT / 'logs/a_side_selftest.json').read_text(encoding='utf-8'))
    if test['status'] != 'PASS':
        raise RuntimeError('A selftest must pass before packaging')
    for name, expected in test['source_sha256'].items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise RuntimeError(f'Source changed after selftest: {name}')
    validation=json.loads((ROOT/'logs/a_headless_validation_20261029.json').read_text(encoding='utf-8'))
    if validation['status']!='PASS_A2_A3_HEADLESS_ON_BOARD':
        raise RuntimeError('Actual clean headless qualification required')
    names = [
        'rtl/a_side_units.v', 'rtl/camera_input_monitor.v', 'rtl/video_grid_sampler.v',
        'rtl/video_a_capture.v', 'rtl/ai_frame_mailbox.v', 'rtl/video_status_overlay.v',
        'rtl/osd_font5x7.vh', 'rtl/frame_motion_stats.v', 'rtl/video_motion_display.v',
        'firmware/a_side/a_side.c', 'firmware/a_side/a_side.h',
        'tools/run_a_side.py', 'tools/start_a_side.ps1', 'tools/package_a_handoff.py',
        'tools/A_selftest.cmd', 'tools/A_PC_demo.cmd', 'tools/A_PC_receive.cmd',
        'tools/build_a_firmware.py', 'docs/A_开始这里.md','docs/current_status.md',
        'docs/team_plan_20261022.md', 'team_work/shared/a_interface_v1.md',
        'logs/a_side_selftest.json', 'logs/a_side_synthesis.json', 'logs/a_side_firmware.json',
        'logs/camera_debug/20261026_195204_674498/summary.json',
    ]
    names += ['rtl/a_gray_snapshot.v','rtl/a_headless_uart.v','rtl/camera_input_uart.v',
        'rtl/a_status_guard.v','rtl/video_a_result_display.v','rtl/a_hdmi_display_exercise.v',
        'tools/prepare_a_headless.py','tools/prepare_a_camera_diag.py','tools/prepare_a_display.py','tools/stage_a_camera_register_probe.py',
        'tools/apply_a_exposure_fix.py','tools/release_a_camera_diag.py','tools/efinity_primary.py',
        'tools/run_efinity.ps1','tools/efinity_compile_primary.py','tools/file_hash.ps1',
        'tools/read_jtag_primary.py','tools/package_a_samples.py','tools/finalize_a_headless.py',
        'tools/prepare_a_units.py','tools/run_a_synthesis.ps1','tools/test_a_firmware_host.py','tools/test_a_udp_stress.py',
        'tools/start_a_headless_preview.ps1','tools/A_headless_preview.cmd','tools/A_headless_capture.cmd','tools/A_camera_measure.cmd',
        'tools/a_side/render_real_replay.py','tools/detect_sensor_uart.ps1',
        'sim/test_a_firmware.c','sim/tb_a_real_replay.sv','sim/tb_a_status_guard.sv','sim/tb_a_result_display.sv','sim/tb_a_hdmi_display_exercise.sv',
        'sim/tb_a_gray_snapshot.sv','sim/tb_a_headless_uart.sv','sim/tb_camera_input_uart.sv','sim/tb_a_camera_register_read.sv',
        'docs/A_串口真图导出.md','docs/A_剩余任务核对_20261029.md','docs/A_无显示器调试_20261029.md',
        'docs/A_real_inputs_OFFLINE_REPLAY.png','docs/A_display_scaled_TEST_preview.png','docs/A_显示接口验收_20261029.md',
        'logs/a_display_hdmi_acceptance_20261029.json','logs/a_display_test_program_20261029.log',
        'logs/a_headless_interrupted_audit_20261029.json',
        'logs/a_headless_validation_20261029.json','logs/a_headless_stability_audit_20261029.json',
        'logs/a_headless_first_capture_audit.json','logs/a_headless_rx_pump_probe_audit.json',
        'logs/a_camera_input_acceptance_20261029.json','logs/a_camera_exposure_fix_20261029.json',
        'logs/a_firmware_host.json','logs/a_firmware_host.log','logs/a_real_inputs_replay.json','logs/a_udp_stress_20261029.json',
        'logs/a_headless_program_20261029.log','logs/a_headless_stability_rx_fixed_20261029.log',
        'logs/a_side/headless/20261029_stability_30min/summary.json',
        'logs/a_side/headless/20261029_stability_30min/raw.bin','logs/a_side/headless/20261029_stability_30min/frames.csv',
        'logs/mlx90640/20261029_155654/frame_001.json','logs/sensor_diag/20261026_215457/samples.csv']
    for release_name in ['a_camera_diag','a_headless','a_display_test']:
        rp=ROOT/('logs/'+release_name+'_release.json')
        release=json.loads(rp.read_text(encoding='utf-8'))
        for p in [rp,Path(release['compile_record']),Path(release['bitstream'])]:
            names.append(str(p.relative_to(ROOT)).replace('\\','/'))
        build=json.loads(Path(release['compile_record']).read_text(encoding='utf-8'))
        for artifact in build['artifacts']:
            p=Path(artifact['path'])
            if sha(p.read_bytes()).upper()!=artifact['sha256'].upper():
                raise RuntimeError('Build artifact changed: '+str(p))
            names.append(str(p.relative_to(ROOT)).replace('\\','/'))
        for p in [Path(build['design_log']),Path(build['final_sta']['report']),Path(build['preflight_log'])]:
            names.append(str(p.relative_to(ROOT)).replace('\\','/'))
    for artifact in json.loads((ROOT/'logs/a_side_synthesis.json').read_text(encoding='utf-8'))['artifacts']:
        p=Path(artifact['file'])
        if sha(p.read_bytes()).upper()!=artifact['sha256'].upper():raise RuntimeError('Synthesis artifact changed')
        names.append(str(p.relative_to(ROOT)).replace('\\','/'))
    names.append(str(Path(validation['jtag']).relative_to(ROOT)).replace('\\','/'))
    ignored={'outflow','work_syn','work_pnr','work_pt','work_sim','work_dbg','__pycache__','.git','.aws','.codex','.agents'}
    for folder in ['projects/11_a_camera_diag','projects/12_a_headless','projects/13_a_display_test']:
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and not any(part in ignored for part in p.relative_to(ROOT/folder).parts):
                names.append(str(p.relative_to(ROOT)).replace('\\','/'))
    # Keep original active image bytes and metadata; PGM/BMP are derivable.
    audit=json.loads(Path(validation['full_raw_csv_and_image_audit']).read_text(encoding='utf-8'))
    accepted_folder=Path(audit['folder']).name
    for folder in ['20261029_first_capture','20261029_rx_pump_probe',accepted_folder]:
        for p in (ROOT/'logs/a_side/headless'/folder).glob('*'):
            if p.is_file() and (p.suffix in ['.gray','.json'] or p.name in ['raw.bin','frames.csv']):
                names.append(str(p.relative_to(ROOT)).replace('\\','/'))
    for filename in ['summary.json','raw.bin','frames.csv']:
        names.append('logs/a_side/headless/20261029_stability_rx_fixed/'+filename)
    samples=json.loads((ROOT/'team_work/01_video/ai_samples_20261029/MANIFEST.json').read_text(encoding='utf-8'))
    for sample in samples['samples']:
        for suffix in ['.gray','.json','.pgm','.bmp']:names.append(sample['original']+suffix)
    stress=json.loads((ROOT/'logs/a_udp_stress_20261029.json').read_text(encoding='utf-8'))
    for filename in ['receiver_summary.json','events.csv','process.log']:
        names.append(str((Path(stress['folder'])/filename).relative_to(ROOT)).replace('\\','/'))
    names += [str(p.relative_to(ROOT)).replace('\\','/') for p in (ROOT/'team_work/01_video/ai_samples_20261029').glob('*') if p.is_file()]
    for folder, pattern in [('tools/a_side','*.py'), ('team_work/01_video','*.md'),
                            ('team_work/01_video','*.csv'), ('logs/a_side/rtl_fixture','*'),
                            ('logs/a_side/pc_demo_20261029','*')]:
        names.extend(str(p.relative_to(ROOT)).replace('\\','/')
                     for p in (ROOT / folder).glob(pattern) if p.is_file())
    names.extend('sim/' + top + '.sv' for top in
                 ['tb_camera_input_monitor','tb_a_mailbox','tb_a_capture','tb_a_overlay','tb_a_pipeline'])
    names.extend(str(Path(item['log']).relative_to(ROOT)).replace('\\','/') for item in test['tests'])
    names = sorted(set(names))
    contents = {name: (ROOT / name).read_bytes() for name in names}
    manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(),
        scope='A incremental source and evidence handoff; requires the existing main project and vendor IP/tools',
        complete_system=False, A_independent_headless_verified=True,
        HDMI_display_interface_user_observed=True,
        current_B_C_sensor_AI_fusion_data_connected=False,
        actual_headless_qualification=validation,
        pending_hardware=validation['pending'],
        synthetic_samples=['logs/a_side/rtl_fixture','logs/a_side/pc_demo_20261029'],
        selftest_status=test['status'], selftest_finished=test['finished'],
        files={name: dict(bytes=len(data),sha256=sha(data)) for name,data in contents.items()})
    target = ROOT / 'team_work/handoff'
    target.mkdir(parents=True,exist_ok=True)
    stem = 'A_video_' + datetime.now().strftime('%Y%m%d_%H%M%S')
    archive = target / (stem + '.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in contents.items():
            z.writestr(name,data)
        z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('ZIP CRC verification failed')
        for name,data in contents.items():
            if sha(z.read(name)) != sha(data):
                raise RuntimeError(f'ZIP content mismatch: {name}')
    digest = sha(archive.read_bytes())
    archive.with_suffix('.sha256.txt').write_text(f'{digest}  {archive.name}\n',encoding='utf-8')
    record = dict(status='PASS',archive=str(archive),bytes=archive.stat().st_size,
                  sha256=digest,files=len(contents),zip_readback_verified=True,manifest=manifest)
    archive.with_suffix('.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in record.items() if k!='manifest'},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    package()
