"""Audit preserved real follow-up files offline; imports never open hardware."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
from dual_soak import crc8

BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'standalone_sensor_fast/host'))
from thermal_calculate import Calculator,read_u16,assess_plausibility
from thermal_scheduler import age

def audit(directory,calculator):
    report=json.loads((directory/'summary.json').read_text(encoding='utf-8'))
    checked=0
    for name,digest in report['files_sha256'].items():
        if Path(name).name!=name:raise ValueError('unsafe evidence path')
        if hashlib.sha256((directory/name).read_bytes()).hexdigest()!=digest:raise ValueError('hash mismatch '+name)
        checked+=1
    txs=[json.loads(line) for line in (directory/'uart_transactions.jsonl').read_text(encoding='utf-8').splitlines()]
    board_stamps=set();errors=[];previous=None;sht_replies=set()
    for t in txs:
        request=bytes.fromhex(t['request_hex'])
        xor=0
        for byte in request[2:]:xor^=byte
        if len(request)!=12 or request[:2]!=b'\xa5\x5a' or xor:raise ValueError('request checksum/frame')
        if 'error' in t:errors.append(t)
        if 'response_hex' not in t:continue
        r=bytes.fromhex(t['response_hex']);xor=0
        for byte in r[2:]:xor^=byte
        if r[:2]!=b'\x5a\xa5' or len(r)!=10+r[4] or r[2]!=request[3] or xor:raise ValueError('response checksum/frame')
        ms=struct.unpack_from('<I',r,5)[0]
        if ms!=t['board_ms']:raise ValueError('saved board timestamp differs from raw reply')
        if previous is not None:age(ms,previous)
        previous=ms;board_stamps.add(ms)
        if request[2]==1 and request[4]==0x45 and request[5]==0 and request[6]==6 and r[3]==0:sht_replies.add(r[9:-1].hex())
    cycles=[json.loads(line) for line in (directory/'environment_cycles.jsonl').read_text(encoding='utf-8').splitlines()]
    valid=0
    for e in cycles:
        if not e['valid']:continue
        raw=bytes.fromhex(e['raw_hex'])
        if len(raw)!=6 or crc8(raw[:2])!=raw[2] or crc8(raw[3:5])!=raw[5]:raise ValueError('accepted SHT CRC invalid')
        if raw.hex() not in sht_replies or e['timestamp_ms'] not in board_stamps:raise ValueError('SHT is not supported by this UART session')
        if e['temperature_centi_c']!=-4500+(17500*int.from_bytes(raw[:2],'big')+32767)//65535:raise ValueError('SHT temperature conversion')
        if e['humidity_centi_percent']!=(10000*int.from_bytes(raw[3:5],'big')+32767)//65535:raise ValueError('SHT humidity conversion')
        if e['valid_flags']!=7 or e['error_bits'] or e['rc'] or e['get_rc'] or e['callback_error']:raise ValueError('SHT acceptance flags')
        valid+=1
    if len(cycles)!=report['sht_cycles'] or valid!=report['sht_valid']:raise ValueError('SHT summary mismatch')
    ee=read_u16(directory/'eeprom_u16_be.bin',832)
    pairs=sorted(directory.glob('pair_[0-9][0-9][0-9][0-9].json'))
    plausible=0;used=set();ages=[]
    for i,path in enumerate(pairs):
        event=json.loads(path.read_text(encoding='utf-8'))
        frames=[];details=[]
        for name in event['subpage_files']:
            if name in used:raise ValueError('measurement subpage reused')
            used.add(name);frame=read_u16(directory/name,834);frames.append(frame)
            detail=json.loads((directory/name.replace('_u16_be.bin','.json')).read_text(encoding='utf-8'))
            if detail['warmup']:raise ValueError('warmup entered measurement pair')
            for k in ('ready_observed_ms','clear_completed_ms','read_completed_ms','checked_completed_ms'):
                if detail[k] not in board_stamps:raise ValueError('thermal timestamp absent from raw replies')
            if detail['page']!=frame[833] or detail['control']!=frame[832]:raise ValueError('subpage metadata differs')
            details.append(detail)
        observed=age(details[-1]['checked_completed_ms'],details[0]['ready_observed_ms'])
        if observed!=event['observed_age_ms'] or observed>500:raise ValueError('accepted thermal timing mismatch')
        recalculated=calculator.pair(ee,frames)
        saved=json.loads((directory/f'temperature_{i:04d}.json').read_text(encoding='utf-8'))
        recalculated['plausibility']=assess_plausibility(recalculated)
        if recalculated!=saved:raise ValueError('official algorithm recalculation differs')
        if saved['valid_pixel_count']!=767 or saved['temperature_c'][620] is not None:raise ValueError('known bad pixel mishandled')
        if saved['plausibility']['status']=='PLAUSIBILITY_CHECK_PASSED':plausible+=1
        ages.append(observed)
    if len(pairs)!=report['pairs'] or plausible!=report['plausible_pairs']:raise ValueError('thermal summary mismatch')
    if report['result']=='PASS_STANDALONE_DUAL_SENSOR_SOAK' and (errors or report['transport_recoveries']):raise ValueError('error session presented as clean PASS')
    return dict(directory=directory.name,status='EVIDENCE_CONSISTENT',files_hash_checked=checked,uart_transactions=len(txs),uart_errors_preserved=len(errors),sht_valid=valid,sht_failed=len(cycles)-valid,thermal_pairs=len(pairs),algorithm_recalculations=len(pairs),plausible_pairs=plausible,observed_age_ms=[min(ages),max(ages)] if ages else None,acquisition_result=report['result'],full_requested_duration_completed=report['full_requested_duration_completed'] if 'full_requested_duration_completed' in report else False)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('directories',nargs='+',type=Path);p.add_argument('--report',type=Path)
    a=p.parse_args();calculator=Calculator()
    results=[audit(d,calculator) for d in a.directories]
    result=dict(scope='OFFLINE_AUDIT_OF_PRESERVED_REAL_HARDWARE_LOGS',hardware_accessed=False,status='PASS_EVIDENCE_AUDIT',sessions=results)
    if a.report:a.report.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
