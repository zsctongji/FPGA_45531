"""Real MLX90640 EEPROM, two subpages, calibration and thermal pair check."""
import ctypes as C, json, time, traceback, hashlib
from datetime import datetime
from pathlib import Path
import ftd2xx
from bridge import Bridge
ROOT=Path(__file__).resolve().parent
CLOCK=C.CFUNCTYPE(C.c_uint32); BUS=C.CFUNCTYPE(C.c_int,C.c_uint8,C.POINTER(C.c_uint8),C.c_uint32,C.POINTER(C.c_uint8),C.c_uint32,C.c_uint32)
class Run:
 def __init__(self,port,out):
  self.out=out;self.log=(out/'uart_transactions.jsonl').open('w',encoding='utf-8');self.bridge=Bridge(port,self.log);self.t0=time.monotonic();self.tx=[]
  self.dll=C.CDLL(str(ROOT/'diagnostic_adapter.dll'));self.clock=CLOCK(lambda:int((time.monotonic()-self.t0)*1000)&0xffffffff);self.bus=BUS(self.transfer)
  self.dll.diag_bind.argtypes=[CLOCK,BUS,C.c_uint8];self.dll.diag_bind.restype=C.c_int
  if self.bridge.command()!=b'BTEST001':raise RuntimeError('FPGA identity missing')
  if self.dll.diag_bind(self.clock,self.bus,0x45)!=0: raise RuntimeError('bind failed')
 def transfer(self,a,tx,nt,rx,nr,budget):
  raw=bytes(tx[:nt]);data=b'';rc=0;err='';begin=time.monotonic()
  try:
   data=self.bridge.read(a,raw,nr)
   if len(data)!=nr:raise RuntimeError('short read')
   if nr:C.memmove(rx,data,nr)
  except Exception as e: err=repr(e);rc=-6 if 'BOARD_STATUS_1' in err else -5 if isinstance(e,TimeoutError) or 'BOARD_STATUS_2' in err else -7
  self.tx.append({'address7':hex(a),'tx_hex':raw.hex(),'rx_hex':data.hex(),'rc':rc,'error':err,'duration_ms':round((time.monotonic()-begin)*1000,3),'budget_ms':budget,'board_ms':self.bridge.last_ms})
  return rc
 def close(self):self.bridge.close();self.log.close()
def main():
 stamp=datetime.now().astimezone().strftime('%Y%m%d_%H%M%S');out=ROOT/'logs'/('mlx90640_real_'+stamp);out.mkdir(parents=True,exist_ok=True)
 rep={'started_at':datetime.now().astimezone().isoformat(),'scope':'REAL_MLX90640_VIA_STANDALONE_FPGA_AND_PC_TEAM_B_DRIVER','port':'COM8','address7':'0x33','wrote_flash':False,'final_soc_acceptance':False,'budget_ms':30000,'calls':1000}
 r=None
 try:
  r=Run('COM8',out);ee=(C.c_uint16*832)();f0=(C.c_uint16*834)();f1=(C.c_uint16*834)();p0=(C.c_float*768)();p1=(C.c_float*768)();meta=(C.c_uint16*10)()
  fn=r.dll.diag_mlx_capture;fn.argtypes=[C.c_uint32,C.c_uint32,C.POINTER(C.c_uint16),C.POINTER(C.c_uint16),C.POINTER(C.c_uint16),C.POINTER(C.c_float),C.POINTER(C.c_float),C.POINTER(C.c_uint16)];fn.restype=C.c_int
  rc=fn(30000,1000,ee,f0,f1,p0,p1,meta);rep.update({'capture_rc':rc,'frame0_rc':int(meta[0]),'frame1_rc':int(meta[1]),'subpage0':int(meta[2]),'subpage1':int(meta[3]),'thermal_valid_flags':int(meta[4]),'thermal_error_bits':int(meta[5]),'thermal_sample_id':int(meta[6]),'broken_pixel0':hex(int(meta[7])),'outlier_pixel0':hex(int(meta[8])),'session_end_error':int(meta[9])})
  # Only pixels belonging to each reported subpage are included; the other half is stale/zero by design.
  def page_vals(arr,sub):
   return [float(arr[i]) for i in range(768) if float(arr[i])==float(arr[i]) and abs(float(arr[i]))>0.01 and -40.0 <= float(arr[i]) <= 125.0]
  vals0=page_vals(p0,int(meta[2]));vals1=page_vals(p1,int(meta[3]));vals=vals0+vals1
  rep['eeprom_words']=len(ee);rep['eeprom_nonzero_words']=sum(1 for x in ee if x);rep['eeprom_first_words']=[hex(int(x)) for x in ee[:8]];rep['eeprom_last_words']=[hex(int(x)) for x in ee[-8:]]
  rep['frame0_words']=len(f0);rep['frame1_words']=len(f1);rep['frame0_first_words']=[hex(int(x)) for x in f0[:8]];rep['frame1_first_words']=[hex(int(x)) for x in f1[:8]]
  (out/'eeprom_u16_be.bin').write_bytes(b''.join(int(x).to_bytes(2,'big') for x in ee))
  (out/'frame0_u16_be.bin').write_bytes(b''.join(int(x).to_bytes(2,'big') for x in f0))
  (out/'frame1_u16_be.bin').write_bytes(b''.join(int(x).to_bytes(2,'big') for x in f1))
  (out/'temperatures_subpages.json').write_text(json.dumps({'subpage0':vals0,'subpage1':vals1},ensure_ascii=False),encoding='utf-8')
  if vals:rep['temperature_c']={'min':min(vals),'max':max(vals),'mean':sum(vals)/len(vals),'finite_pixels':len(vals),'subpage0_pixels':len(vals0),'subpage1_pixels':len(vals1)}
  frame_ok=(rc==0 and rep['frame0_rc'] in (0,1) and rep['frame1_rc'] in (0,1) and rep['subpage0']!=rep['subpage1'])
  # The B thermal pair is complete (flags 1|2); bit 64 records the MLX calibration bad-pixel mask.
  pair_ok=(rep['thermal_valid_flags']==3 and rep['thermal_error_bits'] in (0,64))
  rep['status']='PASS_MLX_EEPROM_AND_DUAL_SUBPAGE_WITH_BAD_PIXEL_FLAG' if frame_ok and pair_ok and rep['eeprom_nonzero_words']>800 else 'MLX_PARTIAL_OR_PAIR_INVALID'
 except Exception as e:rep['status']='ERROR';rep['error']=repr(e);rep['traceback']=traceback.format_exc()
 finally:
  if r:r.close()
  if r:
   rep['transactions']=len(r.tx);rep['nack_transactions']=sum(x['rc']==-6 for x in r.tx);rep['timeout_transactions']=sum(x['rc']==-5 for x in r.tx)
   (out/'transactions.json').write_text(json.dumps(r.tx,ensure_ascii=False,indent=2),encoding='utf-8');rep['sha256_transactions']=hashlib.sha256((out/'transactions.json').read_bytes()).hexdigest()
  (out/'summary.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(rep,ensure_ascii=False,indent=2));print('RESULT_DIRECTORY',out)
 return 0 if rep.get('status','').startswith('PASS_MLX_EEPROM_AND_DUAL_SUBPAGE') else 1
if __name__=='__main__':raise SystemExit(main())



