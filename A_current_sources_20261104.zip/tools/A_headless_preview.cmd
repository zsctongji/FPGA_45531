@echo off
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0start_a_headless_preview.ps1" %*
pause
