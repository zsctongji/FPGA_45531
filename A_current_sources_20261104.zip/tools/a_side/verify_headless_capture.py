"""Offline evidence audit: independently check every raw packet and saved image.

Do not upgrade UART provenance to CPU/HDMI/Ethernet acceptance.
"""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import struct
from capture_headless import HEADER,ROOT
from check_capture import check
from measure_video import analyse

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def verify(folder,output=None):
    folder=Path(folder);raw=(folder/'raw.bin').read_bytes();offset=0;noise=0;leading_noise=0;packets_seen=0
    a2=[];parts={};headers={};complete_images={};counts=Counter()
    while offset+4<=len(raw):
        magic=raw[offset:offset+4]
        if magic not in (b'A2V1',b'A3V1'):
            offset+=1
            if packets_seen:noise+=1
            else:leading_noise+=1
            continue
        size=36 if magic==b'A2V1' else 300
        if offset+size>len(raw):break
        packet=raw[offset:offset+size]
        if sum(packet[:-4])!=int.from_bytes(packet[-4:],'little'):
            counts['bad_packet_sum']+=1;offset+=1;continue
        offset+=size
        packets_seen+=1
        if magic==b'A2V1':
            fid,stamp,w,h,valid,flags,debug,frames,malformed,drops=struct.unpack('<IIHHBBHIII',packet[4:32])
            a2.append((fid,stamp,w,h,valid,flags,debug,frames,malformed,drops));continue
        h=HEADER.unpack(packet[:40]);fid,stamp=h[1:3];index=h[12];key=(fid,stamp)
        if h[13:]!=(36,256,0) or index>=36:raise ValueError('A3 header length/index')
        template=h[:12]+h[13:]
        if key in headers and headers[key]!=template:raise ValueError('Mixed image metadata')
        headers[key]=template;parts.setdefault(key,{})
        if index in parts[key]:raise ValueError('Unexpected repeated UART image fragment')
        parts[key][index]=packet[40:296]
        if len(parts[key])==36:
            image=b''.join(parts[key][i] for i in range(36));complete_images[key]=(image,h)
            del parts[key]
    rows=list(csv.DictReader((folder/'frames.csv').open(encoding='utf-8-sig')))
    if len(rows)!=len(a2):raise ValueError('CSV/raw A2 record count')
    for row,p in zip(rows,a2):
        keys=('frame_id','timestamp_ms','width','height','complete','source_boundaries','malformed_frames','telemetry_drops')
        if tuple(int(row[k]) for k in keys)!=p[:5]+p[7:]:raise ValueError('CSV/raw A2 fields')
    seen=set();motion_frames=[];checksums=set();means=[]
    for file in sorted(folder.glob('frame_*.gray')):
        meta=json.loads(file.with_suffix('.json').read_text(encoding='utf-8'))
        image=file.read_bytes();check(image,meta);key=(meta['frame_id'],meta['timestamp_ms'])
        if key not in complete_images or image!=complete_images[key][0]:raise ValueError('Saved/raw image differs')
        h=complete_images[key][1]
        if (meta['checksum'],meta['changed_count'],meta['absolute_difference_sum'])!=h[3:6]:raise ValueError('Saved motion differs')
        box=list(h[6:10]) if h[10]&8 else None
        if meta['bbox_grid']!=box or meta['comparison_valid']!=bool(h[10]&2) or meta['motion']!=bool(h[10]&4):raise ValueError('Motion flags/bbox')
        if meta['source_frame_id'] is not None or meta['shared_soc_time'] or meta['cpu_read']:raise ValueError('Unsupported source/CPU claim')
        if meta['changed_count'] and meta['bbox_valid']:motion_frames.append(dict(file=str(file),frame=key[0],changed=meta['changed_count'],bbox=box))
        seen.add(key);checksums.add(meta['checksum']);means.append(meta['gray_mean'])
    if seen!=set(complete_images):raise ValueError('Unsaved complete image')
    measurement=analyse(rows)
    drops=[r[9] for r in a2];malformed=[r[8] for r in a2]
    clean=not noise and not counts and measurement['continuous_720p30_candidate'] and drops[0]==drops[-1] and malformed[0]==malformed[-1] and bool(seen)
    report=dict(status='PASS_BYTES_AND_HEADLESS_SOURCE' if clean else 'NEEDS_REVIEW',folder=str(folder.resolve()),
        source_measurement=measurement,source_records=len(a2),images=len(seen),unique_image_checksums=len(checksums),
        active_mean_range=[min(means),max(means)] if means else [],
        motion_snapshots=len(motion_frames),motion_examples=sorted(motion_frames,key=lambda m:m['changed'],reverse=True)[:5],
        raw_csv_and_images_match=True,interior_noise_bytes=noise,boundary_leading_bytes=leading_noise,packet_errors=dict(counts),
        boundary_partial_bytes=len(raw)-offset,boundary_incomplete_images=len(parts),
        source_telemetry_drops_delta=(drops[-1]-drops[0])&0xffffffff,
        source_malformed_delta=(malformed[-1]-malformed[0])&0xffffffff,
        observed_at_least_30min=measurement['seconds']>=1800,
        timer='separate local source/display milliseconds; not integrated SoC shared time',
        source_frame_mapping=False,cpu_read_verified=False,hdmi_verified=False,ethernet_verified=False,
        artifacts={p.name:digest(p) for p in [folder/'raw.bin',folder/'frames.csv',folder/'summary.json']})
    if output:Path(output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2));return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder');p.add_argument('--output')
    a=p.parse_args();verify(a.folder,a.output)
