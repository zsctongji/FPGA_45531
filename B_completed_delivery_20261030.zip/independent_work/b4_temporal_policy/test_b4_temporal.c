#include "b4_temporal_policy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); return 1; } } while (0)

static coop_environment_t sample(uint32_t ts, int32_t t, uint32_t h) {
    coop_environment_t s;
    memset(&s, 0, sizeof(s));
    s.abi_version = COOP_ABI_VERSION;
    s.timestamp_ms = ts;
    s.temperature_centi_c = t;
    s.humidity_centi_percent = h;
    s.valid_flags = COOP_SAMPLE_VALID;
    return s;
}

int main(void) {
    b4_temporal_config_t c; b4_temporal_state_t st; coop_environment_t s; uint32_t r;
    b4_temporal_config_default(&c); b4_temporal_reset(&st);
    s = sample(1000, 2275, 6910);
    CHECK(b4_temporal_accept_environment(&st, &s, 1100, &c, &r) == COOP_OK && r == 0);
    s = sample(2000, 2280, 6920);
    CHECK(b4_temporal_accept_environment(&st, &s, 2100, &c, &r) == COOP_OK);
    s.timestamp_ms = 2000;
    CHECK(b4_temporal_accept_environment(&st, &s, 2100, &c, &r) == COOP_ESTATE && (r & B4_TEMPORAL_REASON_STALE));
    s = sample(3000, 2275, 6910);
    CHECK(b4_temporal_accept_environment(&st, &s, 5201, &c, &r) == COOP_ETIMEOUT && (r & B4_TEMPORAL_REASON_TOO_OLD));
    s = sample(3000, 2275, 6910);
    CHECK(b4_temporal_accept_environment(&st, &s, 2900, &c, &r) == COOP_ETIMEOUT && (r & B4_TEMPORAL_REASON_FUTURE));
    s = sample(3000, 4000, 6910);
    CHECK(b4_temporal_accept_environment(&st, &s, 3050, &c, &r) == COOP_ESTATE && (r & B4_TEMPORAL_REASON_TEMP_STEP));
    s = sample(3000, 2275, 10000);
    CHECK(b4_temporal_accept_environment(&st, &s, 3050, &c, &r) == COOP_ESTATE && (r & B4_TEMPORAL_REASON_HUM_STEP));
    b4_temporal_reset(&st);
    s = sample(0xfffffff0u, 2275, 6910);
    CHECK(b4_temporal_accept_environment(&st, &s, 0xfffffff5u, &c, &r) == COOP_OK);
    s = sample(0x00000004u, 2276, 6911);
    CHECK(b4_temporal_accept_environment(&st, &s, 0x0000000au, &c, &r) == COOP_OK);
    s = sample(0x00000014u, 2276, 6911); s.error_bits = COOP_ERROR_CRC;
    CHECK(b4_temporal_accept_environment(&st, &s, 0x00000018u, &c, &r) == COOP_ESTATE && (r & B4_TEMPORAL_REASON_ERROR));
    b4_temporal_reset(&st);
    s = sample(100, 2275, 6910); s.valid_flags = COOP_SAMPLE_COMPLETE;
    CHECK(b4_temporal_accept_environment(&st, &s, 110, &c, &r) == COOP_ESTATE && (r & B4_TEMPORAL_REASON_FLAGS));
    printf("PASS B4 temporal policy: %u assertions; synthetic fixtures only\n", checks);
    return 0;
}

