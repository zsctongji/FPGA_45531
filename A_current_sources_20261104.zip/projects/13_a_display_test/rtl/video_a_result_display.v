// A's complete same-clock result display adapter. B/C supply a coherent status
// and a complete, stable thermal front buffer. There is no I2C/CPU/fusion here.
module video_a_result_display #(
    parameter WIDTH=1920,HEIGHT=1080,VISUAL_MAX_MS=500,THERMAL_MAX_MS=1000,ENVIRONMENT_MAX_MS=3000,
    UI_SCALE=1,DIAGNOSTIC_TEST=0
)(
    input wire clk,rst_n,in_hs,in_vs,in_de,
    input wire [23:0] in_rgb,
    input wire [31:0] now_ms,visual_timestamp_ms,thermal_timestamp_ms,environment_timestamp_ms,
    input wire [2:0] valid_mask,fault_mask,
    input wire [2:0] diagnostic_phase,
    input wire alarm_active,prediction_valid,
    input wire [7:0] person_score,event_score,event_type,
    input wire signed [15:0] temperature_centi,
    input wire [15:0] humidity_centi,
    input wire [6:0] prediction_x,prediction_y,
    input wire [31:0] status_frame_id,display_frame_id,
    input wire heat_pixel_valid,
    input wire [7:0] heat_level,
    output wire [9:0] heat_address,
    output wire heat_request,out_hs,out_vs,out_de,
    output wire [23:0] out_rgb,
    output wire [2:0] usable_mask,stale_mask,missing_mask
);
    wire [2:0] guard_usable;
    a_status_guard #(.VISUAL_MAX_MS(VISUAL_MAX_MS),.THERMAL_MAX_MS(THERMAL_MAX_MS),
        .ENVIRONMENT_MAX_MS(ENVIRONMENT_MAX_MS)) guard(
        .now_ms(now_ms),.visual_timestamp_ms(visual_timestamp_ms),.thermal_timestamp_ms(thermal_timestamp_ms),
        .environment_timestamp_ms(environment_timestamp_ms),.valid_mask(valid_mask),.fault_mask(fault_mask),
        .usable_mask(guard_usable),.stale_mask(stale_mask),.missing_mask(missing_mask));
    assign usable_mask=guard_usable&{humidity_centi<=10000,2'b11};
    wire [2:0] effective_usable=usable_mask;
    wire [2:0] effective_fault=fault_mask|{valid_mask[2]&&humidity_centi>10000,2'b00};
    video_status_overlay #(.FRAME_WIDTH(WIDTH),.FRAME_HEIGHT(HEIGHT),.STATUS_FLAGS(1),.UI_SCALE(UI_SCALE),.DIAGNOSTIC_TEST(DIAGNOSTIC_TEST)) display(
        .clk(clk),.rst_n(rst_n),.in_hs(in_hs),.in_vs(in_vs),.in_de(in_de),.in_rgb(in_rgb),
        .thermal_valid(effective_usable[1]),.environment_valid(effective_usable[2]),.ai_valid(effective_usable[0]),
        .diagnostic_phase(diagnostic_phase),
        .stale_mask(stale_mask|{2'b00,valid_mask[0]&&status_frame_id!=display_frame_id}),.fault_mask(effective_fault),
        .alarm_active(alarm_active),.prediction_valid(prediction_valid&&effective_usable[0]),
        .person_score(person_score),.event_score(event_score),.event_type(event_type),
        .temperature_centi(temperature_centi),.humidity_centi(humidity_centi),
        .prediction_x(prediction_x),.prediction_y(prediction_y),.status_frame_id(status_frame_id),.display_frame_id(display_frame_id),
        .heat_pixel_valid(heat_pixel_valid),.heat_level(heat_level),.heat_address(heat_address),.heat_request(heat_request),
        .out_hs(out_hs),.out_vs(out_vs),.out_de(out_de),.out_rgb(out_rgb));
endmodule
