"""Targeted failure/representation tests; all inputs here are synthetic."""
import copy
from pathlib import Path
import tempfile
import unittest

from build_dataset import age_ms, child, encode_grid, RECORD


def grid():
    return dict(width=32, height=24, temperature_c=[25.0]*768,
                pixel_reason=["VALID"]*768, pixel_valid_bits_hex="ff"*96)


class DatasetTests(unittest.TestCase):
    def test_wrap_and_future(self):
        self.assertEqual(age_ms(20, 0xfffffff0), 36)
        with self.assertRaises(ValueError): age_ms(19, 20)
        with self.assertRaises(ValueError): age_ms(True, 0)
        with self.assertRaises(ValueError): age_ms(0x100000000, 0)

    def test_bad_pixel_keeps_position_and_mask(self):
        source = grid()
        source["temperature_c"][620] = None
        source["pixel_reason"][620] = "EEPROM_BAD_PIXEL"
        mask = bytearray.fromhex(source["pixel_valid_bits_hex"])
        mask[620//8] &= ~(1 << (620%8))
        source["pixel_valid_bits_hex"] = mask.hex()
        before = copy.deepcopy(source)
        values, encoded = encode_grid(source)
        self.assertEqual(len(values), 768)
        self.assertEqual(values[619:622], [2500, 0, 2500])
        self.assertEqual(encoded, bytes(mask))
        self.assertEqual(source, before)

    def test_invalid_mask_and_nonfinite_rejected(self):
        for value in (float("nan"), float("inf"), True):
            source = grid(); source["temperature_c"][0] = value
            with self.assertRaises(ValueError): encode_grid(source)
        source = grid(); source["temperature_c"][620] = None
        with self.assertRaises(ValueError): encode_grid(source)

    def test_integer_range_rejected(self):
        source = grid(); source["temperature_c"][0] = 400.0
        with self.assertRaises(ValueError): encode_grid(source)

    def test_record_byte_layout(self):
        values, mask = encode_grid(grid())
        raw = RECORD.pack(123, 65536, 7, 100, 3, 64, *values, mask)
        self.assertEqual(len(raw), 1656)
        decoded = RECORD.unpack(raw)
        self.assertEqual(decoded[:6], (123, 65536, 7, 100, 3, 64))
        self.assertEqual(decoded[6:774], tuple(values))
        self.assertEqual(decoded[-1], mask)

    def test_input_cannot_escape_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.assertEqual(child(root, "pair_000.json"), root/"pair_000.json")
            with self.assertRaises(ValueError): child(root, "../escape.json")


if __name__ == "__main__": unittest.main(verbosity=2)
