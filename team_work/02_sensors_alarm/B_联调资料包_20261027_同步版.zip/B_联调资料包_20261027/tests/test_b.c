/* Synthetic host fixtures only. No hardware calibration/measurement evidence. */
#include "b_sensors.h"
#include "b_alarm.h"
#include "b_mlx_port.h"
#include "MLX90640_I2C_Driver.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); exit(1); } } while(0)
typedef struct {
    uint32_t now, advance, calls, commands, reads, gpio_calls, led, buzzer;
    uint32_t fail_call, fail_gpio_channel;
    int fail_code, gpio_error, not_ready;
    uint8_t packet[6];
    uint16_t last_reg, last_value;
} fake_t;
static uint32_t now_ms(void *p) { return ((fake_t *)p)->now; }
static int gpio(void *p, uint32_t channel, uint32_t active) {
    fake_t *f = p;
    ++f->gpio_calls;
    if (f->gpio_error && channel == f->fail_gpio_channel) return f->gpio_error;
    if (channel == C3_GPIO_ALARM_LED) f->led = active; else f->buzzer = active;
    return COOP_OK;
}
static int i2c(void *p, uint32_t bus, uint8_t address, const uint8_t *tx,
               uint32_t nt, uint8_t *rx, uint32_t nr, uint32_t timeout) {
    fake_t *f = p;
    uint32_t i;
    ++f->calls;
    CHECK(bus == 0 && timeout > 0 && timeout <= 20);
    f->now += f->advance;
    if (f->fail_code && (!f->fail_call || f->calls == f->fail_call)) return f->fail_code;
    if (address == 0x44 || address == 0x45) {
        if (nt) {
            CHECK(nt == 2 && tx[0] == 0x24 && tx[1] == 0 && nr == 0);
            ++f->commands;
        } else {
            CHECK(nr == 6); memcpy(rx, f->packet, 6); ++f->reads;
        }
    } else {
        uint16_t reg;
        CHECK(address == 0x33 && nt >= 2);
        reg = (uint16_t)(((uint16_t)tx[0] << 8) | tx[1]);
        f->last_reg = reg;
        if (nt == 4) { CHECK(!nr); f->last_value = (uint16_t)(((uint16_t)tx[2] << 8) | tx[3]); }
        else {
            CHECK(nt == 2 && nr <= 64 && (nr % 2) == 0);
            for (i = 0; i < nr / 2; ++i) {
                uint16_t value = (uint16_t)(reg + i);
                if (reg == MLX90640_STATUS_REG && f->not_ready) value = 0;
                rx[i * 2] = (uint8_t)(value >> 8); rx[i * 2 + 1] = (uint8_t)value;
            }
        }
    }
    return COOP_OK;
}
static c3_hal_t hal_for(fake_t *f) { c3_hal_t h = {f, now_ms, i2c, gpio}; return h; }
static void packet(fake_t *f, uint16_t t, uint16_t h) {
    f->packet[0] = (uint8_t)(t >> 8); f->packet[1] = (uint8_t)t;
    f->packet[2] = b_sht30_crc(f->packet, 2);
    f->packet[3] = (uint8_t)(h >> 8); f->packet[4] = (uint8_t)h;
    f->packet[5] = b_sht30_crc(f->packet + 3, 2);
}
static void sht_tests(void) {
    fake_t f = {0}; c3_hal_t h = hal_for(&f), absent = {0};
    b_sht30_t d; coop_environment_t out;
    uint8_t v[2] = {0xbe, 0xef};
    unsigned bit;
    CHECK(b_sht30_crc(v, 2) == 0x92);
    v[0] = v[1] = 0; CHECK(b_sht30_crc(v, 2) == 0x81);
    CHECK(b_sht30_init(&d, &h, 0x43) == COOP_EINVAL);
    CHECK(b_sht30_init(&d, &absent, 0x44) == COOP_ENOTSUP);
    CHECK(b_sht30_init(&d, &h, 0x44) == COOP_OK);
    packet(&f, 0, 0); CHECK(b_sht30_start(&d) == COOP_OK);
    CHECK(b_sht30_start(&d) == COOP_EBUSY);
    f.now = 15; CHECK(b_sht30_poll(&d) == COOP_EBUSY); CHECK(f.reads == 0);
    f.now = 16; CHECK(b_sht30_poll(&d) == COOP_OK);
    CHECK(b_sht30_get(&d, &out) == COOP_OK);
    CHECK(out.temperature_centi_c == -4500 && out.humidity_centi_percent == 0);
    CHECK(out.timestamp_ms == 16 && out.sample_id == 1 && out.valid_flags == 7 && out.error_bits == 0);
    f.now += COOP_ENV_MAX_LAG_MS; CHECK(b_sht30_get(&d, &out) == COOP_OK);
    ++f.now; CHECK(b_sht30_get(&d, &out) == COOP_ETIMEOUT && out.valid_flags == 0);
    packet(&f, 65535, 65535); CHECK(b_sht30_start(&d) == COOP_OK);
    CHECK(b_sht30_get(&d, &out) == COOP_ESTATE && out.valid_flags == 0);
    f.now += 16; CHECK(b_sht30_poll(&d) == COOP_OK);
    CHECK(b_sht30_get(&d, &out) == COOP_OK);
    CHECK(out.temperature_centi_c == 13000 && out.humidity_centi_percent == 10000);
    /* Each of 48 individual wire-bit corruptions must fail CRC (both words). */
    for (bit = 0; bit < 48; ++bit) {
        memset(&f, 0, sizeof(f)); CHECK(b_sht30_init(&d, &h, 0x45) == 0);
        packet(&f, 0xbeef, 0xbeef); f.packet[bit / 8] ^= (uint8_t)(1u << (bit % 8));
        CHECK(b_sht30_start(&d) == 0);
        f.now += 16; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
        CHECK(d.sample.valid_flags == 0 && d.sample.error_bits == COOP_ERROR_CRC);
        f.now += 5; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
        f.now += 16; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
        f.now += 5; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
        f.now += 16; CHECK(b_sht30_poll(&d) == COOP_EIO);
        CHECK(f.commands == 3 && f.reads == 3 && !d.state);
    }
    /* Recover a CRC error only after a new command/conversion. */
    memset(&f, 0, sizeof(f)); CHECK(b_sht30_init(&d, &h, 0x44) == 0);
    packet(&f, 32768, 32768); f.packet[2] ^= 1;
    CHECK(b_sht30_start(&d) == 0); f.now = 16; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
    f.now += 5; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
    packet(&f, 32768, 32768); f.now += 16; CHECK(b_sht30_poll(&d) == 0);
    CHECK(d.sample.error_bits == 0 && d.sample.valid_flags == 7);
    CHECK(d.sample.temperature_centi_c == 4250 && d.sample.humidity_centi_percent == 5000);
    /* NACK on command invalidates previous data. */
    f.fail_code = COOP_ENACK; CHECK(b_sht30_start(&d) == COOP_ENACK);
    CHECK(d.sample.error_bits == COOP_ERROR_NACK && d.sample.valid_flags == 0);
    f.fail_code = 0; CHECK(b_sht30_start(&d) == 0);
    f.now += 100; CHECK(b_sht30_poll(&d) == COOP_ETIMEOUT && d.sample.valid_flags == 0);
    /* I/O timeout and absolute timeout after a slow callback. */
    CHECK(b_sht30_start(&d) == 0); f.fail_code = COOP_ETIMEOUT;
    f.now += 16; CHECK(b_sht30_poll(&d) == COOP_EBUSY);
    CHECK(d.sample.error_bits == COOP_ERROR_TIMEOUT);
    f.now += 100; CHECK(b_sht30_poll(&d) == COOP_ETIMEOUT);
    f.fail_code = 0; CHECK(b_sht30_start(&d) == 0);
    f.now += 16; f.advance = 100; CHECK(b_sht30_poll(&d) == COOP_ETIMEOUT);
    f.advance = 0; f.now = UINT32_MAX - 8; CHECK(b_sht30_start(&d) == 0);
    f.now += 16; CHECK(b_sht30_poll(&d) == 0); CHECK(b_sht30_get(&d, &out) == 0);
    CHECK(out.timestamp_ms == 7);
    puts("PASS SHT30: CRC corruption, conversion, retries, deadlines, age, clock wrap");
}
static void thermal_tests(void) {
    fake_t f = {0}; c3_hal_t h = hal_for(&f);
    static b_thermal_pair_t d; static coop_thermal_t out;
    static float t[768]; uint8_t bad[96] = {0}; unsigned i, mode;
    for (mode = 0; mode < 2; ++mode) {
        CHECK(b_thermal_init(&d, &h) == 0);
        for (i = 0; i < 768; ++i) t[i] = (float)(i % 100) + 0.25f;
        CHECK(b_thermal_push(&d, 0, (uint8_t)mode, t, bad, 1) == COOP_EBUSY);
        CHECK(b_thermal_get(&d, &out) == COOP_ESTATE);
        f.now += 100; CHECK(b_thermal_push(&d, 0, (uint8_t)mode, t, bad, 1) == COOP_EBUSY);
        f.now += 100; CHECK(b_thermal_push(&d, 1, (uint8_t)mode, t, bad, 1) == 0);
        CHECK(b_thermal_get(&d, &out) == 0 && out.valid_flags == 7);
        for (i = 0; i < 768; ++i) {
            CHECK(out.temperature_centi_c[i] == (int16_t)((i % 100) * 100 + 25));
            CHECK((out.pixel_valid_bits[i / 8] & (1u << (i % 8))) != 0);
        }
        f.now += 401; CHECK(b_thermal_get(&d, &out) == COOP_ETIMEOUT);
    }
    CHECK(b_thermal_init(&d, &h) == 0);
    CHECK(b_thermal_push(&d, 0, 1, t, bad, 0) == COOP_ESTATE);
    CHECK(d.sample.error_bits == COOP_ERROR_CALIBRATION);
    CHECK(b_thermal_push(&d, 0, 1, t, bad, 1) == COOP_EBUSY);
    CHECK(b_thermal_push(&d, 1, 0, t, bad, 1) == COOP_ESTATE);
    CHECK(b_thermal_push(&d, 0, 1, t, bad, 1) == COOP_EBUSY);
    f.now += 501; CHECK(b_thermal_push(&d, 1, 1, t, bad, 1) == COOP_ESTATE);
    bad[0] = 1; t[1] = NAN; t[2] = INFINITY; t[3] = 500.0f;
    CHECK(b_thermal_push(&d, 0, 1, t, bad, 1) == COOP_EBUSY);
    CHECK(b_thermal_push(&d, 1, 1, t, bad, 1) == COOP_EIO);
    CHECK(d.sample.error_bits == COOP_ERROR_PIXEL_QUALITY && d.sample.valid_flags == 3);
    CHECK((d.sample.pixel_valid_bits[0] & 15u) == 0);
    b_thermal_fault(&d, COOP_ERROR_BUS); CHECK(d.sample.valid_flags == 0 && d.seen == 0);
    for (i = 0; i < 768; ++i) t[i] = -1.25f;
    memset(bad, 0, sizeof(bad)); f.now = UINT32_MAX - 4;
    CHECK(b_thermal_push(&d, 0, 1, t, bad, 1) == COOP_EBUSY);
    f.now += 10; CHECK(b_thermal_push(&d, 1, 1, t, bad, 1) == 0);
    CHECK(b_thermal_get(&d, &out) == 0 && out.temperature_centi_c[767] == -125);
    puts("PASS thermal: two modes, duplicate/missing pages, quality mask, calibration gate, wrap");
}
static void alarm_tests(void) {
    fake_t f = {0}; c3_hal_t h = hal_for(&f), absent = {0}; b_alarm_t d;
    f.led = f.buzzer = 1;
    CHECK(b_alarm_init(&d, &h, 2500) == 0 && !f.led && !f.buzzer);
    CHECK(b_alarm_request(&d, 1) == 0 && f.led && f.buzzer);
    f.now = 250; CHECK(b_alarm_poll(&d) == 0 && f.led && !f.buzzer);
    f.now = 1000; CHECK(b_alarm_poll(&d) == 0 && f.buzzer);
    CHECK(b_alarm_request(&d, 1) == 0 && d.started_ms == 0);
    f.now = 2500; CHECK(b_alarm_poll(&d) == COOP_ETIMEOUT && !f.led && !f.buzzer);
    CHECK(b_alarm_request(&d, 1) == COOP_ESTATE);
    CHECK(b_alarm_request(&d, 0) == 0);
    f.now = UINT32_MAX - 10; CHECK(b_alarm_request(&d, 1) == 0);
    f.now += 250; CHECK(b_alarm_poll(&d) == 0 && !f.buzzer);
    f.gpio_error = COOP_EIO; f.fail_gpio_channel = 1;
    f.now += 750; CHECK(b_alarm_poll(&d) == COOP_EIO && !f.led && d.inhibited);
    CHECK(d.buzzer == 2); CHECK(b_alarm_request(&d, 1) == COOP_ESTATE);
    f.gpio_error = 0; CHECK(b_alarm_request(&d, 0) == 0 && !f.buzzer);
    CHECK(b_alarm_init(&d, &absent, 1000) == COOP_ENOTSUP);
    CHECK(b_alarm_init(&d, &h, 0) == COOP_EINVAL);
    puts("PASS alarm: off initialization, pulse, clear/rearm, cutoff, GPIO failure, wrap");
}
static void mlx_tests(void) {
    fake_t f = {0}; c3_hal_t h = hal_for(&f), absent = {0};
    uint16_t data[832], frame[834] = {0}; unsigned i;
    CHECK(b_mlx_session_begin(&absent, 200, 100) == COOP_ENOTSUP);
    CHECK(b_mlx_session_begin(&h, 200, 100) == 0);
    CHECK(b_mlx_session_begin(&h, 200, 100) == COOP_EBUSY);
    CHECK(MLX90640_DumpEE(0x33, data) == 0);
    CHECK(f.calls == 26);
    for (i = 0; i < 832; ++i) CHECK(data[i] == 0x2400 + i);
    CHECK(MLX90640_I2CWrite(0x33, 0x800d, 0x1234) == 0);
    CHECK(f.last_reg == 0x800d && f.last_value == 0x1234);
    CHECK(b_mlx_session_end() == 0);
    memset(data, 0xff, sizeof(data)); f.fail_code = COOP_ENACK; f.fail_call = f.calls + 2;
    CHECK(b_mlx_session_begin(&h, 200, 100) == 0);
    CHECK(MLX90640_DumpEE(0x33, data) < 0);
    for (i = 0; i < 832; ++i) CHECK(data[i] == 0);
    CHECK(b_mlx_session_end() == COOP_ENACK);
    /* Actual official acquisition loop exits even when ready stays low and
     * the mock clock is frozen: the transaction budget is also finite. */
    f.fail_code = 0; f.not_ready = 1; f.calls = 0;
    CHECK(b_mlx_session_begin(&h, 200, 5) == 0);
    CHECK(MLX90640_GetFrameData(0x33, frame) < 0 && f.calls == 5);
    CHECK(b_mlx_session_end() == COOP_ETIMEOUT);
    f.advance = 10; f.now = UINT32_MAX - 4;
    CHECK(b_mlx_session_begin(&h, 20, 100) == 0);
    CHECK(MLX90640_GetFrameData(0x33, frame) < 0);
    CHECK(b_mlx_session_end() == COOP_ETIMEOUT);
    f.advance = 0;
    CHECK(b_mlx_session_begin(&h, 20, 100) == 0);
    CHECK(MLX90640_I2CGeneralReset() < 0);
    CHECK(b_mlx_session_end() == COOP_ENOTSUP);
    CHECK(MLX90640_I2CRead(0x33, 0x2400, 1, data) < 0);
    puts("PASS Melexis port: real library linked, EEPROM chunks/endian, NACK, finite polling");
}
int main(void) {
    sht_tests(); thermal_tests(); alarm_tests(); mlx_tests();
    printf("PASS %u host assertions; SYNTHETIC INPUTS, NO BOARD MEASUREMENTS\n", checks);
    return 0;
}
