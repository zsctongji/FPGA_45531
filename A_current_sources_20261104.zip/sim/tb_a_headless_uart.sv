`timescale 1ns/1ps
module tb_a_headless_uart;
    reg clk=0;always #5 clk=~clk;
    reg rst=0,vs=0,de=0,hs=0,done=0;
    wire tx,request;wire [15:0] address;wire [31:0] drops;
    reg [7:0] data=0;
    always @(posedge clk)begin data<=address[7:0];done<=request;end
    a_headless_uart #(.CLK_HZ(1000000),.BAUD(100000),.SNAPSHOT_MS(1),.WIDTH(8),.HEIGHT(3)) dut(
        .clk(clk),.rst_n(rst),.in_vs(vs),.in_de(de),.in_hs(hs),.raw_debug(16'h1234),
        .config_snapshot(128'b0),.config_valid(1'b0),.image_done(done),.image_data(data),
        .image_id(32'h11223344),.image_time(32'd123),.image_sum(32'd1175040),
        .image_changed(32'd32),.image_difference(32'd1000),.image_min_x(16'd1),.image_min_y(16'd2),
        .image_max_x(16'd10),.image_max_y(16'd20),.image_flags(8'd15),
        .image_request(request),.image_address(address),.tx(tx),.telemetry_drops(drops));
    task tick;begin @(posedge clk);#1;end endtask
    task frame;begin
        @(negedge clk);vs=0;
        for(integer y=0;y<3;y++)begin
            @(negedge clk);de=1;hs=1;tick();tick();
            @(negedge clk);de=0;hs=0;repeat(3)tick();
        end
        @(negedge clk);vs=1;repeat(4)tick();
    end endtask
    initial begin repeat(3)tick();@(negedge clk);rst=1;vs=1;repeat(4)tick();
        forever begin frame();repeat(99000)tick();end
    end
    reg [7:0] bytes[0:299];integer n,b,size,chunks=0,a2=0;reg [31:0] sum,actual;
    task byte_rx(output reg [7:0] val);begin
        @(negedge tx);repeat(15)@(posedge clk);#1;
        for(integer j=0;j<8;j++)begin val[j]=tx;repeat(10)@(posedge clk);#1;end
        if(tx!==1)$fatal(1,"stop");
    end endtask
    initial begin
        wait(rst);
        while(chunks<36)begin
            for(n=0;n<4;n++)byte_rx(bytes[n]);
            if({bytes[3],bytes[2],bytes[1],bytes[0]}==32'h31563241)size=36;
            else if({bytes[3],bytes[2],bytes[1],bytes[0]}==32'h31563341)size=300;
            else $fatal(1,"interleaved packet magic");
            for(n=4;n<size;n++)byte_rx(bytes[n]);
            sum=0;for(n=0;n<size-4;n++)sum=sum+bytes[n];
            actual={bytes[size-1],bytes[size-2],bytes[size-3],bytes[size-4]};
            if(sum!==actual)$fatal(1,"packet SUM32");
            if(size==300)begin
                if(bytes[4]!=8'h44||bytes[34]!=chunks||bytes[35]!=36||bytes[32]!=15||bytes[33]!=1)
                    $fatal(1,"snapshot header");
                for(n=0;n<256;n++)if(bytes[40+n]!==n[7:0])$fatal(1,"synchronous RAM streaming %d %d",n,bytes[40+n]);
                chunks++;
            end else begin
                if(bytes[12]!=8||bytes[14]!=3||bytes[16]!=1)$fatal(1,"A2 geometry");a2++;
            end
        end
        if(drops!=0||a2<10)$fatal(1,"A2 starvation %d %d",drops,a2);
        $display("PASS tb_a_headless_uart 36 chunks, 9216 bytes, SUM32, interleaved A2, zero drops");$finish;
    end
    initial begin #30000000;$fatal(1,"timeout");end
endmodule
