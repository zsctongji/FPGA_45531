#ifndef B4_TEMPORAL_POLICY_H
#define B4_TEMPORAL_POLICY_H
#include "cooperation_v1.h"
#include <stdint.h>

typedef struct {
    uint32_t max_age_ms;
    int32_t max_temperature_step_centi_c;
    uint32_t max_humidity_step_centi_percent;
} b4_temporal_config_t;

typedef struct {
    uint8_t initialized;
    uint32_t last_timestamp_ms;
    int32_t last_temperature_centi_c;
    uint32_t last_humidity_centi_percent;
} b4_temporal_state_t;

#define B4_TEMPORAL_REASON_FLAGS       0x00000001u
#define B4_TEMPORAL_REASON_ERROR       0x00000002u
#define B4_TEMPORAL_REASON_FUTURE      0x00000004u
#define B4_TEMPORAL_REASON_TOO_OLD     0x00000008u
#define B4_TEMPORAL_REASON_STALE       0x00000010u
#define B4_TEMPORAL_REASON_TEMP_STEP  0x00000020u
#define B4_TEMPORAL_REASON_HUM_STEP   0x00000040u

void b4_temporal_config_default(b4_temporal_config_t *config);
void b4_temporal_reset(b4_temporal_state_t *state);
/* Accepts only a complete, error-free sample. `now_ms` and sample timestamps
 * are compared with modulo-2^32 arithmetic; intervals >= 2^31 are invalid. */
int b4_temporal_accept_environment(b4_temporal_state_t *state,
                                   const coop_environment_t *sample,
                                   uint32_t now_ms,
                                   const b4_temporal_config_t *config,
                                   uint32_t *reason_bits);

#endif
