`timescale 1ns/1ps
module tb_camera_input_uart #(parameter DATA_VS_HIGH=0,HAS_CONFIG=0);
    reg clk=0;always #5 clk=~clk;
    reg rst_n=0,vs=0,de=0,hs=0;
    wire tx;wire [31:0] drops;
    camera_input_uart #(.CLK_HZ(1000000),.BAUD(100000),.WIDTH(8),.HEIGHT(3)) dut(
        .clk(clk),.rst_n(rst_n),.in_vs(vs),.in_de(de),.in_hs(hs),.raw_debug(16'h1234),
        .config_snapshot(128'h2f2e2d2c2b2a29282726252423222120),.config_valid(HAS_CONFIG!=0),
        .tx(tx),.telemetry_drops(drops));
    task tick;begin @(posedge clk);#1;end endtask
    task boundary;begin @(negedge clk);vs=!DATA_VS_HIGH;de=0;tick();end endtask
    task line(input integer beats);integer i;begin
        @(negedge clk);vs=DATA_VS_HIGH;de=1;hs=1;
        for(i=0;i<beats;i=i+1)begin
            tick();
            if(i+1<beats)begin
                @(negedge clk);de=0;tick();tick(); // CSI payload bubbles within HS
                @(negedge clk);de=1;
            end
        end
        @(negedge clk);de=0;hs=0;tick();
    end endtask
    reg [7:0] bytes[0:35];
    integer n,b,k,received=0;reg [31:0] sum,wire_sum;
    initial begin
        wait(rst_n);
        for(k=0;k<2;k=k+1)begin
            for(n=0;n<36;n=n+1)begin
                @(negedge tx);repeat(15)@(posedge clk);#1;
                for(b=0;b<8;b=b+1)begin
                    bytes[n][b]=tx;
                    repeat(10)@(posedge clk);#1;
                end
                if(tx!==1)$fatal(1,"UART stop bit");
            end
            if({bytes[3],bytes[2],bytes[1],bytes[0]}!==32'h31563241)$fatal(1,"magic");
            if(bytes[4]!==k*2 || bytes[12]!==8 || bytes[14]!==3 || bytes[16]!==1 || bytes[17]!==(DATA_VS_HIGH*2+HAS_CONFIG*4))
                $fatal(1,"frame/geometry/flag metadata");
            if(HAS_CONFIG)begin
                if(bytes[18]!==(8'h20+k*2) || bytes[19]!==k*2)$fatal(1,"config snapshot/index endian");
            end else if(bytes[18]!==8'h34 || bytes[19]!==8'h12)$fatal(1,"debug endian");
            sum=0;for(n=0;n<32;n=n+1)sum=sum+bytes[n];
            wire_sum={bytes[35],bytes[34],bytes[33],bytes[32]};
            if(sum!==wire_sum)$fatal(1,"SUM32");
            if(bytes[28]!==k || bytes[24]!==k)$fatal(1,"drop/malformed counters");
            received=received+1;
        end
        $display("PASS tb_camera_input_uart: real 8N1 decode, endian/checksum, busy drop and recovery");
        $finish;
    end
    initial begin
        tick();@(negedge clk);rst_n=1;boundary();line(2);line(2);line(2);boundary();
        // First frame learns actual VS polarity; only following complete frames publish.
        line(2);line(2);line(2);boundary();
        // Malformed second frame arrives while UART is busy: count, never stall.
        line(1);line(2);line(2);boundary();
        wait(received==1);repeat(20)tick();line(2);line(2);line(2);boundary();
    end
    initial begin #2000000;$fatal(1,"timeout");end
endmodule
