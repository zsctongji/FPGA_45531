@echo off
echo UDP 39003. Open http://127.0.0.1:39004. Ctrl+C stops recording.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_a_side.ps1" -Mode Receive
pause
