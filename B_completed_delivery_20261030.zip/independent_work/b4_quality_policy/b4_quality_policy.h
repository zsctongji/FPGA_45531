#ifndef B4_QUALITY_POLICY_H
#define B4_QUALITY_POLICY_H
#include "cooperation_v1.h"
#include <stdint.h>

/* B4 policy is a non-mutating gate before fusion. It preserves the original
 * sample and validity mask; it never fills or interpolates an invalid pixel. */
typedef struct {
    int32_t env_temp_min_centi_c;
    int32_t env_temp_max_centi_c;
    uint32_t env_humidity_min_centi_percent;
    uint32_t env_humidity_max_centi_percent;
    int32_t thermal_temp_min_centi_c;
    int32_t thermal_temp_max_centi_c;
    uint16_t thermal_min_valid_pixels;
} b4_quality_policy_t;

#define B4_QUALITY_REASON_FLAGS       0x00000001u
#define B4_QUALITY_REASON_ERROR      0x00000002u
#define B4_QUALITY_REASON_RANGE      0x00000004u
#define B4_QUALITY_REASON_TOO_FEW    0x00000008u
#define B4_QUALITY_REASON_BAD_PIXEL  0x00000010u

void b4_quality_policy_default(b4_quality_policy_t *policy);
int b4_quality_environment(const coop_environment_t *sample,
                           const b4_quality_policy_t *policy,
                           uint32_t *reason_bits);
/* Thermal result is usable when enough pixels are valid. A factory-marked
 * pixel may be invalid and is reported in reason_bits, while remaining
 * invalid in sample->pixel_valid_bits. */
int b4_quality_thermal(const coop_thermal_t *sample,
                       const b4_quality_policy_t *policy,
                       uint16_t *valid_pixels,
                       uint32_t *reason_bits);

#endif
