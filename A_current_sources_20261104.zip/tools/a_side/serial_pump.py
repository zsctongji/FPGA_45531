"""Dedicated bounded serial reader: disk/image work never delays port draining."""
from collections import Counter
import ctypes
import os
import queue
import threading

class SerialPump:
    def __init__(self,uart,max_chunks=2048):
        self.uart=uart;self.queue=queue.Queue(maxsize=max_chunks)
        self.stop=threading.Event();self.error=None;self.stats=Counter()
        self.thread=threading.Thread(target=self._run,name='A UART reader',daemon=True)
        # Windows pyserial opens a small default queue. Ask the driver for 1 MiB
        # before starting the reader; retain the actual API success/failure.
        self.stats['requested_driver_rx_bytes']=1048576
        if hasattr(uart,'set_buffer_size'):
            uart.set_buffer_size(rx_size=1048576,tx_size=4096)
            self.stats['driver_setup_succeeded']=1
        self.flags=None
        if os.name=='nt' and hasattr(uart,'_port_handle'):
            from serial import win32
            self.flags=win32

    def _run(self):
        try:
            while not self.stop.is_set():
                if self.flags:
                    w=self.flags;flags=w.DWORD();status=w.COMSTAT()
                    if not w.ClearCommError(self.uart._port_handle,ctypes.byref(flags),ctypes.byref(status)):
                        raise OSError('Win32 serial status read failed')
                    if flags.value:self.stats[f'win32_error_flags_0x{flags.value:X}']+=1
                    self.stats['max_driver_queued_bytes']=max(self.stats['max_driver_queued_bytes'],status.cbInQue)
                data=self.uart.read(2048)
                if data:
                    self.stats['bytes_read']+=len(data)
                    try:self.queue.put_nowait(data)
                    except queue.Full:raise BufferError('Host image processing queue full; no bytes silently discarded')
                    self.stats['max_pending_chunks']=max(self.stats['max_pending_chunks'],self.queue.qsize())
        except Exception as exc:
            if not self.stop.is_set():self.error=exc

    def __enter__(self):self.thread.start();return self
    def read(self,timeout=.1):
        if self.error:raise self.error
        try:return self.queue.get(timeout=timeout)
        except queue.Empty:
            if self.error:raise self.error
            return b''
    def __exit__(self,*args):
        self.stop.set()
        if hasattr(self.uart,'cancel_read'):self.uart.cancel_read()
        self.thread.join(timeout=2)
        if self.thread.is_alive():raise RuntimeError('Serial reader did not stop')
