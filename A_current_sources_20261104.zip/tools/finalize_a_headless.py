"""Qualify headless A2/A3 evidence against actual source, bitstream and JTAG."""
from pathlib import Path
import argparse
import csv
from datetime import datetime,timezone
import hashlib
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools/a_side'))
from verify_headless_capture import verify

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--jtag',required=True)
    p.add_argument('--display',action='store_true');a=p.parse_args()
    folder=ROOT/('logs/a_side/headless/20261029_display_stability_30min' if a.display else 'logs/a_side/headless/20261029_stability_rx_fixed')
    audit=verify(folder,ROOT/'logs/a_headless_stability_audit_20261029.json')
    capture=read(folder/'summary.json')
    if audit['status']!='PASS_BYTES_AND_HEADLESS_SOURCE' or not audit['observed_at_least_30min']:
        raise ValueError('Complete clean 30-minute run required')
    if any(k.startswith('win32_error_flags_') and v for k,v in capture['serial_reader'].items()):
        raise ValueError('Observed serial driver error flags')
    release=read(ROOT/('logs/a_display_test_release.json' if a.display else 'logs/a_headless_release.json'));build=read(release['compile_record'])
    if build['status']!='PASS' or sha(release['bitstream'])!=release['sha256']:raise ValueError('Release/compile/hash')
    for filename,digest in release['sources'].items():
        if sha(ROOT/filename)!=digest:raise ValueError('Source changed: '+filename)
    jtag=read(a.jtag)
    if jtag['idcode']!='0x10660A79' or jtag['usercode']!=release['usercode']:raise ValueError('Wrong actual FPGA image')
    config=jtag['configuration']
    if not all(config[k]==1 for k in ['IN_USER','CDONE','NSTATUS','CONFIG_END']):raise ValueError('FPGA configuration not ready')
    if any(config[k] for k in ['CRC32_ERROR_CORE','CRC32_ERROR_PERIPH','SEU_ERROR']):raise ValueError('FPGA CRC/SEU')
    regs={}
    for row in csv.DictReader((folder/'frames.csv').open(encoding='utf-8-sig')):
        if row['camera_register_address']:regs[int(row['camera_register_address'])]=int(row['camera_register_value'])
    expected={0x3107:0xcd,0x3108:0x6b,0x3208:0x07,0x3209:0x80,0x320a:0x04,0x320b:0x38,
              0x320e:0x05,0x320f:0xd2,0x3e00:0,0x3e01:0x7d,0x3e02:0}
    if any(regs.get(k)!=v for k,v in expected.items()):raise ValueError('Actual camera register readback differs')
    tests=read(ROOT/'logs/a_side_selftest.json')
    if tests['status']!='PASS':raise ValueError('A regression tests')
    for name,digest in tests['source_sha256'].items():
        if sha(ROOT/name)!=digest:raise ValueError('Post-test source changed: '+name)
    for filename in ['a_firmware_host.json','a_side_firmware.json','a_side_synthesis.json','a_real_inputs_replay.json','a_udp_stress_20261029.json']:
        if read(ROOT/'logs'/filename)['status']!='PASS':raise ValueError(filename)
    samples=read(ROOT/'team_work/01_video/ai_samples_20261029/MANIFEST.json')
    for sample in samples['samples']:
        for filename,digest in sample['files'].items():
            if sha(ROOT/'team_work/01_video/ai_samples_20261029'/filename)!=digest:raise ValueError('Sample hash')
    report=dict(status='PASS_A2_A3_HEADLESS_ON_BOARD',checked_utc=datetime.now(timezone.utc).isoformat(),
        a_independent_headless_scope_complete=True,all_A_acceptance_complete=False,
        bitstream=release['bitstream'],bitstream_sha256=release['sha256'],jtag=str(Path(a.jtag).resolve()),
        source_tap='CSI output before DDR, i_mipi_rx_pclk 50 MHz, four pixels per valid beat',
        gray_tap='DDR read / debayer / preprocess_r, 148.5 MHz, before motion overlay',
        source_measurement={**audit['source_measurement'],'evidence':'hardware_CSI_input_verified',
            'note':'Qualified by actual diagnostic bit/source hashes, raw audit, scene response and JTAG; separate local timer.'},images=audit['images'],
        full_raw_csv_and_image_audit=str(ROOT/'logs/a_headless_stability_audit_20261029.json'),
        serial_reader=capture['serial_reader'],camera_registers={f'0x{k:04X}':f'0x{v:02X}' for k,v in sorted(regs.items())},
        scene_user_confirmed=True,visible_object_reviewed_display_frame=71760,
        scene_examples=[{k:s[k] for k in ['label','display_frame_id','checksum','changed_count','bbox_grid']} for s in samples['samples']],
        actual_fpga_final_sta=release['final_sta'],
        display_exercise_active=a.display,
        hdmi_test_observation=read(ROOT/'logs/a_display_hdmi_acceptance_20261029.json') if a.display else None,
        caveats=['Independent A diagnostic, not final integrated SoC','Separate local timers, not SoC shared milliseconds',
            'Display IDs are not mapped to CSI source IDs','CSI transport error port is not qualified',
            'Motion bbox is threshold change region, not an AI person bbox'],
        pending=['Combined current B/C real-data HDMI display/video acceptance',
            'C source-ID/shared-time transfer with DDR banks and actual CPU acquire/read/release/inference',
            'B/C live thermal/environment/fusion and prediction connection',
            'B Ethernet sender/C SoC integration and actual event/image network closure'],
        previous_failed_run=str(ROOT/'logs/a_side/headless/20261029_stability_30min/summary.json'),
        receiver_fix='Dedicated serial reader, 1 MiB driver receive queue, bounded 4 MiB application queue; same FPGA image',
        flash_modified=False)
    (ROOT/'logs/a_headless_validation_20261029.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
