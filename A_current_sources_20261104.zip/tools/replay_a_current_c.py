"""Replay saved A frames through the pinned current C RTL; no serial/JTAG/network.

Reuse C's reviewed real-data test generator. Keep all generated files in a
separate offline directory and retain original display-domain provenance.
"""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--archive',type=Path,required=True)
    args=ap.parse_args()
    args.repo=args.repo.resolve();args.archive=args.archive.resolve()
    with zipfile.ZipFile(args.archive) as z:commit=z.comment.decode()
    if commit!='6c11cca8ca6cabf2d580334618434c8fd0877454':raise ValueError('Re-review C before changing pinned commit')
    out=args.repo/'build/a_current_c_20261103';out.mkdir(parents=True,exist_ok=True)
    spec=importlib.util.spec_from_file_location('current_c_replay',args.repo/'tools/replay_team_real_data.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.BUILD=out
    iv=ROOT/'tools/iverilog/bin/iverilog.exe';vvp=iv.with_name('vvp.exe')
    def run(command,cwd=mod.ROOT,timeout=90):
        command=[str(x) for x in command]
        if command[0].endswith('iverilog.exe'):command[0]=str(iv)
        p=subprocess.run(command,cwd=cwd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
        if p.returncode:raise RuntimeError(p.stdout+p.stderr)
        return p.stdout+p.stderr
    mod.run=run
    report=dict(status='RUNNING',checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        remote_commit=commit,archive_sha256=sha(args.archive),hardware_accessed=False,source_sha256={},samples=[],
        scope='saved display-domain A pixels -> C A mailbox -> DDR behavioral model -> synthetic CPU AXI readback',
        physical_csi_tested=False,shared_time_verified=False,board_cpu_inference=False,ethernet_verified=False)
    _,exe=mod.bench(report)
    folder=ROOT/'team_work/01_video/ai_samples_20261029'
    manifest=json.loads((folder/'MANIFEST.json').read_text(encoding='utf-8'))
    for sample in manifest['samples']:
        label=sample['label'];case=out/label;case.mkdir(exist_ok=True)
        for name,digest in sample['files'].items():
            if sha(folder/name)!=digest:raise ValueError('Sample manifest: '+name)
        raw=(folder/(label+'.gray')).read_bytes();meta=json.loads((folder/(label+'.json')).read_text())
        sys.path.insert(0,str(ROOT/'tools/a_side'))
        from check_capture import check
        check(raw,meta)
        (case/'input.hex').write_text(''.join(f'{b:02x}\n' for b in raw),encoding='ascii')
        log=run([vvp,exe,'+SEED=12345'],cwd=case,timeout=180)
        (case/'simulation.log').write_text(log,encoding='utf-8')
        ddr=(case/'ddr.gray').read_bytes();cpu=(case/'cpu.gray').read_bytes()
        if 'PASS tb_c2_real_a ' not in log or raw!=ddr or raw!=cpu:raise ValueError('C byte transport mismatch: '+label)
        item=dict(label=label,source_metadata=meta,bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),
            cpu_sha256=hashlib.sha256(cpu).hexdigest(),sum32=sum(raw),fnv1a=mod.fnv(raw),
            int8_input_fnv1a=mod.fnv(bytes((b-128)&255 for b in cpu)),status='PASS',
            replay_frame_id_time='synthetic bench values; original provenance above unchanged')
        report['samples'].append(item);print('PASS current C transport '+label,flush=True)
    report['status']='PASS_OFFLINE_CURRENT_C_BYTES'
    report['source_sha256']['tools/replay_a_current_c.py']=sha(Path(__file__))
    target=ROOT/'logs/a_current_c_replay_20261103.json'
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(str(target))
if __name__=='__main__':main()
