`timescale 1ns/1ps
module tb_bridge;
reg clk=0;always #10 clk=~clk;reg key0=1,locked=0,uart_rx=1;
wire uart_tx,oe1,oe2;tri1 scl,sda;assign scl=oe1?1'b0:1'bz;assign sda=oe2?1'b0:1'bz;
B_sensor_test dut(.key_i({3'b111,key0}),.sys_pll_LOCKED(locked),.clk_sel(0),.clk_50m(clk),.clk_54m(0),.clk_25m_x2(0),.osc_clk(0),.uart_rx(uart_rx),.uart_tx(uart_tx),.sensor_scl_in(scl),.sensor_sda_in(sda),.sensor_scl_oe(oe1),.sensor_sda_oe(oe2));
localparam BIT=8680;
task send;input [7:0] v;integer i;begin uart_rx=0;#BIT;for(i=0;i<8;i=i+1)begin uart_rx=v[i];#BIT;end uart_rx=1;#BIT;end endtask
reg [7:0] out [0:63];integer n=0,i;reg [7:0] v;
always begin @(negedge uart_tx);#(BIT+BIT/2);for(i=0;i<8;i=i+1)begin v[i]=uart_tx;#BIT;end if(uart_tx!==1)$fatal(1,"bad TX stop");out[n]=v;n=n+1;end
initial begin #200;locked=1;#2000;
 // Identify op=0 seq=7, remaining fields zero. XOR is7.
 send(8'ha5);send(8'h5a);send(0);send(7);send(0);send(0);send(0);send(0);send(0);send(0);send(0);send(7);
 wait(n==18);#BIT;
 if(out[0]!=8'h5a||out[1]!=8'ha5||out[2]!=7||out[3]!=0||out[4]!=8)$fatal(1,"response header");
 if({out[9],out[10],out[11],out[12],out[13],out[14],out[15],out[16]}!="BTEST001")$fatal(1,"identity payload");
 $display("PASS: UART command parsing, identify response, board identity payload");$finish;
end
initial begin #10000000;$fatal(1,"bridge bench timeout");end
endmodule
