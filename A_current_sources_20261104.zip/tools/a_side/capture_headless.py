"""Read A2V1 + A3V1 from the A-only image diagnostic (921600 baud).

A3 IDs/time describe the display-side DDR read stream, not CSI source frames.
No CPU inference, HDMI observation or Ethernet claim is inferred from UART.
"""
import argparse
from collections import Counter
import csv
from datetime import datetime
import json
from pathlib import Path
import struct
import sys
import time
from capture_camera_input import Decoder as A2Decoder, detect_port, ROOT
from check_capture import check
from measure_video import analyse
from serial_pump import SerialPump

HEADER=struct.Struct('<4sIIIIIHHHHBBBBHH')
assert HEADER.size==40

class Decoder:
    def __init__(self):
        self.buffer=bytearray();self.stats=Counter();self.a2=A2Decoder()
        self.current=None;self.parts={};self.template=None

    def feed(self,data):
        self.buffer.extend(data);records=[];images=[]
        while len(self.buffer)>=4:
            positions=[p for magic in (b'A2V1',b'A2D1',b'A3V1') if (p:=self.buffer.find(magic))>=0]
            if not positions:
                self.stats['noise_bytes']+=len(self.buffer)-3;del self.buffer[:-3];break
            pos=min(positions)
            if pos:self.stats['noise_bytes']+=pos;del self.buffer[:pos]
            is_image=self.buffer[:4]==b'A3V1';size=300 if is_image else (48 if self.buffer[:4]==b'A2D1' else 36)
            if len(self.buffer)<size:break
            packet=bytes(self.buffer[:size])
            if sum(packet[:-4])!=int.from_bytes(packet[-4:],'little'):
                self.stats['bad_sum']+=1;del self.buffer[0];continue
            del self.buffer[:size]
            if not is_image:records.extend(self.a2.feed(packet));continue
            h=HEADER.unpack(packet[:40])
            _,fid,ms,checksum,changed,diff,x0,y0,x1,y1,flags,tap,part,total,length,reserved=h
            if (flags&~15 or not flags&1 or tap!=1 or total!=36 or part>=36 or length!=256 or reserved
                or changed>5184 or (flags&8 and not(0<=x0<=x1<96 and 0<=y0<=y1<54))):
                self.stats['bad_header']+=1;continue
            template=h[:12]+h[13:]
            key=(fid,ms)
            if self.current!=key:
                if self.parts:self.stats['incomplete_images']+=1
                self.current=key;self.parts={};self.template=template
            if template!=self.template:
                self.stats['metadata_mismatch']+=1;self.parts={};self.template=None;continue
            if part in self.parts:self.stats['duplicate_parts']+=1
            self.parts[part]=packet[40:296]
            if len(self.parts)==36:
                raw=b''.join(self.parts[i] for i in range(36));self.parts={}
                meta=dict(frame_id=fid,timestamp_ms=ms,checksum=checksum,evidence='hardware',
                    tap='display_gray_after_DDR_before_motion_overlay',source_frame_id=None,
                    clock='local_148500000Hz_display_ms',shared_soc_time=False,
                    width=96,height=96,active_width=96,active_height=54,pad_top=21,pad_bottom=21,
                    comparison_valid=bool(flags&2),motion=bool(flags&4),bbox_valid=bool(flags&8),
                    changed_count=changed,absolute_difference_sum=diff,
                    bbox_grid=[x0,y0,x1,y1] if flags&8 else None,
                    transport='USB_UART_not_Ethernet',cpu_read=False,physical_scene_reviewed=False)
                try:check(raw,meta)
                except ValueError:self.stats['bad_image']+=1;continue
                active=raw[2016:7200]
                meta.update(gray_min=min(active),gray_max=max(active),gray_mean=sum(active)/5184,
                            nonzero_active=sum(v!=0 for v in active))
                images.append((raw,meta));self.stats['images']+=1
        return records,images

def bmp(raw):
    # 24-bit BMP, gray converted byte-exactly for any standard image viewer.
    pixels=b''.join(bytes(c for v in raw[y*96:(y+1)*96] for c in (v,v,v)) for y in range(95,-1,-1))
    return (b'BM'+struct.pack('<IHHI',54+len(pixels),0,0,54)+
            struct.pack('<IiiHHIIiiII',40,96,96,1,24,0,len(pixels),0,0,0,0)+pixels)

def capture(port=None,seconds=65,output=None,expected_usercode='0x41335631'):
    if seconds<=0:raise ValueError('seconds must be positive')
    sys.path.append(str(ROOT/'tools/efinity/2026.1/python311/Lib/site-packages'))
    import serial
    port=port or detect_port()
    output=Path(output) if output else ROOT/'logs/a_side/headless'/datetime.now().strftime('%Y%m%d_%H%M%S')
    output.mkdir(parents=True,exist_ok=False)
    d=Decoder();rows=[];metas=[];start=time.monotonic();first=last=None;pump=None
    report=dict(status='RUNNING',port=port,baud=921600,expected_usercode=expected_usercode,
                source_verified=False,hdmi_observed=False,cpu_inference_verified=False,ethernet_verified=False)
    try:
        with serial.Serial(port,921600,timeout=.02) as uart,SerialPump(uart) as pump,(output/'raw.bin').open('wb') as stream,(output/'frames.csv').open('w',encoding='utf-8-sig',newline='') as file:
            writer=None
            while time.monotonic()-start<seconds:
                data=pump.read()
                if data:stream.write(data);stream.flush()
                records,images=d.feed(data)
                for row in records:
                    if first is None:first=time.monotonic()
                    last=time.monotonic()
                    if writer is None:writer=csv.DictWriter(file,fieldnames=list(row));writer.writeheader()
                    writer.writerow(row);rows.append(row)
                file.flush()
                for raw,meta in images:
                    stem=output/f"frame_{meta['frame_id']:010d}"
                    stem.with_suffix('.gray').write_bytes(raw)
                    stem.with_suffix('.pgm').write_bytes(b'P5\n96 96\n255\n'+raw)
                    stem.with_suffix('.bmp').write_bytes(bmp(raw))
                    stem.with_suffix('.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
                    metas.append(meta)
                    print(f"Image {meta['frame_id']} SUM={meta['checksum']} gray={meta['gray_min']}..{meta['gray_max']} motion={meta['changed_count']}",flush=True)
                if not rows and time.monotonic()-start>10:raise TimeoutError('No A2V1 source data at 921600 baud')
            report['measurement']=analyse(rows)
            report['clock_ratio_to_host']=report['measurement']['seconds']/(last-first) if last and last>first else None
            report['status']='CAPTURED_NEEDS_PROVENANCE_REVIEW' if metas else 'FAIL_NO_IMAGES'
            report['telemetry_drops_changed']=rows[-1]['telemetry_drops']!=rows[0]['telemetry_drops']
    except Exception as exc:report.update(status='FAIL',error=str(exc));raise
    finally:
        report.update(source_records=len(rows),images=len(metas),decoder=dict(d.stats),a2_decoder=dict(d.a2.stats),
                      host_seconds=time.monotonic()-start,partial_bytes=len(d.buffer),
                      incomplete_image_parts=len(d.parts))
        report['serial_reader']=dict(pump.stats) if pump else None
        (output/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps(report,indent=2),flush=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--port');p.add_argument('--seconds',type=float,default=65);p.add_argument('--output')
    p.add_argument('--expected-usercode',default='0x41335631',help='Provenance label only; verify actual image separately by JTAG')
    capture(**vars(p.parse_args()))
