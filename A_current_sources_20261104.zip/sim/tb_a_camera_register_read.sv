`timescale 1ns/1ps
module tb_a_camera_register_read;
    reg clk=0;always #5 clk=~clk;
    reg rst_n=0,rd_en=0,nack=0;
    wire init_done,rd_done,valid,read_nack,wr_done;
    wire [7:0] data,wdata;
    wire [2:0] wbaddr;
    wire wbwrite,cs;
    reg [7:0] rx=8'hab;
    // Actual OpenCores WB RX/status output is registered, not combinational.
    reg [7:0] rdata=0;
    always @(posedge clk)rdata<=wbaddr==3?rx:(wbaddr==4?(nack?8'h80:8'h00):8'h20);
    i2c_16addr_8data dut(.clk(clk),.rst_n(rst_n),.din(8'b0),.addr(16'h3107),
        .dout(data),.dev_addr(8'h60),.init_done(init_done),.wr_en(1'b0),.rd_en(rd_en),
        .wr_done(wr_done),.rd_done(rd_done),.dout_valid(valid),.read_nack(read_nack),
        .i2c_address(wbaddr),.i2c_write(wbwrite),.i2c_writedata(wdata),.i2c_chipselect(cs),
        .i2c_waitrequest(1'b0),.i2c_readdata(rdata));
    reg [7:0] txbytes[0:3];integer count=0;
    always @(posedge clk)if(rst_n && wbwrite && wbaddr==3 && dut.rd_wr)begin
        if(count>=4)$fatal(1,"extra I2C address/data write");
        txbytes[count]=wdata;count=count+1;
    end
    task tick;begin @(posedge clk);#1;end endtask
    task request;begin
        count=0;@(negedge clk);rd_en=1;tick();@(negedge clk);rd_en=0;
        wait(valid);#1;
        if(count!=4 || txbytes[0]!=8'h60 || txbytes[1]!=8'h31 || txbytes[2]!=8'h07 || txbytes[3]!=8'h61)
            $fatal(1,"I2C read transaction address sequence");
    end endtask
    initial begin
        tick();@(negedge clk);rst_n=1;wait(init_done);repeat(3)tick();
        request();if(data!==8'hab || read_nack)$fatal(1,"RX byte not connected or false NACK");
        repeat(3)tick();nack=1;rx=8'hcd;
        request();if(data!==8'hcd || !read_nack)$fatal(1,"NACK not retained");
        repeat(3)tick();nack=0;rx=8'hef;
        request();if(data!==8'hef || read_nack)$fatal(1,"NACK recovery");
        $display("PASS tb_a_camera_register_read: repeated-start address sequence, RX data, NACK and recovery");
        $finish;
    end
    initial begin #100000;$fatal(1,"timeout");end
endmodule
