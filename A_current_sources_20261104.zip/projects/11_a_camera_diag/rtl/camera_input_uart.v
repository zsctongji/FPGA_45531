// A2 standalone camera diagnostic. One 50 MHz domain, no video backpressure.
// 36-byte little-endian A2V1 records; byte sum of bytes 0..31 in bytes 32..35.
// Timer is local to this diagnostic, not the future shared SoC timer.
module camera_input_uart #(
    parameter CLK_HZ=50000000, BAUD=115200,
    parameter WIDTH=1920, HEIGHT=1080, PIXELS_PER_CLOCK=4
)(
    input wire clk,rst_n,in_vs,in_de,in_hs,
    input wire [15:0] raw_debug,
    // Snapshot held stable after config_valid; asynchronous source is one-shot.
    input wire [127:0] config_snapshot,
    input wire config_valid,
    output reg tx,
    output reg [31:0] telemetry_drops
);
    localparam MS_DIV=CLK_HZ/1000;
    localparam BIT_DIV=CLK_HZ/BAUD;
    reg [31:0] ms_count,now_ms;
    reg polarity_known,vs_data_high;
    (* async_reg="true" *) reg [3:0] config_ready_sync;
    reg [127:0] configs;
    reg config_latched;
    wire rv,rc;
    wire [31:0] fid,stamp,frames,malformed;
    wire [15:0] width,height,errors;
    camera_input_monitor #(.EXPECTED_WIDTH(WIDTH),.EXPECTED_HEIGHT(HEIGHT),
        .PIXELS_PER_CLOCK(PIXELS_PER_CLOCK),.LINE_FROM_HS(1)) monitor(
        .clk(clk),.rst_n(rst_n && polarity_known),.in_vs(in_vs ^ vs_data_high),
        .in_de(in_de),.in_hs(in_hs),.now_ms(now_ms),
        // Debug bits have not been qualified as faults: flags bit 0 stays zero.
        .transport_errors(16'b0),.record_valid(rv),.record_complete(rc),
        .record_frame_id(fid),.record_timestamp_ms(stamp),.record_width(width),
        .record_height(height),.record_errors(errors),.source_frames(frames),
        .malformed_frames(malformed));
    wire [15:0] diagnostic=config_latched ? {4'b0,fid[3:0],configs[fid[3:0]*8+:8]} : raw_debug;
    wire [255:0] fields={telemetry_drops,malformed,frames,diagnostic,5'b0,config_latched,vs_data_high,1'b0,
                        7'b0,rc,height,width,stamp,fid,32'h31563241};
    function [31:0] sum32(input [255:0] data);
        integer i;begin sum32=0;for(i=0;i<32;i=i+1)sum32=sum32+data[i*8+:8];end
    endfunction
    reg [287:0] packet;
    reg active;
    reg [5:0] byte_index;
    reg [3:0] bit_index;
    reg [31:0] bit_count;
    wire [7:0] current_byte=packet[byte_index*8+:8];
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            ms_count<=0;now_ms<=0;telemetry_drops<=0;
            polarity_known<=0;vs_data_high<=0;
            config_ready_sync<=0;configs<=0;config_latched<=0;
            packet<=0;active<=0;byte_index<=0;bit_index<=0;bit_count<=0;tx<=1;
        end else begin
            config_ready_sync<={config_ready_sync[2:0],config_valid};
            if(config_ready_sync[3] && !config_latched)begin configs<=config_snapshot;config_latched<=1;end
            // Learn VS's data level once from the actual CSI stream, then hold.
            // Hold the monitor reset until known; discard the startup half-frame.
            if(!polarity_known && in_de)begin polarity_known<=1;vs_data_high<=in_vs;end
            if(ms_count==MS_DIV-1)begin ms_count<=0;now_ms<=now_ms+1;end
            else ms_count<=ms_count+1;
            if(rv) begin
                if(active)telemetry_drops<=telemetry_drops+1;
                else begin
                    packet<={sum32(fields),fields};active<=1;byte_index<=0;
                    bit_index<=0;bit_count<=0;tx<=0;
                end
            end
            if(active) begin
                if(bit_count==BIT_DIV-1) begin
                    bit_count<=0;
                    if(bit_index==9) begin
                        if(byte_index==35)begin active<=0;tx<=1;end
                        else begin byte_index<=byte_index+1;bit_index<=0;tx<=0;end
                    end else begin
                        bit_index<=bit_index+1;
                        if(bit_index==8)tx<=1; // stop bit
                        else tx<=current_byte[bit_index];
                    end
                end else bit_count<=bit_count+1;
            end
        end
    end
endmodule
