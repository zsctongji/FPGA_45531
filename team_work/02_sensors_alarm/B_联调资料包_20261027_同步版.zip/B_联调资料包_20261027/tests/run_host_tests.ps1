param(
    [string]$Compiler = 'C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe'
)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$build = Join-Path $project 'build'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$log = Join-Path $build 'host_tests.log'
Set-Content -LiteralPath $log -Value ('Synthetic host regression; ' + (Get-Date -Format o)) -Encoding utf8
function Invoke-Checked {
    param([string]$Program, [string[]]$Arguments)
    $lines = & $Program @Arguments 2>&1
    $code = $LASTEXITCODE
    foreach ($line in $lines) {
        Write-Host $line
        Add-Content -LiteralPath $log -Value $line -Encoding utf8
    }
    if ($code -ne 0) { throw "Command failed ($code): $Program" }
}
try {
    if (-not (Test-Path -LiteralPath $Compiler)) {
        $found = Get-Command gcc -ErrorAction SilentlyContinue
        if (-not $found) { throw 'Supply the GCC path with -Compiler.' }
        $Compiler = $found.Source
    }
    $includes = @(
        ('-I' + (Join-Path $project 'upstream_snapshot'))
        ('-I' + (Join-Path $project 'team_work/02_sensors_alarm/include'))
        ('-I' + (Join-Path $project 'third_party/mlx90640/headers'))
    )
    $sources = @('tests/test_b.c', 'upstream_snapshot/c3_hal.c',
        'team_work/02_sensors_alarm/src/b_sht30.c',
        'team_work/02_sensors_alarm/src/b_thermal.c',
        'team_work/02_sensors_alarm/src/b_alarm.c',
        'team_work/02_sensors_alarm/src/b_mlx_port.c')
    $objects = @()
    foreach ($source in $sources) {
        $obj = Join-Path $build (([IO.Path]::GetFileNameWithoutExtension($source)) + '.o')
        $arguments = @('-std=c11', '-O1', '-Wall', '-Wextra', '-Werror') + $includes + @('-c', (Join-Path $project $source), '-o', $obj)
        Invoke-Checked -Program $Compiler -Arguments $arguments
        $objects += $obj
    }
    # Keep third-party sources unchanged; strict warnings apply to B and C3 code.
    $vendorObj = Join-Path $build 'MLX90640_API.o'
    Invoke-Checked -Program $Compiler -Arguments (@('-std=c11', '-O1') + $includes + @('-c', (Join-Path $project 'third_party/mlx90640/functions/MLX90640_API.c'), '-o', $vendorObj))
    $objects += $vendorObj
    $exe = Join-Path $build 'test_b.exe'
    Invoke-Checked -Program $Compiler -Arguments ($objects + @('-lm', '-o', $exe))
    Invoke-Checked -Program $exe -Arguments @()
    Add-Content -LiteralPath $log -Value 'B code and upstream C3 compiled with -std=c11 -O1 -Wall -Wextra -Werror. Official Melexis API compiled unchanged.' -Encoding utf8
} catch {
    Add-Content -LiteralPath $log -Value ('FAIL: ' + $_.Exception.Message) -Encoding utf8
    throw
}
