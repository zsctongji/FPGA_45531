$ErrorActionPreference='Stop'
$uartCandidates=@(Get-PnpDevice -PresentOnly -Class Ports | ForEach-Object {
    $device=$_
    if($device.InstanceId -like 'FTDIBUS\VID_0403+PID_6011+*'){
        $parent=(Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_Parent').Data
        if($parent -like 'USB\VID_0403&PID_6011&MI_02\*' -and $device.FriendlyName -match '\((COM\d+)\)'){
            [pscustomobject]@{port=$Matches[1];interface='C / MI_02';parent=$parent;instance=$device.InstanceId}
        }
    }
})
if($uartCandidates.Count -ne 1){throw "Expected one FT4232H C UART, found $($uartCandidates.Count); specify --port explicitly after checking devices."}
$uartCandidates[0] | ConvertTo-Json -Compress
