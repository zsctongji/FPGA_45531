# 项目内 Icarus 仿真工具

下载日期：2026-10-17。版本输出：Icarus Verilog 12.0 (devel), s20150603-1539-g2693dd32b。

Windows 发行维护者页面：https://bleyer.org/icarus/

下载的原包：https://bleyer.org/icarus/iverilog-v12-20220611-x64_setup.exe

原包字节数：19,165,730。

原包 SHA-256：A614057374DFAED5DA0FE454CDEB410E54981FD85DBD28BD472F4CCB765DEB84。

使用 innoextract 1.9 纯解包，把 app/bin、app/lib、app/include、app/share 放入本目录；没有执行安装程序、创建卸载注册项或修改系统 PATH。上游源码：https://github.com/steveicarus/iverilog （构建标记含 g2693dd32b）。许可证为 GPL-2.0-or-later，随附 COPYING 来自上游。MinGW 运行库、bzip2、readline、zlib 等 DLL 保留自 Windows 发行包；它们属于各自上游项目，应保留相关许可证和来源信息，不能当作本项目原创代码。

编译使用 bin/iverilog.exe；运行使用 bin/vvp.exe。相对 bin 与 lib 位置须保留，移动时整体移动 iverilog 文件夹。
