"""Real SHT30 capture through FPGA UART/I2C and unchanged team B C driver."""
import ctypes as C,csv,hashlib,json,os,statistics,time,traceback
from datetime import datetime
from pathlib import Path
import ftd2xx
from bridge import Bridge,crc8
ROOT=Path(__file__).resolve().parent
class Environment(C.Structure):
 _fields_=[('abi_version',C.c_uint32),('sample_id',C.c_uint32),('timestamp_ms',C.c_uint32),('valid_flags',C.c_uint32),('error_bits',C.c_uint32),('temperature_centi_c',C.c_int32),('humidity_centi_percent',C.c_uint32)]
CLOCK=C.CFUNCTYPE(C.c_uint32)
BUS=C.CFUNCTYPE(C.c_int,C.c_uint8,C.POINTER(C.c_uint8),C.c_uint32,C.POINTER(C.c_uint8),C.c_uint32,C.c_uint32)
class Diagnostic:
 def __init__(self,port,out):
  self.out=out;out.mkdir(parents=True,exist_ok=True);self.log=(out/'uart_transactions.jsonl').open('w',encoding='utf-8');self.bridge=Bridge(port,self.log);self.origin=time.monotonic();self.transactions=[]
  self.dll=C.CDLL(str(ROOT/'diagnostic_adapter.dll'))
  self.clock=CLOCK(lambda:int((time.monotonic()-self.origin)*1000)&0xffffffff)
  self.bus=BUS(self.transfer)
  self.dll.diag_bind.argtypes=[CLOCK,BUS,C.c_uint8]
  if self.bridge.command()!=b'BTEST001':raise RuntimeError('unexpected FPGA identity')
  if self.dll.diag_bind(self.clock,self.bus,0x45):raise RuntimeError('driver bind')
 def transfer(self,address,tx,nt,rx,nr,budget):
  start=time.monotonic();data=b'';raw=bytes(tx[:nt]);rc=0;error=''
  try:
   data=self.bridge.read(address,raw,nr)
   if len(data)!=nr:raise RuntimeError('short read')
   if (time.monotonic()-start)*1000>budget:rc=-5;error='host UART round trip exceeds HAL timeout'
   if nr:C.memmove(rx,data,nr)
  except Exception as exc:
   error=repr(exc);rc=-6 if 'BOARD_STATUS_1' in error else -5 if isinstance(exc,TimeoutError) or 'BOARD_STATUS_2' in error else -7
  self.transactions.append({'address7':address,'tx_hex':raw.hex(),'rx_hex':data.hex(),'rc':rc,'error':error,'host_duration_ms':round((time.monotonic()-start)*1000,3),'hal_timeout_ms':budget,'board_ms':self.bridge.last_ms})
  return rc
 def close(self):self.bridge.close();self.log.close()
def main():
 stamp=datetime.now().astimezone().strftime('%Y%m%d_%H%M%S');out=ROOT/'logs'/('sht30_real_'+stamp)
 out.mkdir(parents=True,exist_ok=True)
 report={'started_at':datetime.now().astimezone().isoformat(),'scope':'REAL_SENSOR_VIA_STANDALONE_FPGA_AND_PC_TEAM_B_DRIVER','final_soc_acceptance':False,'port':'COM8','address7':'0x45','target':100,'sample_interval_seconds':1,'driver_timebase':'PC_MONOTONIC_MS_DIAGNOSTIC','raw_timebase':'FPGA_MS_IN_TRANSACTION_LOG','wrote_flash':False,'samples':0,'failed_cycles':0}
 latency=ftd2xx.openEx(b'C');report['ftdi_latency_before_ms']=latency.getLatencyTimer();latency.setLatencyTimer(1);report['ftdi_latency_after_ms']=latency.getLatencyTimer();latency.close()
 d=None;rows=[];cycles=[];start=time.monotonic()
 try:
  d=Diagnostic('COM8',out)
  for cycle in range(1,151):
   if time.monotonic()-start>240:break
   wait=start+(cycle-1)-time.monotonic()
   if wait>0:time.sleep(wait)
   d.transactions=[];began=time.monotonic();rc=d.dll.diag_sht_start()
   if rc==0:
    while True:
     rc=d.dll.diag_sht_poll()
     if rc!=-2:break
     time.sleep(.001)
   env=Environment();get_rc=d.dll.diag_sht_result(C.byref(env))
   reads=[t for t in d.transactions if t['address7']==0x45 and not t['tx_hex'] and len(t['rx_hex'])==12]
   raw=bytes.fromhex(reads[-1]['rx_hex']) if reads else b''
   verified=len(raw)==6 and crc8(raw[:2])==raw[2] and crc8(raw[3:5])==raw[5]
   if verified:
    t=-4500+(17500*int.from_bytes(raw[:2],'big')+32767)//65535;h=(10000*int.from_bytes(raw[3:5],'big')+32767)//65535
    verified=t==env.temperature_centi_c and h==env.humidity_centi_percent
   valid=rc==0 and get_rc==0 and env.valid_flags==7 and env.error_bits==0 and verified
   item={'host_time':datetime.now().astimezone().isoformat(),'cycle':cycle,'rc':rc,'get_rc':get_rc,'valid':valid,'sample_id':env.sample_id,'driver_timestamp_ms':env.timestamp_ms,'board_timestamp_ms':d.bridge.last_ms,'raw_hex':raw.hex(),'temperature_c':env.temperature_centi_c/100,'humidity_percent':env.humidity_centi_percent/100,'attempts':d.dll.diag_sht_attempts(),'duration_ms':round((time.monotonic()-began)*1000,3),'valid_flags':env.valid_flags,'error_bits':env.error_bits,'transactions':d.transactions}
   cycles.append(item)
   with (out/'sht30_cycles.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(item)+'\n')
   if valid:rows.append({k:v for k,v in item.items() if k!='transactions'})
   else:report['failed_cycles']+=1;print('FAILED',cycle,rc,get_rc,raw.hex(),flush=True)
   report['samples']=len(rows)
   if len(rows)%20==0 and valid:print('SHT30 valid',len(rows),'/100; temperature',item['temperature_c'],'C; humidity',item['humidity_percent'],'%',flush=True)
   (out/'progress.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
   if len(rows)>=100:break
  report['status']='PASS_STANDALONE_SHT30_100_REAL' if len(rows)>=100 else 'INSUFFICIENT_REAL_SAMPLES'
 except Exception as exc:report['status']='ERROR';report['error']=repr(exc);report['traceback']=traceback.format_exc()
 finally:
  if d:d.close()
  if rows:
   with (out/'sht30_samples.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
   for field in ['temperature_c','humidity_percent']:report[field]={'min':min(r[field] for r in rows),'max':max(r[field] for r in rows),'mean':statistics.mean(r[field] for r in rows)}
  report['attempted_cycles']=len(cycles);report['duration_seconds']=round(time.monotonic()-start,3)
  ts=[t for c in cycles for t in c['transactions']]
  report['nack_transactions']=sum(t['rc']==-6 for t in ts);report['timeout_transactions']=sum(t['rc']==-5 for t in ts);report['crc_error_cycles']=sum(bool(c['error_bits']&4) for c in cycles)
  report['sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='summary.json'}
  (out/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8');(ROOT/'logs'/'latest_sht30_capture.txt').write_text(str(out),encoding='utf-8')
  print(json.dumps(report,indent=2),flush=True);print('RESULT_DIRECTORY',out,flush=True)
 return 0 if report['status']=='PASS_STANDALONE_SHT30_100_REAL' else 1
if __name__=='__main__':raise SystemExit(main())
