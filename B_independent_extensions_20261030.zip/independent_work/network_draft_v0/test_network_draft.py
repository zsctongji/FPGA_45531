import json
from pathlib import Path
import struct
import unittest
import zlib
from draft_receiver import FrameReassembler, parse_packet, HEADER

ROOT = Path(__file__).resolve().parent


def read_fixture():
    blob = (ROOT / "artifacts" / "synthetic_c_packets.bin").read_bytes()
    packets = []
    while blob:
        if len(blob) < 2:
            raise ValueError("bad_fixture_length")
        size = int.from_bytes(blob[:2], "big")
        if size > len(blob) - 2:
            raise ValueError("truncated_fixture")
        packets.append(blob[2:2 + size])
        blob = blob[2 + size:]
    return packets


def rewrite(packet, field, value):
    values = list(HEADER.unpack_from(packet))
    values[field] = value
    return HEADER.pack(*values) + packet[48:]


class NetworkDraftTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.packets = read_fixture()
        cls.image = bytes((i * 37 + i // 97) & 255 for i in range(9216))

    def test_c_wire_layout_and_lengths(self):
        self.assertEqual(len(self.packets), 8)
        self.assertEqual([len(p) - 48 for p in self.packets], [1200] * 7 + [816])
        identity, index, payload = parse_packet(self.packets[0])
        self.assertEqual(identity[:3], (0, 42, 0xfffffff0))
        self.assertEqual(index, 0)
        self.assertEqual(payload, self.image[:1200])

    def test_c_sender_to_python_exact_image(self):
        receiver = FrameReassembler()
        for packet in self.packets:
            receiver.add(packet)
        self.assertEqual(receiver.finish(), self.image)

    def test_out_of_order(self):
        receiver = FrameReassembler()
        for i in (7, 1, 5, 0, 6, 2, 4, 3):
            receiver.add(self.packets[i])
        self.assertEqual(receiver.finish(), self.image)

    def test_identical_duplicate_is_idempotent(self):
        receiver = FrameReassembler()
        for packet in self.packets * 2:
            receiver.add(packet)
        self.assertEqual(len(receiver.chunks), 8)
        self.assertEqual(receiver.finish(), self.image)

    def test_missing_each_chunk_never_finishes(self):
        for missing in range(8):
            with self.subTest(missing=missing):
                receiver = FrameReassembler()
                for i, packet in enumerate(self.packets):
                    if i != missing:
                        receiver.add(packet)
                with self.assertRaisesRegex(ValueError, "incomplete_frame"):
                    receiver.finish()

    def test_corruption_at_each_chunk_rejected(self):
        for i, packet in enumerate(self.packets):
            with self.subTest(chunk=i):
                corrupted = bytearray(packet)
                corrupted[-1] ^= 1
                with self.assertRaisesRegex(ValueError, "chunk_crc_mismatch"):
                    parse_packet(corrupted)

    def test_mixed_event_frame_time_or_crc_rejected(self):
        for field in (4, 5, 6, 8):
            with self.subTest(field=field):
                receiver = FrameReassembler()
                receiver.add(self.packets[0])
                values = HEADER.unpack_from(self.packets[1])
                with self.assertRaisesRegex(ValueError, "mixed_frame_or_event"):
                    receiver.add(rewrite(self.packets[1], field, values[field] ^ 1))

    def test_conflicting_duplicate_rejected(self):
        receiver = FrameReassembler()
        receiver.add(self.packets[0])
        altered = bytearray(self.packets[0])
        altered[-1] ^= 1
        altered = rewrite(altered, 10, zlib.crc32(altered[48:]))
        with self.assertRaisesRegex(ValueError, "conflicting_duplicate"):
            receiver.add(altered)

    def test_header_geometry_and_length_guards(self):
        packet = self.packets[0]
        invalid = [packet[:20], packet[:-1], packet + b"x"]
        for field, value in ((0, b"BAD!"), (1, 1), (2, 2), (3, 49), (7, 9215),
                             (9, 1), (11, 95), (12, 95), (13, 95), (14, 8),
                             (15, 7), (16, 1199)):
            invalid.append(rewrite(packet, field, value))
        for bad in invalid:
            with self.subTest(bytes=len(bad)):
                with self.assertRaises(ValueError):
                    parse_packet(bad)

    def test_whole_frame_crc_independently_checked(self):
        receiver = FrameReassembler()
        wrong_crc = zlib.crc32(self.image) ^ 1
        for packet in self.packets:
            receiver.add(rewrite(packet, 8, wrong_crc))
        with self.assertRaisesRegex(ValueError, "image_crc_mismatch"):
            receiver.finish()

    def test_empty_transfer_cannot_be_reported_complete(self):
        with self.assertRaisesRegex(ValueError, "incomplete_frame"):
            FrameReassembler().finish()

    def test_zero_ids_and_wrapping_timestamp_are_preserved(self):
        for capture_ms in (0, 0xffffffff):
            receiver = FrameReassembler()
            for packet in self.packets:
                packet = rewrite(packet, 5, 0)
                packet = rewrite(packet, 6, capture_ms)
                receiver.add(packet)
            self.assertEqual(receiver.identity[:3], (0, 0, capture_ms))
            self.assertEqual(receiver.finish(), self.image)


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(NetworkDraftTests))
    report = {"scope": "OFFLINE_SYNTHETIC_ONLY", "tests": result.testsRun,
              "passed": result.wasSuccessful(), "failures": len(result.failures),
              "errors": len(result.errors), "board_ethernet_tested": False,
              "real_sensor_samples": 0, "team_protocol_accepted": False}
    (ROOT / "artifacts" / "offline_checks.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
