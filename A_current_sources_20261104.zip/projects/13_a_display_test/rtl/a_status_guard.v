// Same-clock coherent status snapshot; CDC and shared timer come from C.
// Bit order: 0 visual/AI, 1 thermal, 2 environment. No invented sensor values.
// Unsigned subtraction handles uint32 wrap. Future timestamps are rejected.
module a_status_guard #(
    parameter VISUAL_MAX_MS=500,THERMAL_MAX_MS=1000,ENVIRONMENT_MAX_MS=3000
)(
    input wire [31:0] now_ms,visual_timestamp_ms,thermal_timestamp_ms,environment_timestamp_ms,
    input wire [2:0] valid_mask,fault_mask,
    output wire [2:0] usable_mask,stale_mask,missing_mask,
    output wire [31:0] visual_age_ms,thermal_age_ms,environment_age_ms
);
    assign visual_age_ms=now_ms-visual_timestamp_ms;
    assign thermal_age_ms=now_ms-thermal_timestamp_ms;
    assign environment_age_ms=now_ms-environment_timestamp_ms;
    wire [2:0] within_age={environment_age_ms<=ENVIRONMENT_MAX_MS,
                           thermal_age_ms<=THERMAL_MAX_MS,visual_age_ms<=VISUAL_MAX_MS};
    assign usable_mask=valid_mask&~fault_mask&within_age;
    assign stale_mask=valid_mask&~fault_mask&~within_age;
    assign missing_mask=~valid_mask&~fault_mask;
endmodule
