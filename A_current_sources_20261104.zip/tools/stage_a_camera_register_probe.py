"""Append read-only camera register probes after the unchanged vendor init sequence."""
from pathlib import Path
import re
import shutil
import sys

ROOT=Path(__file__).resolve().parents[1]
REGISTERS=[0x3107,0x3108,0x3208,0x3209,0x320a,0x320b,0x320c,0x320d,
           0x320e,0x320f,0x3e00,0x3e01,0x3e02,0x301f,0x36e9,0x37f9]

def repair_readback(target):
    path=target/'rtl/cam_i2c_ctrl/i2c/i2c_16addr_8data.v'
    s=path.read_text(encoding='utf-8')
    if 'output reg read_nack' not in s:
        s,n=re.subn(r'output\s+wire\s+(\[DATA_BYTES\*8-1:0\]\s+dout)',r'output reg \1',s)
        assert n==1
        s,n=re.subn(r'(output\s+wire\s+dout_valid,)',r'\1\n    output reg read_nack,',s)
        assert n==1
        anchor='assign dout_valid = rd_done;'
        extra='''// The init-only reference did not connect the receive data output.
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin dout<=0;read_nack<=0;end
    else begin
        if(rd_en && rd_state==S_RD_IDLE) read_nack<=0;
        if(rd_state==S_RD_TIP_CHK && !i2c_readdata[1] && rd_cnt>=1 && rd_cnt<=4 && i2c_readdata[7]) read_nack<=1;
        if(rd_state==S_RD_CFG_SET) dout<=i2c_readdata;
    end
end
'''
        assert s.count(anchor)==1
        path.write_text(s.replace(anchor,extra+anchor),encoding='utf-8')
    s=path.read_text(encoding='utf-8')
    if 'assign dout_valid = read_valid;' not in s:
        s=s.replace('// The init-only reference did not connect the receive data output.',
                    'reg read_valid;\n// Receive data is registered by the WB core: sample one cycle after rd_done.')
        s=s.replace('begin dout<=0;read_nack<=0;end','begin dout<=0;read_nack<=0;read_valid<=0;end')
        s=s.replace('if(rd_en && rd_state==S_RD_IDLE) read_nack<=0;',
                    'read_valid<=rd_done;\n        if(rd_en && rd_state==S_RD_IDLE) read_nack<=0;')
        s=s.replace('if(rd_state==S_RD_CFG_SET) dout<=i2c_readdata;','if(rd_done) dout<=i2c_readdata;')
        s=s.replace('assign dout_valid = rd_done;','assign dout_valid = read_valid;')
        path.write_text(s,encoding='utf-8')
    ctrl=path.with_name('i2c_master_ctrl_top.v');s=ctrl.read_text(encoding='utf-8')
    if '.read_nack(read_nack)' not in s:
        s=s.replace('.dout_valid(get_valid),','.dout_valid(get_valid),\n    .read_nack(read_nack),')
        s=s.replace('reg [15:0] camera_register_mask;','wire read_nack;\nreg [15:0] camera_register_mask;')
        s=s.replace('else if(get_valid) begin','else if(get_valid && !read_nack) begin')
        ctrl.write_text(s,encoding='utf-8')
    print('Connected I2C RX register and reject NACKed camera register snapshots.')

def stage():
    target=ROOT/'projects/11_a_camera_diag'
    ctrl=target/'rtl/cam_i2c_ctrl/i2c/i2c_master_ctrl_top.v'
    s=ctrl.read_text(encoding='utf-8')
    if 'camera_registers_valid' in s:raise ValueError('Register probe already staged')
    s=s.replace('parameter DATA_LENGTH = 164','parameter DATA_LENGTH = 180')
    s,n=re.subn(r'output\s+sda_padoen_o\s*//[^\n]*',
        'output sda_padoen_o,\noutput reg [127:0] camera_registers,\noutput wire camera_registers_valid',s)
    assert n==1
    insert='''
reg [15:0] camera_register_mask;
assign camera_registers_valid = &camera_register_mask;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin camera_registers<=0;camera_register_mask<=0;end
    else if(get_valid) begin
        case(addr)
'''
    for i,addr in enumerate(REGISTERS):
        insert+=f"16'h{addr:04x}: begin camera_registers[{i*8}+:8]<=get_data;camera_register_mask[{i}]<=1;end\n"
    insert+='default: ;\nendcase\nend\nend\n'
    assert s.count('endmodule')==1
    ctrl.write_text(s.replace('endmodule',insert+'\nendmodule'),encoding='utf-8')
    rom=ctrl.with_name('i2c_master_reg_rom.v');s=rom.read_text(encoding='utf-8')
    anchor="ROM[8'ha3] = {16'h3221,8'h66,1'b0};"
    assert s.count(anchor)==1
    extra='\n// Read-only diagnostics after all original 164 init writes.\n'
    for i,addr in enumerate(REGISTERS):extra+=f"ROM[8'h{164+i:02x}] = {{16'h{addr:04x},8'h00,1'b1}};\n"
    rom.write_text(s.replace(anchor,anchor+extra),encoding='utf-8')
    top=target/'rtl/ti60f225_oob_top.v';s=top.read_text(encoding='utf-8')
    anchor='i2c_master_ctrl_top u2_i2c_master_ctrl_top('
    assert s.count(anchor)==1
    s=s.replace(anchor,'wire [127:0] camera_registers_5m;\nwire camera_registers_valid_5m;\n'+anchor+'\n.camera_registers(camera_registers_5m),\n.camera_registers_valid(camera_registers_valid_5m),')
    s=s.replace(".config_snapshot(128'b0),.config_valid(1'b0),",'')
    anchor='.raw_debug(mipi_debug_out),.tx(uart_tx)'
    assert s.count(anchor)==1
    s=s.replace(anchor,'.config_snapshot(camera_registers_5m),.config_valid(camera_registers_valid_5m),\n    '+anchor)
    top.write_text(s,encoding='utf-8')
    shutil.copy2(ROOT/'rtl/camera_input_uart.v',target/'rtl/camera_input_uart.v')
    repair_readback(target)
    print('Staged 16 read-only camera register captures; original init writes unchanged.')

if __name__=='__main__':
    if sys.argv[1:]==['--repair-readback']:repair_readback(ROOT/'projects/11_a_camera_diag')
    else:stage()
