# B4 quality policy (independent, 2026-10-30)

This small gate is deliberately separate from the shared ABI and from the final C3 backend.
It checks already decoded samples before fusion:

- SHT30 temperature and humidity stay inside configurable physical ranges.
- MLX90640 samples retain the 768-position layout and validity bit mask.
- A factory bad pixel is preserved as invalid; it is not replaced with a guessed value.
- The default policy accepts the audited device result of 767/768 valid pixels, while rejecting too few valid pixels, non-finite values converted outside the configured range, missing completion flags, and non-quality errors.

The test uses synthetic fixtures only. It is not a board measurement and does not claim final C3 acceptance.
Run `powershell -NoProfile -ExecutionPolicy Bypass -File run_checks.ps1`.
