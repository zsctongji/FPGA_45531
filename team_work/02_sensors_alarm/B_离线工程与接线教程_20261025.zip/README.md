# B 离线工程与接线教程

这是可独立重跑主机合成测试的目录包。先读 docs/B_接入说明.md 和 docs/B_接线教程_20261025.md。

在本目录执行 powershell -File tests/run_host_tests.ps1，可追加 -Compiler 指定 GCC 路径。脚本使用 team_work/02_sensors_alarm/include 与 src、upstream_snapshot 和 third_party/mlx90640。upstream_snapshot 仅供离线回归，集成进共享仓库时复用现有团队接口。

既有回归通过 5,987 项合成输入断言，没有进行板卡或传感器实测。源码与测试均随包提供；build/host_tests.log 是原测试记录。完整证据目录和厂家大包不随本精简包重复分发。
