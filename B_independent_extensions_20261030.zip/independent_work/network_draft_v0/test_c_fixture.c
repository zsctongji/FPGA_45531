#include "b6_frame_packets.h"
#include <stdio.h>
#include <string.h>
static unsigned calls;
static int emit(void *context, const uint8_t *packet, size_t bytes) {
    FILE *out = (FILE *)context;
    uint8_t len[2]; len[0] = (uint8_t)(bytes >> 8); len[1] = (uint8_t)bytes;
    return fwrite(len, 1, 2, out) == 2 && fwrite(packet, 1, bytes, out) == bytes ? 0 : -1;
}
static int fail_third(void *context, const uint8_t *packet, size_t bytes) {
    (void)context; (void)packet; (void)bytes;
    ++calls; return calls == 3 ? -1 : 0;
}
int main(int argc, char **argv) {
    static uint8_t image[B6_IMAGE_BYTES], buffer[B6_PACKET_BYTES];
    b6_frame_info_t info = {0, 42, UINT32_C(0xfffffff0)};
    uint16_t sent = 9; size_t i; FILE *out;
    if (argc != 2) return 1;
    for (i = 0; i < sizeof image; ++i) image[i] = (uint8_t)(i * 37u + i / 97u);
    if (b6_crc32((const uint8_t *)"123456789", 9) != UINT32_C(0xcbf43926)) return 2;
    if (b6_packetize_frame(&info, image, sizeof image - 1, buffer, sizeof buffer,
                          fail_third, 0, &sent) != B6_EINVAL || sent != 0 || calls != 0) return 3;
    if (b6_packetize_frame(&info, image, sizeof image, buffer, sizeof buffer - 1,
                          fail_third, 0, &sent) != B6_EINVAL || sent != 0 || calls != 0) return 4;
    if (b6_packetize_frame(&info, image, sizeof image, buffer, sizeof buffer,
                          fail_third, 0, &sent) != B6_ESEND || sent != 2 || calls != 3) return 5;
    if (b6_packetize_frame(0, image, sizeof image, buffer, sizeof buffer,
                          fail_third, 0, &sent) != B6_EINVAL || sent != 0) return 6;
    if (b6_packetize_frame(&info, image, sizeof image, buffer, sizeof buffer,
                          fail_third, 0, 0) != B6_EINVAL) return 7;
    out = fopen(argv[1], "wb"); if (!out) return 8;
    if (b6_packetize_frame(&info, image, sizeof image, buffer, sizeof buffer,
                          emit, out, &sent) != B6_OK || sent != 8) { fclose(out); return 9; }
    if (fclose(out)) return 10;
    puts("PASS: known CRC32 vector, input guards, transport failure stop, 8-packet C fixture");
    return 0;
}
