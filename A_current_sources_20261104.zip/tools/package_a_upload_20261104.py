"""Create reviewed A upload artifacts without serial, JTAG or remote mutations."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'team_work/handoff/A_upload_20261104'
IGNORED={'outflow','work_syn','work_pnr','work_pt','work_sim','work_dbg','__pycache__','.git','.aws','.codex','.agents'}

def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def relative(path):return path.resolve().relative_to(ROOT.resolve()).as_posix()

def archive(path,contents,scope):
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope=scope,
                  complete_system=False,hardware_tested_this_run=False,
                  files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(contents.items())})
    contents=dict(contents,**{'MANIFEST.json':json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')})
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED) as z:
        for n,b in sorted(contents.items()):z.writestr(n,b)
    with zipfile.ZipFile(path) as z:
        if z.testzip():raise ValueError('ZIP CRC: '+str(path))
        if set(z.namelist())!=set(contents):raise ValueError('ZIP inventory')
        for n,b in contents.items():
            if sha(z.read(n))!=sha(b):raise ValueError('ZIP content: '+n)
    return contents

def main():
    test=read(ROOT/'logs/a_side_selftest.json')
    if test['status']!='PASS' or not all(t['status']=='PASS' for t in test['tests']):raise ValueError('Regression not passed')
    for n,digest in test['source_sha256'].items():
        if sha((ROOT/n).read_bytes())!=digest:raise ValueError('Untested source drift: '+n)
    if OUT.exists():raise FileExistsError('Refusing to replace an existing delivery: '+str(OUT))
    OUT.mkdir(parents=True)
    base=ROOT/'team_work/handoff/github_A_20261029/A_video_source_20261029.zip'
    with zipfile.ZipFile(base) as z:
        names={n for n in z.namelist() if n.startswith(('rtl/','sim/','projects/','tools/','docs/','team_work/shared/','team_work/01_video/','firmware/'))}
    names.update(test['source_sha256'])
    names.update(['tools/package_a_upload_20261104.py','tools/audit_a_camera_reference.py','tools/replay_a_current_c.py',
                  'firmware/a_side/a_side.c','firmware/a_side/a_side.h','team_work/01_video/A_UPLOAD_README_20261104.md'])
    for folder,pattern in [('rtl','*.v'),('rtl','*.vh'),('tools/a_side','*.py'),('team_work/01_video','*.md'),
                           ('team_work/01_video/ai_samples_20261029','*')]:
        names.update(relative(p) for p in (ROOT/folder).glob(pattern) if p.is_file())
    for project in ['02_camera','04_camera_preprocess','05_camera_motion','11_a_camera_diag','12_a_headless','13_a_display_test']:
        folder=ROOT/'projects'/project
        names.update(relative(p) for p in folder.rglob('*') if p.is_file() and not any(s in IGNORED for s in p.relative_to(folder).parts) and p.suffix.lower() not in ('.bit','.exe','.dll','.o'))
    vendor=ROOT/'vendor_projects/Ti60_V4/07_Ti60F225_MIPI_C2D_Demo/Ti60f225_csi2dsi_sc431hai_v3.4'
    names.update(relative(vendor/n) for n in ['rtl/cam_i2c_ctrl/i2c/i2c_master_reg_rom.v','ti60f225_oob.peri.xml','ti60f225_oob.sdc'])
    names.update(relative(p) for p in (ROOT/'tools/iverilog').rglob('*') if p.is_file())
    code={n:(ROOT/n).read_bytes() for n in sorted(names)}
    code['README_A_UPLOAD.md']=(ROOT/'team_work/01_video/A_UPLOAD_README_20261104.md').read_bytes()
    stage=OUT/'01_code_unpacked'
    for n,b in code.items():
        p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    # Prove that the extracted package has all selftest dependencies.
    import sys
    check=subprocess.run([sys.executable,'-X','utf8',str(stage/'tools/run_a_side.py')],cwd=stage,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
    (OUT/'package_selftest.log').write_text(check.stdout+check.stderr,encoding='utf-8')
    if check.returncode or read(stage/'logs/a_side_selftest.json')['status']!='PASS':raise RuntimeError(check.stdout+check.stderr)
    for p in (stage/'logs').glob('*'):
        if p.is_file():code[relative(p).split('/01_code_unpacked/',1)[1]]=p.read_bytes()
    code=archive(OUT/'A_code_20261104.zip',code,'A source and independent project handoff; not whole-team code or final hardware release')
    (stage/'MANIFEST.json').write_bytes(code['MANIFEST.json'])
    evidence_names={relative(p) for p in (ROOT/'logs').glob('a_*.json') if p.is_file()}
    evidence_names.update(relative(p) for p in (ROOT/'logs').glob('a_*.log') if p.is_file())
    evidence_names.update(relative(Path(t['log'])) for t in test['tests'])
    evidence_names.update(relative(p) for p in (ROOT/'team_work/01_video/ai_samples_20261029').glob('*') if p.is_file())
    acceptance=read(ROOT/'logs/a_camera_input_acceptance_20261029.json')
    capture=Path(acceptance['capture'])
    for filename,key in [('raw.bin','raw_sha256'),('frames.csv','csv_sha256')]:
        if sha((capture/filename).read_bytes())!=acceptance[key]:raise ValueError('Historical source evidence hash: '+filename)
    evidence_names.update(relative(p) for p in capture.glob('*') if p.is_file())
    samples=read(ROOT/'team_work/01_video/ai_samples_20261029/MANIFEST.json')
    for s in samples['samples']:
        for suffix in ('.gray','.json','.pgm','.bmp'):
            p=ROOT/(s['original']+suffix)
            if p.exists():evidence_names.add(relative(p))
    for item in ['a_camera_diag','a_headless','a_display_test']:
        release=read(ROOT/f'logs/{item}_release.json')
        for p in [Path(release['compile_record']),Path(release['final_sta']['report'])]:evidence_names.add(relative(p))
        if sha(Path(release['bitstream']).read_bytes())!=release['sha256']:raise ValueError('Historical bitstream hash')
        for n,h in release['sources'].items():
            if sha((ROOT/n).read_bytes())!=h:raise ValueError('Historical release source: '+n)
    for folder in ['20261029_display_stability_30min','20261029_stability_rx_fixed','20261029_stability_30min']:
        evidence_names.add('logs/a_side/headless/'+folder+'/summary.json')
    evidence={n:(ROOT/n).read_bytes() for n in sorted(evidence_names)}
    evidence['README_A_UPLOAD.md']=code['README_A_UPLOAD.md']
    for p in (stage/'logs').glob('*'):
        if p.is_file():evidence['latest_package_selftest/'+p.name]=p.read_bytes()
    archive(OUT/'A_evidence_20261104.zip',evidence,'Historical independent hardware evidence and offline regression; not current integrated acceptance')
    media=OUT/'03_video_candidates';media.mkdir()
    video_index=[]
    for p in sorted((ROOT/'team_work/competition_20261101/video_assets').glob('*.mp4')):
        target=media/p.name;shutil.copy2(p,target)
        if sha(target.read_bytes())!=sha(p.read_bytes()):raise ValueError('Video copy')
        video_index.append(dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),mode_confirmed=False,source=relative(p)))
    (media/'VIDEO_INDEX.json').write_text(json.dumps(video_index,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'00_上传清单与使用说明.md').write_bytes(code['README_A_UPLOAD.md'])
    # True RAR, not a renamed ZIP. Exclude generated caches from the unpacked tree.
    rar=Path('C:/Program Files/WinRAR/Rar.exe')
    rar_files=OUT/'rar_filelist.txt';rar_files.write_text('\n'.join(sorted(code))+'\n',encoding='utf-8')
    result=subprocess.run([str(rar),'a','-ma5','-m4','-r-','-scfl',str(OUT/'A_code_20261104.rar'),'@'+str(rar_files)],cwd=stage,capture_output=True,text=True,errors='replace',timeout=180)
    if result.returncode:raise RuntimeError('RAR creation: '+result.stdout+result.stderr)
    result=subprocess.run([str(rar),'t','-idq',str(OUT/'A_code_20261104.rar')],capture_output=True,text=True,errors='replace',timeout=120)
    if result.returncode:raise RuntimeError('RAR integrity: '+result.stdout+result.stderr)
    # Extract RAR independently, then compare every file to the ZIP contents.
    rar_check=OUT/'rar_integrity_check';rar_check.mkdir()
    result=subprocess.run([str(rar),'x','-idq',str(OUT/'A_code_20261104.rar'),str(rar_check)+'\\'],capture_output=True,text=True,errors='replace',timeout=120)
    if result.returncode:raise RuntimeError('RAR extraction: '+result.stdout+result.stderr)
    actual={p.relative_to(rar_check).as_posix() for p in rar_check.rglob('*') if p.is_file()}
    if actual!=set(code):raise ValueError('RAR inventory differs from ZIP')
    for n,b in code.items():
        if sha((rar_check/n).read_bytes())!=sha(b):raise ValueError('RAR content differs: '+n)
    files=[p for p in OUT.rglob('*') if p.is_file() and '01_code_unpacked' not in p.relative_to(OUT).parts and 'rar_integrity_check' not in p.relative_to(OUT).parts and p.name!='SHA256SUMS.txt']
    (OUT/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix()+'\n' for p in sorted(files)),encoding='utf-8')
    report=dict(status='PASS_PACKAGE_AND_EXTRACTED_SELFTEST',output=str(OUT),code_files=len(code),evidence_files=len(evidence),
                video_candidates=len(video_index),python_tests=40,rtl_simulations=15,hardware_accessed=False,rar_matches_zip=True,
                artifacts=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in OUT.glob('*') if p.suffix in ('.zip','.rar')])
    (OUT/'PACKAGE_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    # Include verification report in the final top-level checksum list too.
    with (OUT/'SHA256SUMS.txt').open('a',encoding='utf-8') as file:
        file.write(sha((OUT/'PACKAGE_VERIFICATION.json').read_bytes())+'  PACKAGE_VERIFICATION.json\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
