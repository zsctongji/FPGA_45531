@echo off
echo SYNTHETIC localhost demo. Open http://127.0.0.1:39004
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_a_side.ps1" -Mode Demo
pause
