"""Check the explicitly mapped existing UART image; no programming or sensor writes."""
from datetime import datetime
import argparse
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE/"standalone_sensor_fast/host"))
from fast_bridge import FastBridge
from d2xx_transport import D2xxTransport


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sensor-check", action="store_true")
    args = parser.parse_args()
    output = BASE/"logs"/datetime.now().strftime("followup_probe_%Y%m%d_%H%M%S_%f")
    output.mkdir()
    report = dict(scope="REAL_EXISTING_IMAGE_IDENTITY_PROBE", port="COM8", ftdi_serial="C",
                  wrote_flash=False, programmed_sram=False, buzzer_on_commands_sent=0)
    try:
        with (output/"uart_transactions.jsonl").open("w", encoding="utf-8") as log:
            bridge = FastBridge(D2xxTransport.open("C", "COM8"), log)
            try:
                report["identity"] = bridge.identify().decode("ascii")
                report["status_bytes"] = [bridge.command(3, budget_ms=200)[0] for _ in range(3)]
                report["board_ms"] = bridge.last_ms
                report["status"] = "EXISTING_BQFAST01_LOGIC_LOW_CONFIRMED"
                if args.sensor_check:
                    report["mlx_control"] = bridge.read_words(0x800d, 1)[0]
                    raw = bridge.read(0x45, bytes.fromhex("f32d"), 3)
                    report["sht_status_hex"] = raw.hex()
                    report["status_after_sensor_check"] = bridge.command(3, budget_ms=200)[0]
            finally: bridge.close()
    except Exception as exc:
        report.update(status="ERROR", error=repr(exc))
    (output/"probe.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(dict(output=str(output), **report), indent=2))
    return 0 if report["status"] != "ERROR" else 1


if __name__ == "__main__": raise SystemExit(main())
