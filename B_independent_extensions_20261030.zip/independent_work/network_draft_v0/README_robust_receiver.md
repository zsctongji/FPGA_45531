# B6D0 缩略图接收器增强

电脑端 B6D0 草案接收状态机；保留已有报文，不作为团队最终网络协议。

- 乱序分片、相同片幂等；有效分片CRC下的内容冲突将使当前会话失效。
- 相同图像identity也按source隔离；source可由调用者附加boot/session标识，报文本身没有boot字段。
- 以第一片起算整帧寿命（默认2000 ms），重复片不续期。
- 未完成会话上限默认8；按创建次序淘汰，跨uint32回绕也保持次序。
- 完整帧CRC通过后返回；近期已完成identity在ttl内抑制重复整帧，缓存上限默认64；缓存过期/淘汰后可重新交付，不是持久的恰好一次服务。
- arrival_ms必须来自同一接收端单调时钟；允许uint32自然回绕，单次时钟跨度必须小于2^31 ms；拒绝倒退时间及bool/浮点值。

运行 python -m unittest discover -s . -p test_robust_receiver.py -v，14项测试。配套 draft_receiver.py 必须保留。

没有实现板端MAC/PHY、ARP、IP或UDP，没有新增板端网口实测。测试来源均为电脑生成的确定性图像。原始草案的12项fixture测试另见 test_network_draft.py；fixtures来自先前C分包程序生成的合成数据。
