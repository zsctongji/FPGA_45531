# A 交付包使用说明

整理日期：2026-11-04。板卡目前位于 C 电脑。本包交付 A 的源码、独立工程、历史实测证据及新增诊断代码，未进行本轮上板。

## 上传哪些文件

| 文件 | 用途 | 接收方 |
|---|---|---|
| `A_code_20261104.zip` | A 源码与复现入口，可直接交给 C；解压后保留相对目录 | GitHub / 队友 |
| `A_code_20261104.rar` | 与 ZIP 相同内容的真正 RAR 文件；两份任选一份，避免重复上传 | 比赛“全部代码”栏目要求 RAR 时使用 |
| `A_evidence_20261104.zip` | 历史摄像头源端原始串口、CSV、真图、构建/显示/长稳记录、离线验证报告 | 队友 / 技术报告归档 |
| `03_video_candidates/` | 已找到的 5 个原始视频候选；保留文件名，不根据候选名推断对应模式 | 视频编辑 / 人工核对 |
| `SHA256SUMS.txt` | 所有交付文件的 SHA-256，用于确认传输完整性 | 接收方 |

这些是 A 分工交付，不能代替全队“全部代码”。最终比赛代码 RAR 还须由全队合入 B/C 代码和唯一板级工程。视频候选也不是已经剪好的三分钟完整演示视频。技术报告、签署的承诺授权书、作品全貌图、开发板高清照片属于比赛另行提交的材料，不由这个代码包代替。

## 代码目录与版本

- `rtl/`：A 最新通用 RTL。包含源端完整帧统计、96×54/96×96 采样与邮箱、状态/显示叠加、串口导图和 A2D1 CSI 原始诊断扩展。
- `projects/02_camera`、`04_camera_preprocess`、`05_camera_motion`：历史彩色、灰度和运动工程源码。
- `projects/11_a_camera_diag`、`12_a_headless`、`13_a_display_test`：历史独立源端诊断、导图和六状态显示工程。各工程内的 RTL 是当时工程使用的副本；不自动用根目录新 RTL 替换。
- `firmware/a_side/`：C 接入回调/UDP 编码层的 C 源文件。
- `tools/a_side/`：串口采集、图像校验、UDP 接收/看板及 Python 测试。
- `tools/run_a_side.py`、`sim/`：离线回归入口与测试台。附项目已有 Icarus Windows 运行文件及原有许可/来源说明；Python 和 Efinity 自备。
- `vendor_projects/.../Ti60f225_csi2dsi_sc431hai_v3.4/`：静态审计用厂家 ROM、peripheral 和 SDC 参考文件，非完整厂家工具安装包。
- `team_work/01_video/ai_samples_20261029/`：5 张实际采集的灰度样本及元数据。

最新根目录代码已通过 40 项 Python 测试及 15 次 RTL 仿真；该结果是离线验证。六状态上屏、源端 1080p30、两轮各30分钟长稳分别保留其历史记录和证据范围。

## C 电脑复现

先解压到新目录检查内容，不直接覆盖 C 正在调试的工程。Python 建议 3.11 或更高版本。在解压目录运行：

```powershell
python -X utf8 tools/run_a_side.py
```

结果在 `logs/a_side_selftest.json`，应为 `PASS`。此入口不访问板卡，包含本机 HTTP/UDP 回环；系统需允许本机回环通信。源码/脚本不要使用已过期的固定 COM 号。

静态摄像头参考核对：

```powershell
python -X utf8 tools/audit_a_camera_reference.py
```

预期为 `REVIEW_REQUIRED`（返回2），因为 0x3E08=80、0x3E09=2A、0x3221=66 相对厂家 v3.4 有额外写入，需核对实际模组；这不等于审计脚本失败，也不能改返回值掩盖差异。

采集使用 pyserial。若当前 Python 没有该模块，先安装项目既有环境中的 pyserial，或使用：

```powershell
python -m pip install pyserial
python -m serial.tools.list_ports -v
```

确定 C 电脑实际 UART 和当前已加载镜像后，按镜像选择以下命令。把 `COM实际编号` 换为真实值，每次输出使用一个新的目录名：

```powershell
# 11 独立诊断，或新增且明确配置为115200的A2D1镜像
python -X utf8 tools/a_side/capture_camera_input.py --port COM实际编号 --baud 115200 --seconds 65 --output logs/c_camera_session_01

# 12/13 历史导图/显示测试镜像
python -X utf8 tools/a_side/capture_headless.py --port COM实际编号 --seconds 65 --output logs/c_headless_session_01
```

采集工具只接收，不写摄像头寄存器、不下载 FPGA。`expected_usercode` 是预期版本说明，不是实际 JTAG 版本校验。C 主机的镜像、连线和时钟必须另行确认。

## A2D1 新增诊断的接入边界

`rtl/camera_input_uart.v` 默认 `EXTENDED_DIAGNOSTIC=0`，保留36字节 A2V1。C 在新的独立诊断实例显式设 `EXTENDED_DIAGNOSTIC=1`，才发送48字节 A2D1。需添加 `camera_input_monitor.v`；`raw_debug[15:0]` 必须与 `clk` 同域，不能直接接异步硬核状态。

A2D1 前32字节字段布局保留，magic 改为 `A2D1`；32..33为采样时原始 debug，34..35为自上一次成功入队以来 OR 累积值，36..39为该窗口“任意位上升”的时钟拍数，40..43为窗口拍数，44..47为前44字节求和。所有多字节值均小端。窗口包含 UART 忙期间，计数32位饱和，重置发生在成功装入发送包时；首窗口从复位开始。寄存器读回与原始 debug 可同时保留。

这些是未解释的原始状态，只覆盖输入的16位，不能据此宣称获取了每条 lane 的 SoT 计数。接收端兼容 A2V1/A2D1，混合导图解析器也接受 A2D1。新扩展尚未完成 Efinity 物理编译和上板，不包含相应 bitstream；历史11/12/13工程不会因为解压自动启用扩展。一个 UART 引脚只允许一个发送模块，不能并联输出。

## 目前仍需 A/C 联合完成

| 项目 | 必须补交的真实板端材料 |
|---|---|
| 摄像头 SoT | 实际模组、IP/镜像版本、lane/时钟/初始化配置、位定义明确的错误原始日志及修复前后对照 |
| 完整源视频 | 新整机镜像的1920×1080完整帧、真实源帧率、观测时长、丢帧与遥测丢失分别统计；完整帧内容对照 |
| AI 同帧 | 真正源域首 DE 的共享时间、源帧号，同帧96×54及补边96×96、SUM32、C DDR/CPU读回对照 |
| 显示与网络 | B/C实时数据叠加和状态对应、真实板端发送日志与PC原始UDP记录 |

CSI 输出是每拍4个 RAW10，不是4个灰度或 RGB565；C 入口要求每拍1个 GRAY8。源端去马赛克/串行化和唯一 DDR 仍需落实，不能用显示域历史截图代替。共享分支对照基线固定为 `6c11cca8ca6cabf2d580334618434c8fd0877454`，并非声称已检查11月4日所有远端更新。

物理合入还须解决 J28.37/39、蜂鸣器、P13复位/LED、PLL与Bank冲突。旧独立工程约束不能直接作为整机约束加载。详细见 `A_C_SOURCE_BOUNDARY_20261103.md`。
