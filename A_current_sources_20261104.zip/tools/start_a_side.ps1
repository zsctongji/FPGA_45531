[CmdletBinding()]
param(
    [ValidateSet('Selftest','Demo','Receive','CameraMeasure','HeadlessCapture')][string]$Mode = 'Selftest',
    [string]$Python,
    [string]$Bind = '0.0.0.0',
    [string]$PeerIp,
    [string]$SerialPort,
    [string]$ExpectedUsercode,
    [double]$Seconds = 0,
    [string]$Output
)
$ErrorActionPreference = 'Stop'
$aRoot = Split-Path -Parent $PSScriptRoot
if (!$Python) {
    $aCandidates = @(
        (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'),
        (Join-Path $aRoot 'build\efinity_runtime_py311\python.exe')
    )
    $Python = $aCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
if (!$Python -or !(Test-Path -LiteralPath $Python)) { throw 'No usable Python found. Supply -Python with Python 3.11+.' }
$aPreviousHome = $env:PYTHONHOME
try {
    $env:PYTHONHOME = $null
    & $Python -X utf8 -c 'import socket, threading, http.server; print("A runtime ready")'
    if ($LASTEXITCODE -ne 0) { throw 'Python runtime check failed.' }
    if ($Mode -eq 'Selftest') {
        & $Python -X utf8 (Join-Path $PSScriptRoot 'run_a_side.py')
    } else {
        if (!$Output) { $Output = Join-Path $aRoot ('logs\a_side\' + $Mode.ToLower() + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss')) }
        if ($Mode -in @('CameraMeasure','HeadlessCapture')) {
            if ($Seconds -eq 0) { $Seconds = 65 }
            $aCaptureScript = if ($Mode -eq 'HeadlessCapture') { 'capture_headless.py' } else { 'capture_camera_input.py' }
            $aArguments = @('-X','utf8',(Join-Path $PSScriptRoot "a_side\$aCaptureScript"),'--output',$Output,'--seconds',"$Seconds")
            if ($SerialPort) { $aArguments += @('--port',$SerialPort) }
            if ($Mode -eq 'HeadlessCapture' -and $ExpectedUsercode) { $aArguments += @('--expected-usercode',$ExpectedUsercode) }
            & $Python @aArguments
        } elseif ($Mode -eq 'Demo') {
            & $Python -X utf8 (Join-Path $PSScriptRoot 'a_side\demo.py') --output $Output --seconds $Seconds
        } else {
            $aArguments = @('-X','utf8',(Join-Path $PSScriptRoot 'a_side\receiver.py'),'--bind',$Bind,'--output',$Output,'--seconds',"$Seconds")
            if ($PeerIp) { $aArguments += @('--peer-ip',$PeerIp) }
            & $Python @aArguments
        }
    }
    $aExitCode = $LASTEXITCODE
} finally { $env:PYTHONHOME = $aPreviousHome }
exit $aExitCode
