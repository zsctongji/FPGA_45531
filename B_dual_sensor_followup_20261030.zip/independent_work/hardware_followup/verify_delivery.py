"""Verify a clean follow-up delivery offline, preserving acquisition failures."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
SESSIONS=['dual_soak_20261030_202334_012643','dual_soak_20261030_202534_575823','dual_soak_20261030_202918_079751']

def main():
    manifest=json.loads((BASE/'FOLLOWUP_MANIFEST.json').read_text(encoding='utf-8'))
    for relative,digest in manifest['files_sha256'].items():
        path=BASE/relative
        if path.resolve().is_relative_to(BASE.resolve()) is False:raise ValueError('path outside delivery')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError('delivery hash mismatch '+relative)
    checks=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(ROOT),'-p','test_followup.py','-v'],capture_output=True,text=True,timeout=20)
    print(checks.stdout+checks.stderr)
    if checks.returncode:raise ValueError('adapter boundary test failed')
    from verify_followup import audit
    from thermal_calculate import Calculator
    calculator=Calculator()
    sessions=[audit(BASE/'logs'/name,calculator) for name in SESSIONS]
    result=dict(status='PASS_CLEAN_DELIVERY_EVIDENCE_VERIFICATION',hardware_accessed=False,files_hash_checked=len(manifest['files_sha256']),adapter_boundary_tests=3,sessions=sessions,full_system_acceptance=False)
    print(json.dumps(result,indent=2))
    (BASE/'verification_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
