"""Validate fresh A camera artifacts and sensor-safe pins before JTAG release."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import shutil
import argparse

ROOT=Path(__file__).resolve().parents[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__);group=parser.add_mutually_exclusive_group()
    group.add_argument('--headless',action='store_true');group.add_argument('--display',action='store_true')
    args=parser.parse_args();headless=args.headless or args.display
    project_name='a_display_test' if args.display else 'a_headless' if headless else 'a_camera_diag'
    name=project_name
    record_path=ROOT/('logs/efinity_'+name+'_compile.json')
    build=json.loads(record_path.read_text(encoding='utf-8-sig'))
    if build['status']!='PASS':raise ValueError('Full compile must pass')
    for artifact in build['artifacts']:
        if digest(Path(artifact['path'])).lower()!=artifact['sha256'].lower():
            raise ValueError('Compile artifact changed')
    work=ROOT/('projects/13_a_display_test' if args.display else 'projects/12_a_headless' if headless else 'projects/11_a_camera_diag')
    out=work/'outflow'
    pinout=(out/'ti60f225_oob.pinout.csv').read_text(encoding='utf-8-sig')
    for pin,pin_name,direction in [('GPIOL_04','LCD_RST_P','Input'),('GPIOL_06','LCD_POWER','Input'),
                               ('GPIOL_10','buzzer_sig','Output'),('GPIOR_28','uart_tx','Output')]:
        if not re.search(re.escape(','+pin+','+pin_name+','+direction+','),pinout):
            raise ValueError(f'Pin report mismatch: {pin}')
    if "assign buzzer_sig = 1'b0" not in (out/'ti60f225_oob.map.v').read_text(encoding='utf-8'):
        raise ValueError('Synthesized buzzer must be low')
    bit=out/'ti60f225_oob.bit'
    start=datetime.fromisoformat(build['started']).timestamp()
    if bit.stat().st_size==0 or bit.stat().st_mtime<start:raise ValueError('Bitstream missing or stale')
    target=ROOT/('fpga_bitstreams/'+name+'/'+name+'.bit')
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and digest(target)!=digest(bit):
        archive=target.parent/'archive'/ (digest(target)+'.bit')
        archive.parent.mkdir(exist_ok=True)
        if not archive.exists():shutil.copy2(target,archive)
    shutil.copy2(bit,target)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    frozen=ROOT/('logs/'+name+'_build_'+stamp+'.json')
    shutil.copy2(record_path,frozen)
    record=dict(compile_record=str(frozen),bitstream=str(target),sha256=digest(target),
        bytes=target.stat().st_size,usercode='0x41354431' if args.display else '0x41335631' if headless else '0x41325631',pinout_verified=True,
        scl_sda_input_only=True,buzzer_synthesized_low=True,flash_modified=False,
        final_sta=build['final_sta'],hardware_tested=False,
        sources={str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in
                 [work/'rtl/ti60f225_oob_top.v',work/'rtl/camera_input_monitor.v',work/'rtl/camera_input_uart.v']})
    for name in ['i2c_master_ctrl_top.v','i2c_16addr_8data.v','i2c_master_reg_rom.v']:
        p=work/'rtl/cam_i2c_ctrl/i2c'/name
        record['sources'][str(p.relative_to(ROOT)).replace('\\','/')]=digest(p)
    if headless:
        for filename in ['a_gray_snapshot.v','a_headless_uart.v','video_a_capture.v','video_grid_sampler.v','frame_motion_stats.v']:
            p=work/'rtl'/filename
            record['sources'][str(p.relative_to(ROOT)).replace('\\','/')]=digest(p)
    for filename in ['ti60f225_oob.xml','ti60f225_oob.peri.xml','ti60f225_oob.sdc']:
        p=work/filename
        record['sources'][str(p.relative_to(ROOT)).replace('\\','/')]=digest(p)
    if args.display:
        for filename in ['a_hdmi_display_exercise.v','video_a_result_display.v','video_status_overlay.v','a_status_guard.v','osd_font5x7.vh']:
            p=work/'rtl'/filename
            record['sources'][str(p.relative_to(ROOT)).replace('\\','/')]=digest(p)
        record['sources'][str((work/'a_display_thermal.mem').relative_to(ROOT)).replace('\\','/')]=digest(work/'a_display_thermal.mem')
        record['display_scope']='Live camera, explicitly labelled fixture B/C display exercise'
    name=project_name
    (ROOT/('logs/'+name+'_release.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
    (ROOT/('logs/'+name+'_release_'+stamp+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
