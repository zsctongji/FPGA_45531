"""Rebuild the host adapter from the bundled unchanged SHT30 driver, offline."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
VENDOR=ROOT.parent/'c3_driver_host/vendor'

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cc');a=p.parse_args()
    cc=a.cc or shutil.which('gcc') or r'C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe'
    sources=[ROOT/'sht_adapter.c',VENDOR/'b_sht30.c',VENDOR/'c3_hal.c']
    cmd=[cc,'-std=c11','-O2','-Wall','-Wextra','-Werror','-shared','-I',str(VENDOR),*[str(s) for s in sources],'-o',str(ROOT/'sht_adapter.dll')]
    subprocess.run(cmd,check=True,capture_output=True,timeout=60)
    report=dict(scope='HOST_ADAPTER_BUILD',hardware_accessed=False,compiler=cc,command=cmd,source_sha256={str(f.relative_to(ROOT.parent)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources+sorted(VENDOR.glob('*.h'))},dll_sha256=hashlib.sha256((ROOT/'sht_adapter.dll').read_bytes()).hexdigest())
    (ROOT/'adapter_build.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
