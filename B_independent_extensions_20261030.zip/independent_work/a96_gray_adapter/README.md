# 96×54 → 96×96 灰度适配器

这是 B 侧独立的图像入口适配层，依据当前团队接口候选：输入 96×54、GRAY8，保留每个源像素，在上方和下方各补 21 行 0，得到 96×96、stride=96、9216 字节。策略 ID 为 `GRAY54_PAD_Y21_ZERO_V1`。

它不宣称最终模型预处理已经被 A/C 验收。A 的真实视频接口或 C 的模型输入策略若改变，只需替换策略 ID 和本适配层，不需要改 B 的传感器/报警代码。

提供：

- `gray96_adapter.py`：预处理、96×54 运动框 y 坐标映射、FNV-1a、SUM32 和元数据生成；
- `test_gray96_adapter.py`：9 项主机断言；
- `fixtures/`：用于后续跨语言对照的确定性样例目录。

运行：

```powershell
D:\Ti60B\tools\efinity\2026.1\python311\bin\python.exe test_gray96_adapter.py
```

输出中的 FNV-1a 只用于数据一致性检查，不是安全散列；SUM32 用于与 A 侧样例的简单对照。此模块没有访问摄像头、DDR、SoC 或网络。
