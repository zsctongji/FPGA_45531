"""Compile and execute the bundled unmodified driver with a host mock HAL."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cc", default=os.environ.get("CC"))
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    cc = args.cc or shutil.which("gcc") or shutil.which("clang")
    if not cc:
        candidate = Path(r"C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe")
        if candidate.is_file(): cc = str(candidate)
    if not cc: raise SystemExit("Host gcc/clang required; pass --cc PATH")
    command = [cc, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-I", str(ROOT / "vendor"),
               str(ROOT / "test_sht30_driver.c"), str(ROOT / "vendor/b_sht30.c"), str(ROOT / "vendor/c3_hal.c")]
    with tempfile.TemporaryDirectory(prefix="b_c3_driver_", dir=ROOT) as tmp:
        binary = Path(tmp) / ("driver_test.exe" if os.name == "nt" else "driver_test")
        build = subprocess.run(command + ["-o", str(binary)], capture_output=True, text=True, errors="replace", timeout=60)
        if build.returncode: raise SystemExit(build.stderr or build.stdout or "compiler failed")
        run = subprocess.run([str(binary)], check=True, capture_output=True, text=True, timeout=10)
    report = json.loads(run.stdout)
    report["compiler"] = cc
    report["compiler_version"] = subprocess.check_output([cc,"--version"],text=True).splitlines()[0]
    report["source_sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"vendor").iterdir())}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))
if __name__ == "__main__": main()
