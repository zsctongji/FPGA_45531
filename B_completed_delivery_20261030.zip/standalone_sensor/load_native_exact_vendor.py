"""SRAM stream using a single native D2XX bit-sequence type; checks USER_MODE."""
import sys,json,time,hashlib
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
EFX=Path(r'D:\Ti60B\tools\efinity\2026.1')
sys.path[:0]=[str(EFX/'pgm'/'bin'),str(EFX/'debugger'/'bin')]
from efx_pgm.hiftdi.jtag import JtagEngine
from efx_pgm.hiftdi.bits import BitSequence
from efx_pgm.prog_detector import TiProgStateDetector
from efx_pgm.device_utils import DeviceUtils
artifact=ROOT/'logs'/'vendor_original_led.hex'
frequency=float(sys.argv[1]) if len(sys.argv)>1 else 1000000
j=JtagEngine(trst=False,frequency=frequency)
r={'at':datetime.now().astimezone().isoformat(),'artifact':str(artifact),'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'wrote_flash':False,'frequency':frequency,'path':'native_d2xx_exact_vendor_stream'}
def instruction(n):j.write_ir(BitSequence(n,length=5))
def status():
 instruction(12);v=j.read_dr(32);d=TiProgStateDetector(DeviceUtils().get_info_by_idcode(0x10660a79));b=repr(v)[::-1];return {'state':d.decode_prog_state(b),'registers':d.get_register_values(b),'raw':hex(int(v))}
try:
 j.configure('hiftdi://0x0403:0x6011/1');j.reset();code=int(j.read_dr(32));r['idcode']=hex(code)
 if code!=0x10660a79:raise RuntimeError('Unexpected ID')
 instruction(4);j.go_idle();j.sync();time.sleep(.02);j.reset();instruction(4);j.go_idle();j.sync();time.sleep(.02)
 j.change_state('shift_dr')
 fifo_size=512; buf='0'*20*8
 with artifact.open() as fh:
  line=fh.readline()
  while line:
   buf += format(int(line[0:2],16),'08b')
   if len(buf)//8 >= fifo_size:
    j.write(BitSequence(buf,msb=False),use_last=False); j.sync(); buf=''
   line=fh.readline()
 for _ in range((fifo_size-len(buf)//8)*8): buf += '0'
 j.write(BitSequence(buf,msb=False),use_last=False); j.sync()
 j.sync();j.change_state('exit_1_dr');j.change_state('update_dr');j.change_state('run_test_idle');time.sleep(.2)
 instruction(7);j.write_dr(BitSequence(0,length=100));j.go_idle();j.sync();time.sleep(.3)
 r['configuration']=status()
except Exception as e:
 import traceback
 r['error']=repr(e);r['traceback']=traceback.format_exc()
finally:j.reset();j.close()
(ROOT/'logs'/('native_sram_exact_'+str(int(frequency))+'.json')).write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))


