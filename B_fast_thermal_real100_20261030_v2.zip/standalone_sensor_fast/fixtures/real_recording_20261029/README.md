# Historical real raw data

Captured on 2026-10-29 by the original slow diagnostic. Used only for offline numerical regression. These pages did not satisfy the 500 ms pair condition. No new hardware measurements are implied. Pixel 620 (zero based) is an EEPROM defect and must remain invalid.
