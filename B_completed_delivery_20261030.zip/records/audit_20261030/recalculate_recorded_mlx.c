/* Offline recalculation of previously recorded REAL EEPROM/RAM data.
 * No serial/JTAG/device access. I2C stubs fail if accidentally called. */
#include <stdint.h>
#include <math.h>
#include <string.h>
#include "MLX90640_API.h"
void MLX90640_I2CInit(void) {}
void MLX90640_I2CFreqSet(int f) {(void)f;}
int MLX90640_I2CGeneralReset(void) {return -1;}
int MLX90640_I2CRead(uint8_t a,uint16_t r,uint16_t n,uint16_t *p) {(void)a;(void)r;(void)n;(void)p;return -1;}
int MLX90640_I2CWrite(uint8_t a,uint16_t r,uint16_t v) {(void)a;(void)r;(void)v;return -1;}
__declspec(dllexport) int audit_calculate(uint16_t *ee,uint16_t *f0,uint16_t *f1,
 float *out,uint8_t *quality,uint16_t *bad,float *ambient,float *supply) {
 paramsMLX90640 p; memset(&p,0,sizeof(p));
 int rc=MLX90640_ExtractParameters(ee,&p); if(rc) return rc;
 memcpy(bad,p.brokenPixels,5*sizeof(uint16_t));memcpy(bad+5,p.outlierPixels,5*sizeof(uint16_t));
 for(int j=0;j<2;j++) {
  uint16_t *f=j?f1:f0;float *o=out+j*768;uint8_t *q=quality+j*768;
  if(f[833]>1) return -100;
  for(int i=0;i<768;i++){o[i]=NAN;q[i]=0;}
  ambient[j]=MLX90640_GetTa(f,&p);supply[j]=MLX90640_GetVdd(f,&p);
  MLX90640_CalculateTo(f,&p,0.95f,ambient[j]-8.0f,o);
  for(int i=0;i<768;i++) {
   unsigned page=(unsigned)(i/32)&1u;
   if((f[832]>>12)&1u) page^=(unsigned)i&1u;
   if(page!=f[833]) continue;
   int defect=0;for(int k=0;k<10;k++)if(bad[k]==i)defect=1;
   q[i]=defect?2u:(isfinite(o[i])?1u:3u);
  }
 }
 return 0;
}
