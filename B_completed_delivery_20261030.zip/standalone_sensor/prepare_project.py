from pathlib import Path
import copy, json, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
LED=Path(r'D:\Ti60B\projects\01_led')
N='http://www.efinixinc.com/enf_proj'; P='http://www.efinixinc.com/peri_design_db'
ET.register_namespace('efx',N); ET.register_namespace('efxpt',P)
q=lambda name:'{'+N+'}'+name
p=lambda name:'{'+P+'}'+name
project=ET.parse(LED/'LED_8bit_Test.xml'); pr=project.getroot();pr.set('name','B_sensor_test')
di=pr.find(q('design_info'));di.find(q('top_module')).set('name','B_sensor_test')
for e in list(di):
 if e.tag==q('design_file'):di.remove(e)
for filename in ['B_sensor_test.v','b_uart.v','b_i2c_transaction.v']:
 di.insert(1+['B_sensor_test.v','b_uart.v','b_i2c_transaction.v'].index(filename),ET.Element(q('design_file'),name='src/'+filename,version='default',library='default'))
pr.find(q('constraint_info')).find(q('sdc_file')).set('name','constraints/sensor_clocks.sdc')
project.write(ROOT/'B_sensor_test.xml',encoding='utf-8',xml_declaration=True)
peri=ET.parse(LED/'LED_8bit_Test.peri.xml');per=peri.getroot();per.set('name','B_sensor_test');gpio=per.find(p('gpio_info'))
if gpio is None:
 for elem in per.iter():
  if elem.find(p('comp_gpio')) is not None:gpio=elem;break
assert gpio is not None
for elem in list(gpio):
 if elem.tag==p('comp_gpio') and elem.get('name','').startswith('led_data[') and elem.get('name') not in ('led_data[0]','led_data[1]'):gpio.remove(elem)
 if elem.tag==p('bus') and elem.get('name')=='led_data':elem.set('msb','1')
input_example=next(e for e in gpio if e.tag==p('comp_gpio') and e.get('name')=='key_i[3]')
output_example=next(e for e in gpio if e.tag==p('comp_gpio') and e.get('name')=='led_data[0]')
def inputnode(name):
 node=copy.deepcopy(input_example.find(p('input_config')))
 for k,v in list(node.attrib.items()):node.set(k,v.replace('key_i[3]',name))
 node.set('name',name);node.set('pull_option','none')
 for k in ['pullup_ena_name','dyn_delay_en_name','dyn_delay_reset_name','dyn_delay_ctrl_name']:node.set(k,name+'_'+k)
 return node
def outputnode(name):
 node=copy.deepcopy(output_example.find(p('output_config')))
 node.set('name',name);return node
for base,gpiodef in [('sensor_scl','GPIOL_04'),('sensor_sda','GPIOL_06')]:
 node=ET.SubElement(gpio,p('comp_gpio'),name=base,gpio_def=gpiodef,mode='inout',bus_name='',io_standard='3.3 V LVCMOS')
 node.append(inputnode(base+'_in'));node.append(outputnode(base+'_out'))
 ET.SubElement(node,p('output_enable_config'),name=base+'_oe',is_register='false',clock_name='',is_clock_inverted='false',name_oen=base+'_OEN')
node=ET.SubElement(gpio,p('comp_gpio'),name='uart_rx',gpio_def='GPIOL_02',mode='input',bus_name='',io_standard='3.3 V LVCMOS');node.append(inputnode('uart_rx'))
for name,gpiodef in [('uart_tx','GPIOR_28'),('buzzer_sig','GPIOL_10')]:
 node=ET.SubElement(gpio,p('comp_gpio'),name=name,gpio_def=gpiodef,mode='output',bus_name='',io_standard='3.3 V LVCMOS');node.append(outputnode(name))
for e in list(gpio):
 if e.tag in (p('global_unused_config'),p('bus')):gpio.remove(e);gpio.append(e)
peri.write(ROOT/'B_sensor_test.peri.xml',encoding='utf-8',xml_declaration=True)
(ROOT/'constraints'/'sensor_clocks.sdc').write_bytes((LED/'constraints'/'led_clocks.sdc').read_bytes())
top=ROOT/'src'/'B_sensor_test.v';text=top.read_text();text=text.replace('output wire [7:0] led_data','output wire [1:0] led_data').replace("assign led_data={ms_now[9],ms_now[8],2'b11,scl_sync[1],sda_sync[1],!i2c_busy,!buzzer_sig};",'assign led_data={!i2c_busy,ms_now[9]};');top.write_text(text)
print('Prepared B_sensor_test for Ti60F225. B3/C3 open-drain, B5 alarm, R14/R4 UART. Does not use DDR/Flash.')
