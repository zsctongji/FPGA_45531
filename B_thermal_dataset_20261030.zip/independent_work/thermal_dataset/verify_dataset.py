"""Rebuild dataset, run original C policies and reject damaged replay files."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from build_dataset import BASE, DEFAULT_RUN, load, require, sha

ROOT = Path(__file__).resolve().parent


def verify(compiler=None):
    manifest_path = BASE / "thermal_dataset_manifest.json"
    manifest_files = 0
    if manifest_path.is_file():
        manifest = load(manifest_path)
        for name, digest in manifest["files_sha256"].items():
            path = (BASE/name).resolve()
            require(path.is_relative_to(BASE), "manifest path escapes bundle")
            require(sha(path) == digest, "bundle hash mismatch: " + name)
            manifest_files += 1
    suite = unittest.defaultTestLoader.discover(str(ROOT), pattern="test_dataset.py")
    tests = unittest.TextTestRunner(verbosity=2).run(suite)
    require(tests.wasSuccessful(), "targeted dataset tests failed")
    delivered = load(ROOT/"results/dataset_report.json")
    for name, digest in delivered["output_files_sha256"].items():
        require(sha(ROOT/"results"/name) == digest, "delivered output changed: " + name)
    with tempfile.TemporaryDirectory(prefix="b_thermal_dataset_") as temp:
        output = Path(temp)
        # Windows keeps a loaded ctypes DLL locked until its process exits.
        # Run regeneration in a child so the disposable directory can be removed.
        regenerate_command = [sys.executable, "-B", str(ROOT/"build_dataset.py"),
                              "--run", str(DEFAULT_RUN), "--output", str(output)]
        if compiler: regenerate_command += ["--cc", compiler]
        regenerated_process = subprocess.run(regenerate_command, capture_output=True,
                                              text=True, errors="replace", timeout=90)
        require(regenerated_process.returncode == 0,
                "regeneration failed: " + regenerated_process.stderr)
        regenerated = load(output/"dataset_report.json")
        require(regenerated == delivered, "independent regeneration changed dataset report")
        cc = compiler or os.environ.get("CC") or shutil.which("gcc") or str(
            Path(r"C:/Program Files (x86)/Dev-Cpp/MinGW64/bin/gcc.exe"))
        vendor = BASE/"independent_work/offline_acceptance/vendor"
        exe = output/("replay_thermal.exe" if sys.platform == "win32" else "replay_thermal")
        command = [cc, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-pedantic",
                   "-I"+str(vendor), str(ROOT/"replay_thermal.c")]
        command += [str(vendor/(name+".c")) for name in
                    ("b4_quality_policy", "b4_temporal_policy", "b4_publish_gate")]
        command += ["-o", str(exe)]
        compiled = subprocess.run(command, capture_output=True, text=True, timeout=60)
        require(compiled.returncode == 0, "C replay compile failed: " + compiled.stderr)
        binary = output/"thermal_probe_records.bin"
        replay = subprocess.run([str(exe), str(binary)], capture_output=True, text=True, timeout=20)
        require(replay.returncode == 0, "C ABI replay failed: " + replay.stderr)
        damaged = output/"damaged.bin"
        original = binary.read_bytes()
        damaged.write_bytes(original[:-1])
        truncated = subprocess.run([str(exe), str(damaged)], capture_output=True, timeout=20)
        require(truncated.returncode != 0, "C accepted truncated data")
        changed = bytearray(original)
        changed[24+1536+620//8] |= 1 << (620%8)
        damaged.write_bytes(changed)
        mask_corruption = subprocess.run([str(exe), str(damaged)], capture_output=True, timeout=20)
        require(mask_corruption.returncode != 0, "C accepted bad-pixel mask corruption")
    drivers = [name for name in ("serial", "ftd2xx", "pyftdi.ftdi", "efx_pgm.ftdi_program")
               if name in sys.modules]
    require(not drivers, "offline verification imported a hardware driver")
    return dict(status="PASS", scope="OFFLINE_REAL100_DATASET_AND_C_ABI_VERIFICATION",
                hardware_accessed=False, new_board_measurements=0,
                manifest_files_verified=manifest_files, targeted_tests=tests.testsRun,
                pairs_recalculated=100, output_hashes_reproduced=True,
                c_abi_replay=replay.stdout.strip(),
                c_rejects_truncated_record=True, c_rejects_changed_bad_pixel_mask=True,
                hardware_drivers_imported=drivers, full_system_release_allowed=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cc")
    args = parser.parse_args()
    print(json.dumps(verify(args.cc), ensure_ascii=False, indent=2))
