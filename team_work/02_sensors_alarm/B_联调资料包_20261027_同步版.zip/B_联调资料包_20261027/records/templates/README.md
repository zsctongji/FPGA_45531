# 上板日志空白模板说明

更新：2026-10-27。六个 CSV 仅有列头，没有任何虚构的测试值或 PASS。先复制到 records/实际session_id/ 再填写，原始日志单独保存。

## 共用规则

- session_id：本次上电/固件/接线组合的唯一编号。重启、换固件或改接线后使用新编号。版本、约束哈希、模块接线和时钟来源写在本次 B_上板测试记录副本中。
- record_kind：真实器件正常采样填 real_board；在真实板上有意注入软件故障填 board_fault_injection；主机合成数据填 synthetic_host，不能计入真实样本验收。
- 空值表示未获取或不适用，数字 0 表示实际值为零。失败时仍要记录 rc/error_bits，不用 0 摄氏度或空行冒充有效样本。
- timestamp_ms 及其他 _ms 字段为整机公共 uint32 毫秒时钟；以 2^32 模回绕，在同一 session 内解释。duration_ms/gap_ms 是时长；任何跨主机/板卡时钟的差值都需先有同步依据。
- address7 使用文本 0x45、0x44 或 0x33；存的是 7 位地址。序号/标志为十进制或明确带 0x 的十六进制；温湿度固定单位见下面。
- 原始数据、位图、EEPROM、载荷等 _ref 填证据文件路径；共享时优先使用相对本次 session 文件夹的路径。SHA-256 用 64 位十六进制字符。
- CSV 为 UTF-8（带 BOM），逗号分隔。有逗号、引号或换行的单元格按标准 CSV 用双引号包围、内部引号加倍。原始失败数据完整保留。

## 六个文件怎么填

### sht30_samples.csv

每次终态读数/失败一行；中途失败重试的细节保存在 raw_log_ref，必要时也单独记行，不丢弃失败尝试。

- timestamp_ms/sample_id/rc/valid_flags/error_bits 取实际 B 接口结果。有效温度单位 temperature_centi_c 为 0.01°C；humidity_centi_percent 为 0.01%RH。
- raw_hex 为收到的 6 字节十六进制串，不放计算结果；读失败或字节不足时保留实际收到长度并在原始日志说明。
- temperature_crc_ok/humidity_crc_ok：实测校验通过为 1、失败为 0、未能校验为空。两处 CRC 都必须检查。
- attempts 为本周期已发生的尝试次数；read_duration_ms 为此次实际读事务耗时，不能把转换等待时间直接填作读耗时。
- 统计至少 100 条有效真实读数时，同时报告总周期数、总尝试数、CRC/NACK/超时数和测试时间。

### mlx_subpages.csv

每个原始子页读出/失败一行。capture_start_ms、capture_end_ms、conversion_end_ms 分别记录采集开始、完成和温度换算完成。

- subpage 实测为 0 或 1；mode 统一填 chess 或 interleaved。address7 填真实地址。
- vendor_rc 为实际调用的 Melexis API 返回值，含义按该 API 解释；部分采集 API 非负值可能是子页编号，不能统一当作只有 0 才成功。session_rc 为 b_mlx_session_end 返回的 COOP 状态；两者分开记录。
- calibration_ok 为本器件 EEPROM 已由官方函数提取参数且调用成功时的 1，否则 0。eeprom_sha256 关联本器件 EEPROM 导出文件。
- raw_frame_ref 保存实际原始帧；converted_pixels_ref 保存校准后的摄氏度浮点数组，仅本子页对应像素有意义。bad_bits_ref 为 b_thermal_push 使用的坏点位图，bit=1 表示该像素不可用。
- 不用同一子页复制两次伪造完整温度帧。配置/模式改变后重新开始配对。

### thermal_frames.csv

每次成帧或读取失败一行。

- timestamp_ms/sample_id/rc/valid_flags/error_bits 来自 B 的完整热图接口，时间戳保守取两页中较早的组装时刻，不是精确曝光时间。
- first_subpage/second_subpage 为先后收到的真实子页编号，二者必须不同；subpage_gap_ms 是对应两次组装输入时间差。
- temperature_centi_c_ref 指向 JSON：固定 768 个整数，单位 0.01°C，按索引顺序保存；pixel_valid_bits_ref 指向恰好 96 字节的二进制位图。像素索引 i 对应 byte[i/8] 的 bit(i%8)，1 表示有效。valid_pixel_count 为位图中有效位总数。
- 该有效位图的意义与 mlx_subpages.csv 的 bad_bits_ref 相反。不能把两者混用。文件名应注明 valid 或 bad。
- eeprom_sha256 与子页日志一致。按当前本地接口，rc=0、valid_flags=7、error_bits=0 和年龄条件同时满足才是有效完整样本；带坏点的诊断帧保留错误状态。

### alarm_events.csv

每次初始化、触发、解除、限时停止、重新布防或故障至少一行；需要观察脉冲时增加实际输出变化记录。

- event_id 关联 C 的真实事件接口；单独测试也使用唯一测试事件号，并在整机结论中标明是测试请求。
- action 可填 init、request、clear、timeout、rearm、fault、output_change；request_active 是调用参数，max_on_ms 是本次传入的实际配置。
- rc 是对应 B 操作返回值；led_write_rc/buzzer_write_rc 仅在确实捕获该次 HAL 写返回值时填写，未发生写入留空。
- led_observed/buzzer_observed 填 on、off、unknown 或 unobserved。软件调用成功不等于观察到实体动作，需 evidence_ref 的视频/测量记录支持。GPIO 写失败后不能推断实体一定关闭。

### event_delivery.csv

同一事件按 stage 分别记录 decision、alarm_request、tx、rx、clear；实际协议没有的阶段不要编造。

- board_timestamp_ms 仅填真实板端时刻，host_time_iso8601 仅填电脑真实带时区时间。二者不能在没有同步证据时直接相减。
- 若现有协议没有 event_id 或时间字段，由 A/C 确认关联方法或升级协议；此模板并不改变实际网络协议。
- state、rc、transport 来自当前协议和真实实现；rc 未提供时留空。payload_ref 保存真实消息字节/JSON及接收日志。
- 通知时延、重复与丢失采用团队确认的测量方法，不能把串口演示登记为以太网通过。

### test_results.csv

测试编号使用 B_联调与验收清单中的 B01～B15；需要细分时可写 B07-CRC 等，但应能回溯主编号。

- result 只填 NOT_RUN、BLOCKED、PASS、FAIL；空模板本身无结果。PASS 附 evidence_ref 和复核人，BLOCKED 写具体依赖。
- attempted_count/passed_count/failed_count 用同一种明确的统计单位，在 issue 或原始记录注明是周期、帧还是请求。未完成/进行中不能自动归为失败或忽略。
- duration_ms 为真实观察时长；owner/reviewer/reviewed_at 用于团队关闭问题，复核时间用带时区 ISO 8601。

## 当前本地接口的状态码

来自 upstream_snapshot/cooperation_v1.h，合入前与 C 的当前版本核对：

| rc | 含义 |
|---|---|
| 0 | COOP_OK |
| -1 | COOP_EINVAL |
| -2 | COOP_EBUSY（仍在等待，不等于最终失败） |
| -3 | COOP_ESTATE |
| -4 | COOP_ENOTSUP（能力/后端不支持） |
| -5 | COOP_ETIMEOUT |
| -6 | COOP_ENACK |
| -7 | COOP_EIO |

error_bits 可按位组合：1 超时、2 NACK、4 CRC、8 校准、16 子帧、32 总线、64 像素质量。valid_flags=7 表示 COMPLETE|CONVERTED|QUALITY 三位齐全。

## 保存热图与 EEPROM

首次联调建议用 JSON 数组保存 EEPROM 的 832 个 16 位字并注明字序/导出方式；保存原始帧时注明官方库版本和实际字数。不要以 JSON 文本 SHA-256 代替芯片内部校验，其用途只是对应同一份导出文件。温度帧用 JSON 768 个定点整数，像素有效位图用 96 字节二进制。附文件 SHA-256 便于交接时确认文件未变化。

不要只保存截图上的平均温度，或只保存一个“成功”字符串。这些记录需要能追溯到本设备、当前固件和实际读数。
