"""Independent desktop checker for the local B6D0 thumbnail DRAFT.
No sockets, hardware or accepted A receiver protocol are implied.
"""
import struct
import zlib

HEADER = struct.Struct("!4sBBH7I6H")
IMAGE_BYTES = 96 * 96
PAYLOAD_BYTES = 1200
PACKET_COUNT = 8


def parse_packet(packet):
    if len(packet) < HEADER.size:
        raise ValueError("short_header")
    values = HEADER.unpack_from(packet)
    (magic, version, kind, header_bytes, event, frame, capture_ms, total,
     image_crc, offset, chunk_crc, width, height, stride, index, count, size) = values
    if (magic, version, kind, header_bytes) != (b"B6D0", 0, 1, 48):
        raise ValueError("unsupported_draft_header")
    if (width, height, stride, total, count) != (96, 96, 96, IMAGE_BYTES, PACKET_COUNT):
        raise ValueError("invalid_geometry")
    if index >= count or offset != index * PAYLOAD_BYTES:
        raise ValueError("invalid_chunk_offset")
    expected = min(PAYLOAD_BYTES, total - offset)
    if size != expected or len(packet) != 48 + size:
        raise ValueError("invalid_packet_length")
    payload = packet[48:]
    if zlib.crc32(payload) != chunk_crc:
        raise ValueError("chunk_crc_mismatch")
    identity = (event, frame, capture_ms, total, image_crc, width, height, stride, count)
    return identity, index, payload


class FrameReassembler:
    """One explicit transfer only. Never displays an incomplete frame.
    The eventual A receiver must add per-session expiry and source isolation.
    """
    def __init__(self):
        self.identity = None
        self.chunks = {}

    def add(self, packet):
        identity, index, payload = parse_packet(packet)
        if self.identity is not None and identity != self.identity:
            raise ValueError("mixed_frame_or_event")
        if index in self.chunks and self.chunks[index] != payload:
            raise ValueError("conflicting_duplicate")
        self.identity = identity
        self.chunks[index] = payload

    def finish(self):
        if self.identity is None or len(self.chunks) != PACKET_COUNT:
            raise ValueError("incomplete_frame")
        image = b"".join(self.chunks[i] for i in range(PACKET_COUNT))
        if len(image) != IMAGE_BYTES or zlib.crc32(image) != self.identity[4]:
            raise ValueError("image_crc_mismatch")
        return image
