// 921600-baud A2V1 source records interleaved with A3V1 display snapshots.
// A3 packets: 40-byte LE header, 256 payload bytes, SUM32 over first 296.
// Prioritize A2 between chunks (one chunk < 3.4 ms, source interval > 33 ms).
module a_headless_uart #(
    parameter CLK_HZ=50000000, BAUD=921600, SNAPSHOT_MS=1000, WIDTH=1920, HEIGHT=1080
)(
    input wire clk,rst_n,in_vs,in_de,in_hs,
    input wire [15:0] raw_debug,
    input wire [127:0] config_snapshot,
    input wire config_valid,
    input wire image_done,
    input wire [7:0] image_data,
    input wire [31:0] image_id,image_time,image_sum,image_changed,image_difference,
    input wire [15:0] image_min_x,image_min_y,image_max_x,image_max_y,
    input wire [7:0] image_flags,
    output reg image_request,
    output wire [15:0] image_address,
    output reg tx,
    output reg [31:0] telemetry_drops
);
    reg [31:0] ms_tick,now_ms,snapshot_wait;
    reg polarity_known,vs_data_high;
    (* async_reg="true" *) reg [3:0] config_sync;
    (* async_reg="true" *) reg [3:0] done_sync;
    reg config_latched;
    reg [127:0] configs;
    wire rv,complete;
    wire [31:0] fid,stamp,frames,malformed;
    wire [15:0] width,height,errors;
    camera_input_monitor #(.EXPECTED_WIDTH(WIDTH),.EXPECTED_HEIGHT(HEIGHT),.PIXELS_PER_CLOCK(4),.LINE_FROM_HS(1)) monitor(
        .clk(clk),.rst_n(rst_n&&polarity_known),.in_vs(in_vs^vs_data_high),.in_de(in_de),.in_hs(in_hs),
        .now_ms(now_ms),.transport_errors(16'b0),.record_valid(rv),.record_complete(complete),
        .record_frame_id(fid),.record_timestamp_ms(stamp),.record_width(width),.record_height(height),
        .record_errors(errors),.source_frames(frames),.malformed_frames(malformed));
    wire [15:0] diag=config_latched?{4'b0,fid[3:0],configs[fid[3:0]*8+:8]}:raw_debug;
    wire [255:0] fields={telemetry_drops,malformed,frames,diag,5'b0,config_latched,vs_data_high,1'b0,
                         7'b0,complete,height,width,stamp,fid,32'h31563241};
    function [31:0] sum32(input [255:0] d);
        integer i;begin sum32=0;for(i=0;i<32;i=i+1)sum32=sum32+d[i*8+:8];end
    endfunction
    reg [287:0] pending_packet,a2_packet;
    reg a2_pending,packet_active,packet_image,image_active,waiting_image;
    reg [319:0] header;
    reg [7:0] chunk;
    reg [8:0] index;
    reg [31:0] packet_sum;
    reg serial_busy;
    reg [31:0] bit_tick;
    reg [3:0] bit_index;
    reg [7:0] serial_byte;
    wire take_a2=!serial_busy&&!packet_active&&a2_pending;
    assign image_address={chunk,8'b0}+(index>=40&&index<296?index-40:0);
    reg [7:0] next_byte;
    always @* begin
        if(!packet_image)next_byte=a2_packet[index*8+:8];
        else if(index<40)next_byte=header[index*8+:8];
        else if(index<296)next_byte=image_data;
        else next_byte=packet_sum[(index-296)*8+:8];
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            ms_tick<=0;now_ms<=0;snapshot_wait<=0;polarity_known<=0;vs_data_high<=0;
            config_sync<=0;done_sync<=0;config_latched<=0;configs<=0;
            image_request<=0;waiting_image<=0;image_active<=0;header<=0;chunk<=0;
            pending_packet<=0;a2_packet<=0;a2_pending<=0;telemetry_drops<=0;
            packet_active<=0;packet_image<=0;index<=0;packet_sum<=0;
            serial_busy<=0;bit_tick<=0;bit_index<=0;serial_byte<=0;tx<=1;
        end else begin
            config_sync<={config_sync[2:0],config_valid};done_sync<={done_sync[2:0],image_done};
            if(config_sync[3]&&!config_latched)begin configs<=config_snapshot;config_latched<=1;end
            if(!polarity_known&&in_de)begin polarity_known<=1;vs_data_high<=in_vs;end
            if(ms_tick==CLK_HZ/1000-1)begin
                ms_tick<=0;now_ms<=now_ms+1;
                if(!image_active&&!waiting_image)begin
                    if(snapshot_wait==SNAPSHOT_MS-1)begin
                        image_request<=!image_request;waiting_image<=1;snapshot_wait<=0;
                    end else snapshot_wait<=snapshot_wait+1;
                end
            end else ms_tick<=ms_tick+1;
            if(waiting_image&&done_sync[3]==image_request)begin
                waiting_image<=0;image_active<=1;chunk<=0;
                header<={16'b0,16'd256,8'd36,8'd0,8'd1,image_flags,
                    image_max_y,image_max_x,image_min_y,image_min_x,image_difference,
                    image_changed,image_sum,image_time,image_id,32'h31563341};
            end
            if(!serial_busy)begin
                if(!packet_active)begin
                    index<=0;packet_sum<=0;
                    if(a2_pending)begin a2_packet<=pending_packet;packet_active<=1;packet_image<=0;a2_pending<=0;end
                    else if(image_active)begin
                        header[34*8+:8]<=chunk;packet_active<=1;packet_image<=1;
                    end
                end else begin
                    serial_busy<=1;bit_tick<=0;bit_index<=0;serial_byte<=next_byte;tx<=0;
                    if(packet_image&&index<296)packet_sum<=packet_sum+next_byte;
                    if(index==(packet_image?299:35))begin
                        packet_active<=0;
                        if(packet_image)begin
                            if(chunk==35)begin image_active<=0;chunk<=0;end else chunk<=chunk+1;
                        end
                    end else index<=index+1'b1;
                end
            end else if(bit_tick==CLK_HZ/BAUD-1)begin
                bit_tick<=0;
                if(bit_index==9)begin serial_busy<=0;tx<=1;end
                else begin bit_index<=bit_index+1;tx<=bit_index==8?1'b1:serial_byte[bit_index];end
            end else bit_tick<=bit_tick+1;
            if(rv)begin
                if(a2_pending&&!take_a2)telemetry_drops<=telemetry_drops+1;
                else begin pending_packet<={sum32(fields),fields};a2_pending<=1;end
            end
        end
    end
endmodule
