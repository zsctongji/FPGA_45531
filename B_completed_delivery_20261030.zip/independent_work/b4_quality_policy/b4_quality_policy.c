#include "b4_quality_policy.h"
#include <stddef.h>

void b4_quality_policy_default(b4_quality_policy_t *policy) {
    if (!policy) return;
    policy->env_temp_min_centi_c = -4000;
    policy->env_temp_max_centi_c = 8500;
    policy->env_humidity_min_centi_percent = 0;
    policy->env_humidity_max_centi_percent = 10000;
    policy->thermal_temp_min_centi_c = -4000;
    policy->thermal_temp_max_centi_c = 30000;
    /* The measured MLX90640 has one factory bad pixel (767/768 valid). */
    policy->thermal_min_valid_pixels = 700;
}

int b4_quality_environment(const coop_environment_t *sample,
                           const b4_quality_policy_t *policy,
                           uint32_t *reason_bits) {
    uint32_t reasons = 0;
    if (reason_bits) *reason_bits = 0;
    if (!sample || !policy) return COOP_EINVAL;
    if ((sample->valid_flags & COOP_SAMPLE_COMPLETE) == 0 ||
        (sample->valid_flags & COOP_SAMPLE_CONVERTED) == 0)
        reasons |= B4_QUALITY_REASON_FLAGS;
    if (sample->error_bits) reasons |= B4_QUALITY_REASON_ERROR;
    if (sample->temperature_centi_c < policy->env_temp_min_centi_c ||
        sample->temperature_centi_c > policy->env_temp_max_centi_c ||
        sample->humidity_centi_percent < policy->env_humidity_min_centi_percent ||
        sample->humidity_centi_percent > policy->env_humidity_max_centi_percent)
        reasons |= B4_QUALITY_REASON_RANGE;
    if (reason_bits) *reason_bits = reasons;
    return reasons ? COOP_ESTATE : COOP_OK;
}

int b4_quality_thermal(const coop_thermal_t *sample,
                       const b4_quality_policy_t *policy,
                       uint16_t *valid_pixels,
                       uint32_t *reason_bits) {
    uint32_t reasons = 0;
    uint16_t count = 0;
    uint32_t i;
    if (reason_bits) *reason_bits = 0;
    if (valid_pixels) *valid_pixels = 0;
    if (!sample || !policy) return COOP_EINVAL;
    if ((sample->valid_flags & COOP_SAMPLE_COMPLETE) == 0 ||
        (sample->valid_flags & COOP_SAMPLE_CONVERTED) == 0)
        reasons |= B4_QUALITY_REASON_FLAGS;
    if (sample->error_bits & ~COOP_ERROR_PIXEL_QUALITY)
        reasons |= B4_QUALITY_REASON_ERROR;
    for (i = 0; i < 768; ++i) {
        if ((sample->pixel_valid_bits[i / 8u] & (uint8_t)(1u << (i % 8u))) == 0) {
            reasons |= B4_QUALITY_REASON_BAD_PIXEL;
            continue;
        }
        ++count;
        if (sample->temperature_centi_c[i] < policy->thermal_temp_min_centi_c ||
            sample->temperature_centi_c[i] > policy->thermal_temp_max_centi_c)
            reasons |= B4_QUALITY_REASON_RANGE;
    }
    if (count < policy->thermal_min_valid_pixels)
        reasons |= B4_QUALITY_REASON_TOO_FEW;
    if (valid_pixels) *valid_pixels = count;
    if (reason_bits) *reason_bits = reasons;
    /* A known invalid pixel is a quality warning, not a reason to discard the
     * complete thermal map when the configured minimum valid count is met. */
    return (reasons & ~(uint32_t)B4_QUALITY_REASON_BAD_PIXEL) ? COOP_ESTATE : COOP_OK;
}

