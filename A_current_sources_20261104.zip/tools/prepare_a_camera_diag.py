"""Clone the verified motion baseline; add camera ingress UART and release J28 I2C pins."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import re
import shutil
import xml.etree.ElementTree as E

root=Path(__file__).resolve().parents[1]
source=root/'projects/05_camera_motion'
target=root/'projects/11_a_camera_diag'
if target.exists():raise FileExistsError(f'Refusing to overwrite {target}')
ignored={'outflow','work_syn','work_pnr','work_pt','work_sim','__pycache__','work_dbg'}
shutil.copytree(source,target,ignore=lambda d,n:[x for x in n if x in ignored])
top=target/'rtl/ti60f225_oob_top.v'
s=top.read_text(encoding='utf-8')
s,n=re.subn(r'output\s+wire\s+(LCD_RST_P|LCD_POWER)',r'input wire \1',s)
assert n==2
s,n=re.subn(r'assign\s+(LCD_POWER|LCD_RST_P)\s*=.*?;', '',s)
assert n==2
s=s.replace('output [7:0] led,','output [7:0] led,\n       output wire uart_tx,\n       output wire buzzer_sig,')
assert s.count('output wire uart_tx')==1
anchor='wire mdebug_pixel_fifo_full'
insert='''// A-only diagnostic: camera input at 50 MHz, four RAW pixels per beat.
// J28.37/39 are inputs and buzzer SIG is held low; no sensor transactions.
assign buzzer_sig = 1'b0;
wire [31:0] a_telemetry_drops;
camera_input_uart #(.CLK_HZ(50000000),.BAUD(115200)) a_input_log(
    .clk(i_mipi_rx_pclk),.rst_n(w_mipi_rx_pclk_arstn),
    .in_vs(w_mipi_rx_vs),.in_de(w_mipi_rx_de & w_mipi_rx_hs),.in_hs(w_mipi_rx_hs),
    .config_snapshot(128'b0),.config_valid(1'b0),
    .raw_debug(mipi_debug_out),.tx(uart_tx),.telemetry_drops(a_telemetry_drops));

'''
assert s.count(anchor)==1
top.write_text(s.replace(anchor,insert+anchor),encoding='utf-8')
P='http://www.efinixinc.com/enf_proj';Q='http://www.efinixinc.com/peri_design_db'
E.register_namespace('efx',P);E.register_namespace('efxpt',Q)
tree=E.parse(target/'ti60f225_oob.xml');design=tree.getroot().find('{'+P+'}design_info')
for name in ['camera_input_monitor.v','camera_input_uart.v']:
    shutil.copy2(root/'rtl'/name,target/'rtl'/name)
    index=max(i for i,x in enumerate(design) if x.tag=='{'+P+'}design_file')+1
    design.insert(index,E.Element('{'+P+'}design_file',name='rtl/'+name,version='default',library='default'))
for node in tree.getroot().findall('.//{'+P+'}bitstream_generation/{'+P+'}param'):
    if node.get('name')=='jtag_usercode':node.set('value','0x41325631')
# The native reader rejected the reserialized camera XML; preserve baseline text.
xml=(source/'ti60f225_oob.xml').read_text(encoding='utf-8')
pos=list(re.finditer(r'        <efx:design_file[^\n]+\n',xml))[-1].end()
extra=''.join('        <efx:design_file name="rtl/'+name+'" version="default" library="default" />\n'
              for name in ['camera_input_monitor.v','camera_input_uart.v'])
xml=xml[:pos]+extra+xml[pos:]
xml=xml.replace('name="jtag_usercode" value="0xFFFFFFFF"','name="jtag_usercode" value="0x41325631"')
(target/'ti60f225_oob.xml').write_text(xml,encoding='utf-8')
tree=E.parse(target/'ti60f225_oob.peri.xml');gpio=tree.getroot().find('{'+Q+'}gpio_info')
bridge=E.parse(root/'projects/09_mlx_bridge/mlx_bridge.peri.xml')
rx=next(x for x in bridge.iter() if x.tag.endswith('comp_gpio') and x.get('name')=='uart_rx')
for name in ['LCD_RST_P','LCD_POWER']:
    old=next(x for x in gpio if x.get('name')==name);index=list(gpio).index(old)
    new=deepcopy(rx);new.set('gpio_def',old.get('gpio_def'))
    for node in new.iter():
        for key,value in list(node.attrib.items()):node.set(key,value.replace('uart_rx',name))
    gpio.remove(old);gpio.insert(index,new)
for name in ['uart_tx','buzzer_sig']:
    node=deepcopy(next(x for x in bridge.iter() if x.tag.endswith('comp_gpio') and x.get('name')==name))
    assert not any(x.get('gpio_def')==node.get('gpio_def') for x in gpio if x.tag.endswith('comp_gpio'))
    gpio.insert(0,node)
tree.write(target/'ti60f225_oob.peri.xml',encoding='utf-8',xml_declaration=True)
sdc=target/'ti60f225_oob.sdc'
s='\n'.join(line for line in sdc.read_text(encoding='utf-8').splitlines() if not any(x in line for x in ['LCD_POWER','LCD_RST_P']))
s+='\nset_output_delay -clock i_mipi_rx_pclk -max 0 [get_ports {uart_tx}]\nset_output_delay -clock i_mipi_rx_pclk -min 0 [get_ports {uart_tx}]\n'
sdc.write_text(s,encoding='utf-8')
record=dict(source=str(source),target=str(target),camera_input_hz=50000000,uart_baud=115200,
    uart_pin='GPIOR_28',sensor_pins_input_only=['GPIOL_04','GPIOL_06'],buzzer_low='GPIOL_10',
    timer='standalone local camera clock milliseconds, not final SoC shared timer',
    transport_errors_qualified=False,programmed=False,
    top_sha256=hashlib.sha256(top.read_bytes()).hexdigest())
(target/'A_DIAG_PREPARATION.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
