$ErrorActionPreference = 'Stop'
$networkRoot = $PSScriptRoot
$artifactRoot = Join-Path $networkRoot 'artifacts'
New-Item -ItemType Directory -Path $artifactRoot -Force | Out-Null
. 'D:\Ti60B\tools\b_environment.ps1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PATH = 'C:\Program Files (x86)\Dev-Cpp\MinGW64\bin;' + $env:PATH
& 'C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe' -std=c99 -Wall -Wextra -Werror -pedantic -O2 -static -I $networkRoot (Join-Path $networkRoot 'b6_frame_packets.c') (Join-Path $networkRoot 'test_c_fixture.c') -o (Join-Path $artifactRoot 'test_c_fixture.exe')
if ($LASTEXITCODE -ne 0) { throw 'Native C compilation failed' }
& (Join-Path $artifactRoot 'test_c_fixture.exe') (Join-Path $artifactRoot 'synthetic_c_packets.bin')
if ($LASTEXITCODE -ne 0) { throw 'Native C fixture checks failed' }
& 'D:\Ti60B\tools\riscv_gcc\13.4.0\bin\riscv-none-elf-gcc.exe' -std=c99 -Wall -Wextra -Werror -pedantic -O2 -ffreestanding -march=rv32imac -mabi=ilp32 -I $networkRoot -c (Join-Path $networkRoot 'b6_frame_packets.c') -o (Join-Path $artifactRoot 'b6_frame_packets_rv32.o')
if ($LASTEXITCODE -ne 0) { throw 'RV32 C compilation failed' }
& (Join-Path $BEfinity 'python311\bin\python.exe') (Join-Path $networkRoot 'test_network_draft.py')
if ($LASTEXITCODE -ne 0) { throw 'Independent Python checks failed' }
