#define _CRT_SECURE_NO_WARNINGS
#include "../firmware/a_side/a_side.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
    uint8_t image[A_IMAGE_BYTES];
    int acquire_result,fail_at,releases,acquires,reads;
    uint32_t expected_sum;
} mock_port;
static int acquire(void *ctx,a_frame_info *info) {
    mock_port *p=ctx;p->acquires++;
    info->frame_id=0xffffffffu;info->timestamp_ms=0xfffffff0u;
    info->checksum=p->expected_sum;info->buffer_id=1;
    return p->acquire_result;
}
static int read_byte(void *ctx,uint16_t addr,uint8_t *value) {
    mock_port *p=ctx;p->reads++;
    if(addr>=A_IMAGE_BYTES||(int)addr==p->fail_at)return -1;
    *value=p->image[addr];return 0;
}
static void release(void *ctx) {((mock_port *)ctx)->releases++;}
static void must(int truth,const char *msg) {if(!truth){fprintf(stderr,"FAIL %s\n",msg);exit(1);}}
int main(int argc,char **argv) {
    static mock_port p;
    static uint8_t out[A_IMAGE_BYTES],packet[A_PACKET_BYTES];
    a_frame_info info;unsigned i;FILE *f;
    a_frame_port port={&p,acquire,read_byte,release};
    must(argc==2,"output argument");
    for(i=2016;i<7200;i++){p.image[i]=(uint8_t)((i-2016)%251u);p.expected_sum+=p.image[i];}
    p.acquire_result=1;p.fail_at=-1;
    must(a_read_gray96(&port,out,sizeof(out),&info)==0,"complete read");
    must(p.releases==1&&p.reads==9216&&memcmp(out,p.image,9216)==0,"byte read / release");
    must(info.frame_id==0xffffffffu&&info.timestamp_ms==0xfffffff0u&&info.buffer_id==1,"metadata unsigned");
    p.acquire_result=0;
    must(a_read_gray96(&port,out,sizeof(out),&info)==1&&p.releases==1,"no lease busy");
    p.acquire_result=-1;
    must(a_read_gray96(&port,out,sizeof(out),&info)==-1&&p.releases==1,"acquire fault");
    p.acquire_result=1;p.fail_at=3456;
    must(a_read_gray96(&port,out,sizeof(out),&info)==-1&&p.releases==2,"read fault releases lease");
    p.fail_at=-1;p.image[10]=1;
    must(a_read_gray96(&port,out,sizeof(out),&info)==-3&&p.releases==3,"padding fault releases lease");
    p.image[10]=0;p.expected_sum++;
    must(a_read_gray96(&port,out,sizeof(out),&info)==-2&&p.releases==4,"checksum fault releases lease");
    p.expected_sum--;
    must(a_read_gray96(&port,out,9215,&info)==-4&&p.releases==4,"bounded output");
    must(a_read_gray96(NULL,out,sizeof(out),&info)==-4,"null argument");
    must(a1_encode_fragment(packet,sizeof(packet),2,2,1,2,3,4,p.image,9216,0)==0,"flags range");
    must(a1_encode_fragment(packet,sizeof(packet),2,1,1,2,3,4,p.image,9216,8)==0,"fragment bound");
    must(a1_encode_fragment(packet,1239,2,1,1,2,3,4,p.image,9216,0)==0,"packet output capacity");
    f=fopen(argv[1],"wb");must(f!=NULL,"open output");
    for(i=0;i<8;i++) {
        size_t n=a1_encode_fragment(packet,sizeof(packet),2,1,7,8,0xffffffffu,0xfffffff0u,p.image,9216,(uint16_t)i);
        uint8_t length[2]={(uint8_t)(n>>8),(uint8_t)n};
        must(n==(i==7?856u:1240u),"fragment size");
        must(fwrite(length,1,2,f)==2&&fwrite(packet,1,n,f)==n,"write packet");
    }
    must(fclose(f)==0,"close output");
    puts("PASS native a_read_gray96 success/busy/errors/release/bounds and A1 fragment encoding");return 0;
}
