"""Independently match preserved UART replies, raw pages and numerical results."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics
import struct
import sys

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE / "standalone_sensor_fast"
RUN = ROOT / "logs/real_fast_20261030_184934_752153"
sys.path.insert(0, str(ROOT / "host"))
from thermal_calculate import Calculator, read_u16, assess_plausibility


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def xor(data):
    result = 0
    for value in data:
        result ^= value
    return result


def main(write_report=True):
    summary = load(RUN / "summary.json")
    for name, expected in summary["files_sha256"].items():
        assert hashlib.sha256((RUN / name).read_bytes()).hexdigest() == expected, name
    assert summary["accepted_pairs"] == summary["plausible_temperature_pairs"] == 100
    assert summary["control_restore"] == "VERIFIED"
    assert summary["original_control"] == summary["restored_control"] == 0x1901
    assert summary["buzzer_on_commands_sent"] == 0 and not summary["wrote_flash"]
    transactions = []
    for line in (RUN / "uart_transactions.jsonl").read_text().splitlines():
        item = json.loads(line)
        assert "error" not in item
        request, reply = bytes.fromhex(item["request_hex"]), bytes.fromhex(item["response_hex"])
        assert len(request) == 12 and request[:2] == b"\xa5\x5a" and xor(request[2:]) == 0
        assert reply[:2] == b"\x5a\xa5" and xor(reply[2:]) == 0
        assert request[3] == reply[2] and reply[3] == 0 and len(reply) == 10 + reply[4]
        assert item["duration_ms"] <= item["budget_ms"]
        assert struct.unpack_from("<I", reply, 5)[0] == item["board_ms"]
        op = request[2]
        assert op in (0, 1, 3)
        data = reply[9:-1]
        if op == 0:
            assert data == b"BQFAST01"
        elif op == 3:
            assert len(data) == 1 and data[0] & 4 == 0
        else:
            assert request[4] == 0x33
            register = int.from_bytes(request[7:9], "big")
            if request[5] == 4:
                assert request[6] == 0
                assert (register, int.from_bytes(request[9:11], "big")) in (
                    (0x800D, 0x1981), (0x800D, 0x1901), (0x8000, 0x0030))
            else:
                assert request[5] == 2 and len(data) == request[6] and len(data) % 2 == 0
                transactions.append({"reg": register, "ms": item["board_ms"],
                                     "words": list(struct.unpack(">" + str(len(data)//2) + "H", data))})

    eeprom = read_u16(RUN / "eeprom_u16_be.bin", 832)
    reconstructed = []
    for register in range(0x2400, 0x2740, 32):
        match = [t for t in transactions if t["reg"] == register]
        assert len(match) == 1
        reconstructed.extend(match[0]["words"])
    assert reconstructed == eeprom

    saved = {}
    warmup = []
    ram_durations = []
    for metadata_path in sorted(RUN.glob("subpage_*.json")):
        metadata = load(metadata_path)
        words = read_u16(RUN / metadata["raw_file"], 834)
        saved[metadata["raw_file"]] = (metadata, words)
        ready = [t for t in transactions if t["reg"] == 0x8000 and t["ms"] == metadata["ready_observed_ms"]]
        assert len(ready) == 1 and ready[0]["words"][0] & 8
        assert ready[0]["words"][0] & 1 == words[833]
        chunks = [t for t in transactions if 0x0400 <= t["reg"] < 0x0740 and
                  metadata["clear_completed_ms"] <= t["ms"] <= metadata["read_completed_ms"]]
        assert [t["reg"] for t in chunks] == list(range(0x0400, 0x0740, 32))
        assert [word for t in chunks for word in t["words"]] == words[:832]
        controls = [t for t in transactions if t["reg"] == 0x800D and
                    metadata["read_completed_ms"] <= t["ms"] <= metadata["checked_completed_ms"]]
        assert len(controls) == 1 and controls[0]["words"][0] == words[832] == 0x1981
        final = [t for t in transactions if t["reg"] == 0x8000 and t["ms"] == metadata["checked_completed_ms"]]
        assert len(final) == 1 and final[0]["words"][0] & 8 == 0
        assert final[0]["words"][0] & 1 == words[833]
        if metadata["sampling_phase"] == "WARMUP_EXCLUDED":
            warmup.append(metadata["raw_file"])
        else:
            ram_durations.append(metadata["read_completed_ms"] - metadata["clear_completed_ms"])
    assert len(saved) == 204 and len(warmup) == 4

    calculator = Calculator()
    ages, calculated_values, used = [], [], []
    for pair_path in sorted(RUN.glob("pair_*.json")):
        pair = load(pair_path)
        a, b = [saved[name] for name in pair["subpage_files"]]
        assert a[0]["sampling_phase"] == b[0]["sampling_phase"] == "MEASUREMENT"
        assert {a[1][833], b[1][833]} == {0, 1} and a[1][832] == b[1][832]
        observed_age = (b[0]["checked_completed_ms"] - a[0]["ready_observed_ms"]) & 0xffffffff
        assert observed_age == pair["observed_age_ms"] <= 500
        ages.append(observed_age)
        used.extend(pair["subpage_files"])
        calculated = calculator.pair(eeprom, [a[1], b[1]])
        temperature = load(RUN / pair_path.name.replace("pair_", "temperature_"))
        for key, value in calculated.items():
            assert value == temperature[key], (pair_path.name, key)
        assert calculated["valid_pixel_count"] == 767 and calculated["temperature_c"][620] is None
        assert assess_plausibility(calculated) == temperature["plausibility"]
        assert temperature["plausibility"]["status"] == "PLAUSIBILITY_CHECK_PASSED"
        calculated_values.append(calculated)
    assert len(used) == len(set(used)) == 200 and not set(used).intersection(warmup)
    report = {"status": "REAL100_UART_RAW_TIMING_AND_NUMERICAL_AUDIT_PASSED",
              "at": datetime.now().astimezone().isoformat(),
              "audit_itself_accessed_hardware": False,
              "evidence_origin": "REAL_Ti60F225_UART_AND_I2C_CAPTURE",
              "run": str(RUN.relative_to(ROOT)), "hashes_checked": len(summary["files_sha256"]),
              "transactions_checked": len((RUN/"uart_transactions.jsonl").read_text().splitlines()),
              "complete_pages_checked": len(saved), "warmup_excluded": len(warmup),
              "accepted_pairs_checked": len(ages), "temperatures_recalculated": len(calculated_values),
              "pair_observed_age_ms": {"min": min(ages), "max": max(ages), "mean": statistics.mean(ages)},
              "ram_read_interval_board_ms": {"min": min(ram_durations), "max": max(ram_durations)},
              "host_elapsed_s": summary["host_elapsed_s"],
              "derived_ambient_c": [min(v for t in calculated_values for v in t["ambient_c"]),
                                    max(v for t in calculated_values for v in t["ambient_c"])],
              "derived_supply_v": [min(v for t in calculated_values for v in t["supply_v"]),
                                   max(v for t in calculated_values for v in t["supply_v"])],
              "valid_pixels_each_pair": 767, "invalid_pixel_zero_based": 620,
              "rejections": summary["rejections"], "control_restore": "VERIFIED_0x1901",
              "flash_written": False, "buzzer_on_commands_sent": 0,
              "independent_radiometric_calibration": False,
              "c3_final_soc_shared_clock_and_fall_detection": "NOT_VALIDATED"}
    target = BASE / "records/B_fast_thermal_real100_audit_20261030.json"
    if write_report:
        target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"record": str(target), **report}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main(write_report="--verify-only" not in sys.argv)
