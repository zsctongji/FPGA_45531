# B 统一离线验收工具

本目录分析已保存的真实 SHT30 / MLX90640 日志，直接编译并调用固定快照中的 B4 C 质量、时间和发布策略，
再输出热区候选与整机发布证据清单。不会打开串口、JTAG、板卡或蜂鸣器，不会新增测量。

## 使用

需要 Python 3.11 或更新版本及 GCC（C11）。无第三方 Python 依赖。

在本目录运行：

    python -B verify_bundle.py --cc "C:/Program Files (x86)/Dev-Cpp/MinGW64/bin/gcc.exe"

该命令校验包内文件、执行 17 个针对性测试，并运行真实日志分析。结果位于 verified_results。
若 GCC 已在 PATH 中，可以省略 --cc。默认 Windows GCC 路径也是上述路径。

单独运行分析：

    python -B run_offline_acceptance.py --output-dir results

程序正常生成报告时退出 0，即使 release_decision.release_allowed=false。
执行成功、历史传感器数据有效、整机发布证据齐全是不同状态，必须读 release_decision。
输入损坏、来源 SHA 不一致、原 C 编译失败、原始 UART/CRC/换算不一致会异常退出。

## 热区特征

thermal_features.py 保留 32×24 索引和 LSB-first 的 96 字节位图。
无效位置必须为 null、有明确原因，不能为伪造温度；有效位置必须是有限数值。
只用有效像素计算最低、最高、均值、中位数，使用四邻域生成候选区域、面积、质心和包围框。

默认阈值为有效像素中位数 + 2 °C，候选区域至少 3 像素；可以在 Python analyze 调用中配置
 delta_c、absolute_min_c、min_area。这些参数仅供探索，尚无人体/跌倒标注和准确率验收。
当前真实静态热图得到 0 个候选是正常分析结果，不为生成热区而修改数据。

## 原 C 策略与重放范围

vendor 中 7 个文件是原样复制的固定本地快照；来源及 SHA256 见 provenance.json。
b4_gate_host.c 只做主机调用桥，Gate.environment / Gate.thermal 执行的是这些 C 源码，未重新写 Python 门限逻辑。
同意使用坏点的 B4 原默认最低有效数实际为 700，并非要求恰好 767；本数据有 767 个有效像素。
原 C 的成功返回 reason_bits 为 0，坏点警告需从原 error_bits=64 和位图读取；输出原样保留。
C3 的严格双子页驱动策略与此 B4 质量策略仍有差异，本工具没有改变共享 ABI 或原驱动。

环境重放把原始 board_timestamp_ms 同时用作采集时刻和 now；该操作仅验证已保存数据在该条件下的 C 策略，
不能证明正式融合时的样本新鲜度。日志中的 4 次错误仍保留并被拒绝。

热图使用经前次审计重算得到的 mlx_corrected_grid.json，不在本入口重新执行辐射标定。
原始 EEPROM、子页、事务和 UART 同时随包保存并交叉核对。此前原 summary.json 的错误温度统计由
inputs/audit_summary.json 和 corrected_grid 取代，不能再采用旧 768/768 / 最低约 0.066 °C 结论。

热图主机探针以第一子页完成时间为重建输入 timestamp，第二子页完成时间为 now；
这是对最旧子页年龄下界的条件探针，不是假称板上曾执行了这次 publish 调用。
两子页完成差 625 ms > 500 ms，直接阻止当前整机发布；最终发布时钟和 I2C 截止时间也尚未验收。

图像只用明确标注的合成梯度测试已有 GRAY54_PAD_Y21_ZERO_V1 适配器。
没有把图像时间戳与传感器的两次独立会话拼成真实同步数据，没有引入新正式协议。

## 仍需实物联调的证据

- 同一会话、同一时钟下的真实图像、温湿度、连续双子页热图。
- 双子页读取、整帧组装及正式发布年龄满足 500 ms 的证据。
- 最终 SoC I2C 后端的完整事务超时与恢复证据。
- 有标注的目标场景和负样本；推理、报警等整机功能单独验收。

此包不包含上板、推理、低功耗、Flash、断电启动或蜂鸣器冷启动通过结论。
