"""Freeze A code and scoped evidence, without certifying unfinished hardware tests."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    read=lambda n:json.loads((ROOT/n).read_text(encoding='utf-8-sig'))
    test=read('logs/a_side_selftest.json')
    if test['status']!='PASS':raise ValueError('A source regression must pass')
    for n,h in test['source_sha256'].items():
        if sha((ROOT/n).read_bytes())!=h:raise ValueError('Source changed after test: '+n)
    status=read('logs/a_delivery_status_20261029.json')
    names=set(test['source_sha256'])
    names.update(['tools/package_a_delivery.py','tools/finalize_a_headless.py','tools/package_a_handoff.py',
        'tools/start_a_side.ps1','tools/start_a_headless_preview.ps1','tools/prepare_a_units.py',
        'tools/prepare_a_camera_diag.py','tools/prepare_a_headless.py','tools/prepare_a_display.py',
        'tools/stage_a_camera_register_probe.py','tools/apply_a_exposure_fix.py','tools/release_a_camera_diag.py',
        'tools/efinity_primary.py','tools/read_jtag_primary.py','tools/run_efinity.ps1','tools/efinity_compile_primary.py',
        'tools/file_hash.ps1','tools/detect_sensor_uart.ps1','tools/build_a_firmware.py','tools/run_a_synthesis.ps1',
        'tools/test_a_firmware_host.py','tools/test_a_udp_stress.py','tools/a_side/render_real_replay.py','tools/package_a_samples.py',
        'docs/A_开始这里.md','docs/A_剩余任务核对_20261029.md','docs/A_串口真图导出.md',
        'docs/A_显示接口验收_20261029.md','docs/team_plan_20261022.md','team_work/shared/a_interface_v1.md',
        'docs/A_display_scaled_TEST_preview.png','docs/A_real_inputs_OFFLINE_REPLAY.png',
        'logs/a_delivery_status_20261029.json','logs/a_display_hdmi_acceptance_20261029.json','logs/a_stability_user_confirmation_20261030.json',
        'logs/a_display_interrupted_audit_20261029.json','logs/a_headless_first_capture_audit.json',
        'logs/a_headless_rx_pump_probe_audit.json','logs/a_headless_interrupted_audit_20261029.json',
        'logs/a_camera_input_acceptance_20261029.json','logs/a_camera_exposure_fix_20261029.json',
        'logs/a_side_selftest.json','logs/a_side_synthesis.json','logs/a_firmware_host.json','logs/a_side_firmware.json',
        'logs/a_real_inputs_replay.json','logs/a_udp_stress_20261029.json','logs/a_display_test_program_20261029.log',
        'logs/jtag_primary_20261029_221400.json','logs/a_firmware_host.log','sim/test_a_firmware.c',
        'sim/tb_a_real_replay.sv','logs/mlx90640/20261029_155654/frame_001.json',
        'logs/sensor_diag/20261026_215457/samples.csv'])
    for pattern in ['tools/A_*.cmd','team_work/01_video/*.md','team_work/01_video/*.csv','team_work/01_video/ai_samples_20261029/*']:
        names.update(p.relative_to(ROOT).as_posix() for p in ROOT.glob(pattern) if p.is_file())
    for item in test['tests']:names.add(Path(item['log']).relative_to(ROOT).as_posix())
    ignored={'outflow','work_syn','work_pnr','work_pt','work_sim','work_dbg','__pycache__','.git','.aws','.codex','.agents'}
    for project in ['11_a_camera_diag','12_a_headless','13_a_display_test']:
        base=ROOT/'projects'/project
        names.update(p.relative_to(ROOT).as_posix() for p in base.rglob('*') if p.is_file() and not any(s in ignored for s in p.relative_to(base).parts))
    for version in ['a_camera_diag','a_headless','a_display_test']:
        n='logs/'+version+'_release.json';release=read(n);names.add(n)
        for n in [release['compile_record'],release['bitstream'],release['final_sta']['report']]:names.add(Path(n).relative_to(ROOT).as_posix())
        if sha(Path(release['bitstream']).read_bytes())!=release['sha256']:raise ValueError('Bit hash')
        for n,h in release['sources'].items():
            if sha((ROOT/n).read_bytes())!=h:raise ValueError('Project source drift: '+n)
        build=json.loads(Path(release['compile_record']).read_text(encoding='utf-8-sig'))
        for n in [build['design_log'],build['preflight_log']]:names.add(Path(n).relative_to(ROOT).as_posix())
        for a in build['artifacts']:
            p=Path(a['path'])
            if sha(p.read_bytes()).upper()!=a['sha256'].upper():raise ValueError('Build artifact drift')
            if p.suffix in ['.rpt','.lpf']:names.add(p.relative_to(ROOT).as_posix())
    for folder in ['20261029_display_stability_30min','20261029_stability_rx_fixed','20261029_stability_30min']:
        names.add('logs/a_side/headless/'+folder+'/summary.json')
    contents={n:(ROOT/n).read_bytes() for n in sorted(names)}
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope='A source and evidence delivery; incremental to existing cooperative project',
        complete_system=False,all_A_acceptance_complete=False,a_independent_tasks_complete=True,continuous_30min_passed=status['continuous_30min_passed'],continuous_30min_evidence=status['continuous_30min_evidence'],continuous_30min_raw_logs_reviewed=False,delivery_status=status,
        files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in contents.items()})
    out=ROOT/'team_work/handoff/github_A_20261029';out.mkdir(parents=True,exist_ok=True)
    archive=out/'A_video_source_20261029.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in contents.items():z.writestr(n,b)
        z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(archive) as z:
        if z.testzip():raise ValueError('ZIP CRC')
        for n,b in contents.items():
            if sha(z.read(n))!=sha(b):raise ValueError('ZIP readback '+n)
    digest=sha(archive.read_bytes());archive.with_suffix('.sha256.txt').write_text(digest+'  '+archive.name+'\n',encoding='utf-8')
    (out/'A_DELIVERY_20261029.md').write_bytes(contents['team_work/01_video/A_DELIVERY_20261029.md'])
    record=dict(status='PASS_PACKAGE_INTEGRITY_ONLY',archive=str(archive),bytes=archive.stat().st_size,sha256=digest,files=len(contents),zip_readback_verified=True,
        hardware_30min_passed=status['continuous_30min_passed'],hardware_30min_evidence=status['continuous_30min_evidence'],hardware_30min_raw_logs_reviewed=False,a_independent_tasks_complete=True,all_A_acceptance_complete=False)
    (ROOT/'logs/a_delivery_package_20261029.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
