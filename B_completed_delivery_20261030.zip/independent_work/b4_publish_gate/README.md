# B4 publish gate

This adapter combines the independent B4 quality and temporal policies before a sample is published to fusion. It copies a sample only after the checks pass, preserves the MLX90640 validity mask and error bits, and keeps quality and temporal rejection reasons in separate 16-bit halves of a diagnostic word.

It is deliberately outside the shared ABI and final C3 backend. Integrate it after C supplies the real I2C/time backend. The included test uses synthetic fixtures only.
