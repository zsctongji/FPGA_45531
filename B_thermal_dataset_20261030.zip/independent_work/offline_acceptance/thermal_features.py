"""Offline thermal candidates; never infer a person/fall from a temperature blob."""
from collections import deque
import math
import statistics

WIDTH, HEIGHT = 32, 24


def validate_grid(grid):
    if grid.get("width") != WIDTH or grid.get("height") != HEIGHT:
        raise ValueError("expected the indexed 32x24 grid")
    values = grid.get("temperature_c")
    reasons = grid.get("pixel_reason")
    if not isinstance(values, list) or len(values) != WIDTH * HEIGHT:
        raise ValueError("expected 768 indexed temperatures")
    if not isinstance(reasons, list) or len(reasons) != len(values):
        raise ValueError("expected 768 pixel reasons")
    try:
        mask = bytes.fromhex(grid["pixel_valid_bits_hex"])
    except (KeyError, ValueError, TypeError) as e:
        raise ValueError("invalid validity mask") from e
    if len(mask) != 96:
        raise ValueError("expected 96-byte LSB-first validity mask")
    for i, value in enumerate(values):
        valid = bool(mask[i // 8] & (1 << (i % 8)))
        if valid:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError("valid pixel must be finite: " + str(i))
            if reasons[i] != "VALID":
                raise ValueError("validity/reason mismatch: " + str(i))
        elif value is not None or not isinstance(reasons[i], str) or reasons[i] == "VALID":
            raise ValueError("invalid pixel must remain null with an explicit reason: " + str(i))
    return values, mask


def analyze(grid, *, delta_c=2.0, absolute_min_c=None, min_area=3):
    if isinstance(delta_c, bool) or not isinstance(delta_c, (int, float)) or not math.isfinite(delta_c) or delta_c < 0:
        raise ValueError("delta must be finite and nonnegative")
    if absolute_min_c is not None and (isinstance(absolute_min_c, bool) or not isinstance(absolute_min_c, (int, float)) or not math.isfinite(absolute_min_c)):
        raise ValueError("absolute minimum must be finite")
    if isinstance(min_area, bool) or not isinstance(min_area, int) or not 1 <= min_area <= 768:
        raise ValueError("minimum component area must be 1..768")
    values, mask = validate_grid(grid)
    valid_values = [v for v in values if v is not None]
    invalid = [i for i, v in enumerate(values) if v is None]
    median = statistics.median(valid_values) if valid_values else None
    threshold = None if median is None else median + delta_c
    if threshold is not None and absolute_min_c is not None:
        threshold = max(threshold, absolute_min_c)
    hot = {i for i, v in enumerate(values) if v is not None and threshold is not None and v >= threshold}
    unseen, components = set(hot), []
    while unseen:
        seed = min(unseen)
        unseen.remove(seed)
        queue, pixels = deque([seed]), []
        while queue:
            i = queue.popleft()
            pixels.append(i)
            x, y = i % WIDTH, i // WIDTH
            neighbors = []
            if x: neighbors.append(i - 1)
            if x + 1 < WIDTH: neighbors.append(i + 1)
            if y: neighbors.append(i - WIDTH)
            if y + 1 < HEIGHT: neighbors.append(i + WIDTH)
            for j in neighbors:
                if j in unseen:
                    unseen.remove(j)
                    queue.append(j)
        xs, ys = [i % WIDTH for i in pixels], [i // WIDTH for i in pixels]
        temperatures = [values[i] for i in pixels]
        components.append({"area_pixels":len(pixels), "area_fraction_of_grid":len(pixels)/768,
                           "centroid_xy_pixels":[statistics.mean(xs), statistics.mean(ys)],
                           "bbox_xyxy_inclusive":[min(xs),min(ys),max(xs),max(ys)],
                           "mean_c":statistics.mean(temperatures), "peak_c":max(temperatures),
                           "indices_zero_based":sorted(pixels)})
    components.sort(key=lambda c:(-c["area_pixels"],c["indices_zero_based"][0]))
    candidates = [c for c in components if c["area_pixels"] >= min_area]
    return {"scope":"OFFLINE_THERMAL_FEATURE_ANALYSIS", "width":WIDTH,"height":HEIGHT,
            "valid_pixels":len(valid_values),"invalid_indices_zero_based":invalid,
            "coverage":len(valid_values)/768,"mask_preserved_hex":mask.hex(),
            "statistics_valid_only":{"min_c":min(valid_values) if valid_values else None,
                                     "max_c":max(valid_values) if valid_values else None,
                                     "mean_c":statistics.mean(valid_values) if valid_values else None,
                                     "median_c":median},
            "candidate_policy":{"background":"median_of_valid_pixels", "delta_c":delta_c,
                                "absolute_min_c":absolute_min_c,"threshold_c":threshold,
                                "comparison":">=","connectivity":4,"min_area_pixels":min_area,
                                "status":"EXPLORATORY_NOT_PERSON_OR_FALL_CLASSIFIER"},
            "hot_pixels":len(hot),"component_count_before_area_filter":len(components),
            "discarded_small_components":len(components)-len(candidates),
            "candidates":candidates,
            "human_or_fall_detection_validated":False}
