"""Read Ti60 ID/status/USERCODE using PyFtdi on the working Python runtime.

Uses the installed vendor PyFtdi package and Windows USB driver. No configuration
or Flash programming instructions are issued. The URL must come from inventory.
"""
import argparse
import csv
from datetime import datetime
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / 'tools/efinity/2026.1/python311/Lib/site-packages'))

def main():
    from pyftdi.bits import BitSequence
    from pyftdi.jtag import JtagEngine
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', required=True)
    args = parser.parse_args()
    record = {'checked_at': datetime.now().astimezone().isoformat(),
              'url': args.url, 'flash_modified': False,
              'configuration_programmed': False, 'status': 'STARTED'}
    engine = JtagEngine(trst=False, frequency=3E6)
    try:
        engine.configure(args.url, init=SimpleNamespace(val='', dir=''))
        engine.reset()
        record['idcode'] = f'0x{int(engine.read_dr(32)):08X}'
        if record['idcode'] != '0x10660A79':
            raise ValueError('Expected exactly the Ti60 production ID')
        # Status and USERCODE instructions as specified by the installed
        # Efinix ti_jtag_status.py. String bit order is intentional.
        for label, instruction in [('registers', '01100'), ('usercode', '01101')]:
            engine.write_ir(BitSequence(instruction, msb=True, length=5))
            record[label] = f'0x{int(engine.read_dr(32)):08X}'
        mapping = ROOT / 'tools/efinity/2026.1/pgm/bin/efx_pgm/ti_jtag_status_entries_ti60mp.csv'
        with mapping.open(encoding='utf-8') as source:
            record['configuration'] = {name: (int(record['registers'],16)>>int(index))&1
                                       for index,name in csv.reader(source) if name}
        engine.go_idle()
        engine.sync()
        record['status'] = 'READ_COMPLETED'
    except Exception as exc:
        record['status'] = 'FAILED'
        record['error'] = f'{type(exc).__name__}: {exc}'
    finally:
        engine.close()
        path = ROOT / 'logs' / ('jtag_primary_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.json')
        path.write_text(json.dumps(record, indent=2), encoding='utf-8')
        print(json.dumps(record, indent=2))
        print('REPORT', path)
    return 0 if record['status'] == 'READ_COMPLETED' else 1

if __name__ == '__main__':
    raise SystemExit(main())
