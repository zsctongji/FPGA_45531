# A 的无显示器图像导出与交接

**2026-10-30 更正：两轮各30分钟长稳由用户确认通过，18分钟中断是主动拔板。A独立任务已完成，保留联合联调待办。**

**交付时状态：当前板卡已断开；下文上板结果是已保存的历史实测，用户已确认两轮各30分钟长稳通过；18分钟中断为主动拔板。**

此页描述12无显示器工程及保留相同A2/A3接口的13显示测试工程；沿用11的SC431HAI、DDR、灰度和HDMI链路。13的灰度抽头在所有TEST显示叠加前，模型输入不包含文字/报警框。持续运行结果见 `logs/a_delivery_status_20261029.json`。

## 数据来源与边界

- A2V1：DDR 前 CSI 输出，50 MHz，4 RAW 像素/有效拍，记录真实源端宽高、完整标志、帧号和本地毫秒时间。格式延续 11。
- A3V1：DDR 读出、debayer/灰度后、运动红框之前的 `preprocess_r`，148.5 MHz。每隔 20 个像素/行采样成 96×54，上下各补 21 行，输出 9216 个 GRAY8 字节。图中不包含运动框。
- **A3 帧号与时间是显示流自己的编号和本地时间，不是 A2 源帧编号，也不是最终 SoC 共享时间。** JSON 的 `source_frame_id=null` 保留这项缺口。显示帧可能重读同一源画面；不能用 A3 间隔计算摄像头 FPS。
- 运动统计由同一份抽样流连续计算；快照对应的 changed_count、绝对差值和、有效标志及包围框与该快照一起冻结。比较对象是它的前一显示帧，不是前一张串口导出的图。
- 包围框为 96×54 网格闭区间；投到 96×96 输入图时 y 坐标加 21。它是阈值帧差范围，不是 AI 人体检测框。默认差值阈值 24、至少 32 点触发运动。
- UART 证明的是实际字节读出，不证明 C 的软核执行、推理准确率、HDMI 观察或 B 的以太网闭环。

## 缓存所有权和跨时钟

`rtl/a_gray_snapshot.v` 在下一次请求后，从 SOF 开始取得一张完整帧。最后一个采样字节在下一 VS 验证源尺寸后提交；等待同帧运动统计有效才翻转 done。半帧、格式错误和 abort 不发布。

请求 toggle 经像素域三级同步；完成 toggle 经读取域四级同步。完成通知之前，RAM 与元数据已稳定；通知后一直冻结，直到读者全部读完、等待下一次请求。像素复位异步置位、同步释放。两时钟之间只跨请求/完成通知和受该所有权保护的稳定数据；图像 RAM 为双时钟读写端口。读地址同步采样，下一读取时钟得到字节。必须读完再发新请求，不允许在写入期间读 RAM。

视频没有 ready 输入，不会等待 UART。冻结期间其余帧仍通过原显示管线，也持续更新运动历史；仅不再写快照。每次导出后等 1000 ms 再申请下一张，不能把快照速率当作采集帧率。

SDC 将 50 MHz CSI/UART 与 148.5 MHz 显示时钟声明异步；这要求上述握手和冻结协议成立，并非允许任意信号跨域。C 最终接入时须重新审查统一复位、共享时间、DDR 银行元数据和 CPU 总线。

## 串口格式

FT4232 C 通道（最近USB重连后COM30，端口可能变化），921600 baud，8N1。A2V1 每条 36 字节；A3V1 每条 300 字节。串口按完整分片调度，分片之间优先发送待处理 A2，防止图像导出阻塞源端统计。A2 的 flags、校验和字段不变。

A3V1 的所有多字节字段为 little-endian：

| 偏移 | 字节 | 字段 |
|---|---:|---|
| 0 | 4 | ASCII A3V1 |
| 4 / 8 | 各 4 | 显示 frame_id / 首个有效像素 timestamp_ms |
| 12 | 4 | 全图 SUM32，含零填充 |
| 16 / 20 | 各 4 | changed_count / absolute_difference_sum |
| 24/26/28/30 | 各 2 | min_x/min_y/max_x/max_y |
| 32 | 1 | bit0 完整；bit1 可与前一帧比较；bit2 运动；bit3 包围框有效 |
| 33 | 1 | tap=1，显示侧灰度 |
| 34 / 35 | 各 1 | 分片序号 0…35 / 总数 36 |
| 36 / 38 | 各 2 | 载荷长 256 / 保留 0 |
| 40 | 256 | 图像中 index×256 对应的连续字节 |
| 296 | 4 | 本包字节 0…295 的 SUM32 |

SUM32 用于串口误码/连接一致性检查，不是 CRC 或来源认证。PC 拒绝损坏包、元数据混帧、缺片、错误填充和全图校验不符，不保存半张图。

## 复现

从主项目执行（新诊断已加载时可直接用最后一行；所有编程均为临时 JTAG）：

```powershell
tools/run_efinity.ps1 -Project a_headless -Flow compile -CompatiblePython build/efinity_runtime_py311/python.exe
# 使用可运行的 Python 3.12 执行以下工具
python tools/release_a_camera_diag.py --headless
python tools/efinity_primary.py program-a-headless
tools/start_a_side.ps1 -Mode HeadlessCapture -SerialPort COM30 -Seconds 65 -ExpectedUsercode 0x41335631
```

13已加载时用 `tools/start_a_side.ps1 -Mode HeadlessCapture -SerialPort COM30 -Seconds 65 -ExpectedUsercode 0x41354431`。预期USERCODE只是标签，实际版本另查JTAG。也可双击 `tools/A_headless_capture.cmd` 自动找串口，默认记录12的预期版本标签。保存 raw.bin、源端 frames.csv、summary.json，以及每张图的 .gray/.pgm/.bmp/.json；BMP 可直接查看。该入口不会改网卡、防火墙或系统安全设置。

30分钟长稳已由用户确认两轮通过（每轮30分钟）。约18.9分钟那次是用户主动拔板结束，不作为稳定性失败；原串口日志和错误返回保留不改写。两轮长稳对应原始日志尚未逐一匹配复核，本项依据为用户现场确认，见 `logs/a_stability_user_confirmation_20261030.json`。A独立任务已完成，剩余为C的实际CPU/DDR/共享时间接入、B/C实时同屏与板端网络联合验收。

`tools/A_headless_preview.cmd` 或 `python tools/a_side/headless_preview.py <采集目录>` 可在127.0.0.1:39005只读预览，完全不打开串口。命令行加 `--follow-latest` 并传入 `logs/a_side/headless` 可自动跟随新采集目录；结束采集后显示最后完整快照。

J28.37/39 在此工程中为输入，J28.38 蜂鸣器低电平。旧 02/04/05 仍占用 LCD 输出，与当前传感器接线冲突，不可直接切回。11 的安全 A2 镜像仍可作回退；115200 与本工程 921600 不可混用。

## A/C、A/B 接口交接

1. C 可先用实际 .gray/.json 验证模型预处理、GRAY8 到 INT8 和补黑布局。最终要把源帧 ID/统一时间与 DDR 银行一起传递，不能拿显示编号冒充源编号。
2. `ai_frame_mailbox.v` 的双缓存与 `firmware/a_side/a_side.h` 的 acquire/read/release 回调仍是最终 CPU 接口基线。本次 UART 单快照没有 CPU MMIO 地址，也没有替 C 实现总线仲裁。
3. A5 推荐接 `video_a_result_display.v`：输入同域完整状态、三路时间戳/有效/故障掩码和稳定热图前台缓存；内部 `a_status_guard` 按年龄屏蔽过期量。默认视觉 500、热图 1000、环境 3000 ms，可参数调整；这些是接口默认值，须按 B/C 实测采样/推理周期确定最终值。状态灯顺序 IR/环境/AI/报警，绿有效、橙过期、红故障、灰缺失；AI 帧号不对应时停用分值并橙色提示。显示报警保持仍由 C 决定。
4. B 的以太网发送按 `team_work/shared/a_interface_v1.md`，PC 接收工具已可用；本 UART 不能算网络拓展验收。
