"""Host for BTEST001 independent FPGA module test; logs real bus transactions."""
import json,struct,time
from pathlib import Path
import serial
class Bridge:
 def __init__(self,port,log):
  self.serial=serial.Serial(port,115200,timeout=0.08,write_timeout=1)
  self.serial.dtr=False;self.serial.rts=False
  self.log=log;self.seq=0;self.last_ms=0
  self.serial.reset_input_buffer()
 def close(self):self.serial.close()
 def command(self,op=0,address=0,tx=b'',rx_count=0,timeout=0.5):
  if len(tx)>4 or rx_count>64:raise ValueError('transaction size')
  self.seq=(self.seq+1)&255
  body=bytes([op,self.seq,address,len(tx),rx_count])+tx.ljust(4,b'\0')
  check=0
  for b in body:check^=b
  request=b'\xa5\x5a'+body+bytes([check])
  started=time.monotonic();self.serial.write(request);buf=bytearray()
  result={'host_monotonic':started,'request_hex':request.hex(),'source':'REAL_UART_TO_FPGA_I2C_BRIDGE'}
  try:
   while time.monotonic()-started<timeout:
    buf.extend(self.serial.read(self.serial.in_waiting or 1))
    begin=buf.find(b'\x5a\xa5')
    if begin<0:
     if len(buf)>1000:del buf[:-1]
     continue
    if begin:del buf[:begin]
    if len(buf)<9:continue
    length=buf[4]
    if length>64:del buf[0];continue
    if len(buf)<10+length:continue
    response=bytes(buf[:10+length]);xor=0
    for b in response[2:-1]:xor^=b
    if xor!=response[-1] or response[2]!=self.seq:
     del buf[0];continue
    result['response_hex']=response.hex();result['status']=response[3]
    self.last_ms=struct.unpack_from('<I',response,5)[0];result['board_ms']=self.last_ms
    payload=response[9:-1]
    if response[3]!=0:raise RuntimeError('BOARD_STATUS_'+str(response[3]))
    return payload
   raise TimeoutError('no matching UART reply')
  except Exception as exc:
   result['error']=repr(exc);result['received_hex']=buf.hex();raise
  finally:
   result['duration_ms']=(time.monotonic()-started)*1000
   self.log.write(json.dumps(result)+'\n');self.log.flush()
 def read(self,address,tx,count):return self.command(1,address,tx,count)
 def read_words(self,reg,words):
  result=[]
  while words:
   n=min(32,words);raw=self.read(0x33,reg.to_bytes(2,'big'),n*2)
   if len(raw)!=n*2:raise RuntimeError('short I2C payload')
   result.extend(struct.unpack('>'+str(n)+'H',raw));words-=n;reg+=n
  return result
 def write_word(self,reg,value):self.read(0x33,reg.to_bytes(2,'big')+value.to_bytes(2,'big'),0)

def crc8(raw):
 crc=255
 for b in raw:
  crc^=b
  for _ in range(8):crc=((crc<<1)^0x31)&255 if crc&128 else (crc<<1)&255
 return crc
