"""Verify archive contents, targeted tests and fixed-session evidence. Offline only."""
import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cc")
    parser.add_argument("--output-dir",type=Path,default=ROOT/"verified_results")
    args=parser.parse_args()
    if args.cc: os.environ["B_OFFLINE_CC"]=args.cc
    manifest=json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        file=(ROOT/item["path"]).resolve()
        if not file.is_relative_to(ROOT) or not file.is_file() or file.stat().st_size!=item["bytes"] or hashlib.sha256(file.read_bytes()).hexdigest()!=item["sha256"]:
            raise SystemExit("Manifest mismatch: "+item["path"])
    suite=unittest.defaultTestLoader.discover(str(ROOT),pattern="test_offline_acceptance.py")
    stream=io.StringIO()
    tests=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    if not tests.wasSuccessful(): raise SystemExit(stream.getvalue())
    import run_offline_acceptance as runner
    report=runner.run(args.output_dir,args.cc)
    require=lambda ok,msg: None if ok else (_ for _ in ()).throw(RuntimeError(msg))
    require(report["sht30"]["raw_valid_samples"]==100 and report["sht30"]["failed_cycles"]==4,"fixed SHT evidence changed")
    require(report["sht30"]["host_gate_accepted"]==100 and report["sht30"]["host_gate_rejected"]==4,"SHT replay decision changed")
    require(report["thermal_features"]["invalid_indices_zero_based"]==[620] and report["thermal_features"]["valid_pixels"]==767,"fixed thermal mask changed")
    require(report["thermal_timing"]["oldest_completion_age_lower_bound_at_second_completion_ms"]==625,"fixed timing changed")
    require(report["thermal_policy"]["oldest_subpage_age_lower_bound_probe"]["rc"]==-5,"over-age data was not blocked")
    require(report["release_decision"]["release_allowed"] is False,"incomplete evidence was released")
    # Deliberately damage only a disposable copy; source evidence is never edited.
    with tempfile.TemporaryDirectory(prefix="b_offline_tamper_") as temp:
        scratch=Path(temp)
        for name in ("inputs","vendor"):shutil.copytree(ROOT/name,scratch/name)
        for name in ("gray96_adapter.py","provenance.json"):shutil.copy2(ROOT/name,scratch/name)
        file=scratch/"inputs/mlx90640/frame0_u16_be.bin"
        bad=bytearray(file.read_bytes());bad[0]^=1;file.write_bytes(bad)
        saved_root=runner.ROOT
        try:
            runner.ROOT=scratch
            caught=False
            try:runner.verify_provenance()
            except ValueError:caught=True
            require(caught,"input corruption was not detected")
        finally:runner.ROOT=saved_root
    verification={"status":"PASS","scope":"CLEAN_BUNDLE_OFFLINE_VERIFICATION","hardware_accessed":False,
                  "new_board_measurements":0,"manifest_files_verified":len(manifest["files"]),
                  "targeted_tests":tests.testsRun,"original_c_gate_compiled":True,
                  "saved_sht_rows_replayed":104,"tampered_disposable_input_rejected":True,
                  "release_allowed":False,"release_status":report["release_decision"]["status"]}
    args.output_dir.mkdir(parents=True,exist_ok=True)
    (args.output_dir/"verification.json").write_text(json.dumps(verification,indent=2)+"\n",encoding="utf-8")
    (args.output_dir/"targeted_tests.log").write_text(stream.getvalue(),encoding="utf-8")
    print(json.dumps(verification,indent=2))

if __name__=="__main__":main()
