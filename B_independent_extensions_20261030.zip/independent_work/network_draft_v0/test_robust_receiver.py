import sys
import struct
import unittest
import zlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from robust_receiver import B6Receiver
HEADER = struct.Struct("!4sBBH7I6H")
IMAGE_BYTES = 96 * 96

def packets(image, event=1, frame=2, capture=100):
    result = []
    for index, offset in enumerate(range(0, len(image), 1200)):
        payload = image[offset:offset + 1200]
        result.append(HEADER.pack(b"B6D0", 0, 1, 48, event, frame, capture,
                                  len(image), zlib.crc32(image), offset, zlib.crc32(payload),
                                  96, 96, 96, index, 8, len(payload)) + payload)
    return result

class RobustReceiverTests(unittest.TestCase):
    def test_out_of_order_duplicate_and_completion(self):
        image = bytes((i * 13 + 7) & 255 for i in range(IMAGE_BYTES))
        p, r, frames = packets(image), B6Receiver(ttl_ms=100), []
        for t, i in enumerate([7, 1, 7, 0, 6, 2, 5, 3, 4], start=10):
            got = r.ingest(p[i], arrival_ms=t, source=("sender", 5000))
            if got is not None: frames.append(got)
        self.assertEqual([f.image for f in frames], [image])
        self.assertEqual(r.stats.duplicate_packets, 1)
        self.assertFalse(r.sessions)

    def test_identical_identity_sources_do_not_mix(self):
        p, r = packets(bytes(IMAGE_BYTES)), B6Receiver()
        for i in range(8):
            r.ingest(p[i], arrival_ms=i, source="A" if i < 4 else "B")
        self.assertEqual(len(r.sessions), 2)
        self.assertEqual(r.stats.completed_frames, 0)
        for i in range(4, 8): r.ingest(p[i], arrival_ms=10+i, source="A")
        for i in range(4): r.ingest(p[i], arrival_ms=20+i, source="B")
        self.assertEqual(r.stats.completed_frames, 2)

    def test_expiry_exact_boundary(self):
        r = B6Receiver(ttl_ms=20)
        r.ingest(packets(bytes(IMAGE_BYTES))[0], arrival_ms=100)
        self.assertEqual(r.expire(119), 0)
        self.assertEqual(r.expire(120), 1)

    def test_valid_crc_conflict_discards_session(self):
        p, r = packets(bytes(IMAGE_BYTES)), B6Receiver()
        r.ingest(p[0], arrival_ms=1)
        changed = bytearray(p[0]); changed[-1] ^= 1
        # Chunk CRC is repaired: this reaches the true duplicate conflict path.
        changed[32:36] = struct.pack("!I", zlib.crc32(changed[48:]))
        with self.assertRaisesRegex(ValueError, "conflicting_duplicate"):
            r.ingest(bytes(changed), arrival_ms=2)
        self.assertEqual(r.stats.conflicting_duplicates, 1)
        self.assertEqual(r.stats.malformed_packets, 0)
        self.assertFalse(r.sessions)

    def test_bad_chunk_crc(self):
        p, r = packets(bytes(IMAGE_BYTES)), B6Receiver()
        bad = bytearray(p[0]); bad[-1] ^= 1
        with self.assertRaisesRegex(ValueError, "chunk_crc_mismatch"):
            r.ingest(bytes(bad), arrival_ms=1)
        self.assertEqual(r.stats.malformed_packets, 1)
        self.assertFalse(r.sessions)

    def test_bad_image_crc(self):
        p, r = packets(bytes(IMAGE_BYTES)), B6Receiver()
        p = [v[:24] + struct.pack("!I", zlib.crc32(bytes(IMAGE_BYTES)) ^ 1) + v[28:] for v in p]
        for i in range(7): r.ingest(p[i], arrival_ms=i)
        with self.assertRaises(ValueError): r.ingest(p[7], arrival_ms=7)
        self.assertEqual(r.stats.image_crc_failures, 1)
        self.assertFalse(r.sessions)

    def test_capacity_evicts_oldest_across_wrap(self):
        r = B6Receiver(ttl_ms=100, max_sessions=2)
        for source, t in [("A", 0xFFFFFFF0), ("B", 1), ("C", 2)]:
            r.ingest(packets(bytes(IMAGE_BYTES))[0], arrival_ms=t, source=source)
        self.assertEqual({key[0] for key in r.sessions}, {"B", "C"})
        self.assertEqual(r.stats.dropped_sessions, 1)

    def test_expiry_across_wrap(self):
        r = B6Receiver(ttl_ms=20)
        r.ingest(packets(bytes(IMAGE_BYTES))[0], arrival_ms=0xFFFFFFF8)
        self.assertEqual(r.expire(11), 0)
        self.assertEqual(r.expire(12), 1)

    def test_reject_backwards_clock_without_expiring(self):
        r = B6Receiver(); p = packets(bytes(IMAGE_BYTES))
        r.ingest(p[0], arrival_ms=100)
        with self.assertRaisesRegex(ValueError, "clock_moved_backwards"):
            r.ingest(p[1], arrival_ms=99)
        self.assertEqual(len(r.sessions), 1)
        self.assertEqual(r.stats.expired_sessions, 0)
        r.ingest(p[1], arrival_ms=101)

    def test_duplicate_does_not_extend_lifetime(self):
        r, p = B6Receiver(ttl_ms=20), packets(bytes(IMAGE_BYTES))
        r.ingest(p[0], arrival_ms=10)
        r.ingest(p[0], arrival_ms=29)
        self.assertEqual(r.expire(30), 1)

    def test_whole_frame_replay_suppressed(self):
        r, p = B6Receiver(ttl_ms=100), packets(bytes(IMAGE_BYTES))
        for i in range(8): r.ingest(p[i], arrival_ms=i)
        for i in range(8): self.assertIsNone(r.ingest(p[i], arrival_ms=10+i))
        self.assertEqual(r.stats.completed_frames, 1)
        self.assertEqual(r.stats.replayed_packets, 8)
        self.assertFalse(r.sessions)
        r.expire(107)
        for i in range(8): r.ingest(p[i], arrival_ms=110+i)
        self.assertEqual(r.stats.completed_frames, 2)

    def test_recent_cache_capacity_and_boot_identity(self):
        r, p = B6Receiver(max_recent=1), packets(bytes(IMAGE_BYTES))
        for boot in ("boot1", "boot2"):
            for i in range(8): r.ingest(p[i], arrival_ms=10 if boot == "boot1" else 20, source=("A", boot))
        self.assertEqual(r.stats.completed_frames, 2)
        self.assertEqual(len(r.recent), 1)

    def test_invalid_clock_inputs(self):
        for v in (-1, 2**32, True, 1.2, None):
            with self.subTest(v=v):
                r = B6Receiver()
                with self.assertRaises(ValueError): r.expire(v)
                with self.assertRaises(ValueError): r.ingest(b"", arrival_ms=v)
                self.assertIsNone(r._last_now)

    def test_invalid_configuration(self):
        for args in ({"ttl_ms":0}, {"ttl_ms":2**31}, {"ttl_ms":True}, {"max_sessions":0}, {"max_recent":0}):
            with self.assertRaises(ValueError): B6Receiver(**args)

if __name__ == "__main__": unittest.main(verbosity=2)
