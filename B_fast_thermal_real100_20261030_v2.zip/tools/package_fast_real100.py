"""Package corrected diagnostics and preserved real-board evidence; no device I/O."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "standalone_sensor_fast"
NAME = "B_fast_thermal_real100_20261030_v2"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    archive = BASE / "artifacts" / (NAME + ".zip")
    if archive.exists():
        raise RuntimeError("Preserve the existing delivery; choose a new version")
    stamp = datetime.now().strftime("%H%M%S_%f")
    stage = BASE / "artifacts" / (NAME + "_stage_" + stamp)
    clean = BASE / "artifacts" / (NAME + "_clean_" + stamp)
    stage.mkdir()
    for folder in ("src", "constraints", "host", "tests", "native", "vendor", "fixtures", "logs"):
        for path in sorted((SOURCE / folder).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix in (".pyc", ".vvp"):
                continue
            target = stage / "standalone_sensor_fast" / path.relative_to(SOURCE)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    for name in ("B_sensor_fast.xml", "B_sensor_fast.peri.xml", "README.md", "verify_fast_bundle.py",
                 "outflow/B_sensor_fast.bit", "outflow/B_sensor_fast.pinout.csv",
                 "outflow/B_sensor_fast.timing.rpt", "outflow/B_sensor_fast.warn.log"):
        target = stage / "standalone_sensor_fast" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / name, target)
    source_stage = stage / "standalone_sensor_fast"
    manifest = {"scope": "STANDALONE_MLX_DIAGNOSTIC_WITH_REAL_BOARD_EVIDENCE",
                "contains_real_board_records": True,
                "primary_run": "logs/real_fast_20261030_184934_752153",
                "new_primary_real_thermal_pairs": 100,
                "final_soc_release": "BLOCKED_BY_EVIDENCE",
                "files_sha256": {p.relative_to(source_stage).as_posix(): sha(p)
                                 for p in sorted(source_stage.rglob("*")) if p.is_file()}}
    encoded = json.dumps(manifest, indent=2) + "\n"
    (source_stage / "bundle_manifest.json").write_text(encoded, encoding="utf-8")
    (SOURCE / "bundle_manifest.json").write_text(encoded, encoding="utf-8")
    for name in ("tools/audit_fast_real100.py", "tools/package_fast_real100.py",
                 "records/B_fast_thermal_real100_audit_20261030.json",
                 "records/B_热成像100组实测交接_20261030.md"):
        target = stage / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(BASE / name, target)
    (stage / "README.md").write_text(
        "# Ti60F225 real-board thermal delivery\n\n"
        "Read records/B_热成像100组实测交接_20261030.md.\n"
        "Offline: python -B standalone_sensor_fast/verify_fast_bundle.py\n"
        "Offline raw-evidence audit: python -B tools/audit_fast_real100.py --verify-only\n"
        "100 real thermal pairs; not final C3 or fall-detection acceptance.\n", encoding="utf-8")
    package_manifest = {p.relative_to(stage).as_posix(): sha(p)
                        for p in sorted(stage.rglob("*")) if p.is_file()}
    (stage / "DELIVERY_MANIFEST.json").write_text(json.dumps(package_manifest, indent=2)+"\n", encoding="utf-8")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(stage.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(stage))
    with zipfile.ZipFile(archive) as z:
        z.extractall(clean)
    assert all(sha(clean/name) == value for name,value in package_manifest.items())
    outputs = []
    for command in ([sys.executable, "-B", str(clean/"standalone_sensor_fast/verify_fast_bundle.py")],
                    [sys.executable, "-B", str(clean/"tools/audit_fast_real100.py"), "--verify-only"]):
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8")
        outputs.append(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError("Clean verification failed: " + outputs[-1])
    assert all(sha(clean/name) == value for name,value in package_manifest.items())
    log = BASE / "records" / (NAME + "_clean_verify.log")
    log.write_text("\n".join(outputs), encoding="utf-8")
    report = {"status": "CLEAN_EXTRACTION_HASH_TESTS_AND_REAL100_AUDIT_PASSED",
              "at": datetime.now().astimezone().isoformat(), "verification_accessed_hardware": False,
              "archive": str(archive), "archive_bytes": archive.stat().st_size,
              "archive_sha256": sha(archive), "package_files_checked": len(package_manifest),
              "host_tests": 32, "new_primary_real_thermal_pairs": 100,
              "raw_record_hashes_checked": 612, "uart_transactions_checked": 12959,
              "temperatures_independently_recalculated": 100,
              "configuration_restored": "VERIFIED_0x1901", "wrote_flash": False,
              "buzzer_on_commands_sent": 0, "clean_directory": str(clean), "log": str(log),
              "final_soc_shared_clock_and_fall_detection": "NOT_VALIDATED",
              "github_upload": "PENDING_PUSH"}
    (BASE/"records"/(NAME+"_clean_verify.json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    (BASE/"artifacts"/(NAME+".sha256.txt")).write_text(sha(archive)+"  "+archive.name+"\n",encoding="ascii")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
