// Complete display-side gray snapshot. RAM is frozen from completion until the
// next request: request/done toggles transfer ownership across the two clocks.
// Metadata is bundled with done and stays stable while the reader owns RAM.
// No ready/backpressure path returns to video. This is not a CPU bus adapter.
module a_gray_snapshot #(
    parameter PIX_HZ=148500000, WIDTH=1920, HEIGHT=1080, STEP=20
)(
    input wire pixel_clk, read_clk, rst_n, in_vs, in_de,
    input wire [7:0] in_gray,
    input wire request_toggle,
    input wire [15:0] read_address,
    output reg [7:0] read_data,
    output reg done_toggle,
    output reg [31:0] frame_id,timestamp_ms,checksum,changed_count,difference_sum,
    output reg [15:0] min_x,min_y,max_x,max_y,
    output reg [7:0] flags
);
    localparam GW=(WIDTH+STEP-1)/STEP, GH=(HEIGHT+STEP-1)/STEP;
    localparam N=GW*GH, PAD=GW*((GW-GH)/2);
    reg [7:0] memory[0:N-1];
    // Assert reset asynchronously, release only on pixel clock edges.
    (* async_reg="true" *) reg [2:0] reset_sync;
    always @(posedge pixel_clk or negedge rst_n)
        if(!rst_n)reset_sync<=0;else reset_sync<={reset_sync[1:0],1'b1};
    wire pixel_reset_n=reset_sync[2];
    reg [31:0] tick,now_ms;
    (* async_reg="true" *) reg [2:0] request_sync;
    wire sv,ss,se,sa,stat_valid,comparison,motion,stat_error,box_valid;
    wire [7:0] gray;
    wire [31:0] fid,stamp,changed,diff;
    wire [15:0] bx0,by0,bx1,by1;
    video_a_capture #(.FRAME_WIDTH(WIDTH),.FRAME_HEIGHT(HEIGHT),.STEP_X(STEP),.STEP_Y(STEP)) tap(
        .clk(pixel_clk),.rst_n(pixel_reset_n),.in_vs(in_vs),.in_de(in_de),.in_gray(in_gray),.now_ms(now_ms),
        .sample_valid(sv),.sample_sof(ss),.sample_eof(se),.sample_abort(sa),.sample_gray(gray),
        .sample_frame_id(fid),.sample_timestamp_ms(stamp));
    frame_motion_stats #(.WIDTH(GW),.HEIGHT(GH)) stats(
        .clk(pixel_clk),.rst_n(pixel_reset_n),.in_valid(sv),.in_sof(ss),.in_eof(se),.in_abort(sa),.in_gray(gray),
        .out_valid(stat_valid),.comparison_valid(comparison),.motion(motion),.frame_error(stat_error),
        .changed_count(changed),.absolute_difference_sum(diff),.bbox_valid(box_valid),
        .min_x(bx0),.min_y(by0),.max_x(bx1),.max_y(by1));
    reg capturing,waiting_stats;
    reg [15:0] count;
    reg [31:0] sum;
    wire start=sv&&ss&&(request_sync[2]!=done_toggle)&&!capturing&&!waiting_stats&&!sa;
    wire write_pixel=start||(sv&&capturing&&!sa);
    wire [15:0] address=start?16'd0:count;
    // True dual-clock RAM. Ownership ensures the two ports never access a
    // changing frame concurrently; no asynchronous data bus is sampled live.
    always @(posedge pixel_clk) if(pixel_reset_n&&write_pixel&&address<N)memory[address]<=gray;
    always @(posedge read_clk) begin
        if(read_address>=PAD&&read_address<PAD+N)read_data<=memory[read_address-PAD];
        else read_data<=0;
    end
    always @(posedge pixel_clk or negedge pixel_reset_n) begin
        if(!pixel_reset_n)begin
            tick<=0;now_ms<=0;request_sync<=0;done_toggle<=0;capturing<=0;waiting_stats<=0;
            count<=0;sum<=0;frame_id<=0;timestamp_ms<=0;checksum<=0;changed_count<=0;difference_sum<=0;
            min_x<=0;min_y<=0;max_x<=0;max_y<=0;flags<=0;
        end else begin
            request_sync<={request_sync[1:0],request_toggle};
            if(tick==PIX_HZ/1000-1)begin tick<=0;now_ms<=now_ms+1;end else tick<=tick+1;
            if(start)begin
                capturing<=1;count<=1;sum<=gray;frame_id<=fid;timestamp_ms<=stamp;
            end else if(sv&&capturing&&!sa)begin
                count<=count+1'b1;sum<=sum+gray;
                if(se)begin
                    capturing<=0;
                    if(count==N-1)begin waiting_stats<=1;checksum<=sum+gray;end
                end
            end
            if(sa)begin capturing<=0;waiting_stats<=0;end
            if(waiting_stats&&stat_valid)begin
                changed_count<=changed;difference_sum<=diff;
                min_x<=bx0;min_y<=by0;max_x<=bx1;max_y<=by1;
                flags<={4'b0,box_valid,motion,comparison,1'b1};
                done_toggle<=request_sync[2];waiting_stats<=0;
            end
        end
    end
endmodule
