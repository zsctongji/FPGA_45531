"""Explicit opt-in, bounded MLX speed diagnostic. Importing does not access hardware."""
import argparse
from collections import Counter
from dataclasses import asdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import time

from fast_bridge import FastBridge
from thermal_calculate import Calculator, write_u16
from thermal_scheduler import CaptureError, FrameReader, PairAssembler, refresh_control


def save_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def acquire(bridge, directory, *, pairs=10, max_subpages=60, duration_s=45,
            refresh_code=3, clock=time.monotonic):
    """Device-independent orchestration; inject bridge/clock for offline testing."""
    directory = Path(directory)
    report = {"scope":"STANDALONE_MLX_DIAGNOSTIC", "status":"STARTED", "target_pairs":pairs,
              "subpages_saved":0, "accepted_pairs":0, "rejections":{},
              "wrote_flash":False, "buzzer_on_commands_sent":0,
              "final_soc_or_shared_clock_verified":False,"exposure_age_verified":False,
              "observed_pair_limit_ms":500,"control_restore":"NOT_NEEDED"}
    original = None
    changed = False
    accepted, rejects = [], Counter()
    started = clock()
    try:
        report["identity"] = bridge.identify().decode("ascii")
        eeprom = bridge.read_words(0x2400,832)
        write_u16(directory/"eeprom_u16_be.bin",eeprom)
        original = bridge.read_words(0x800d,1)[0]
        desired = refresh_control(original,refresh_code)
        report.update(original_control=original,requested_control=desired,refresh_code=refresh_code)
        # Record before sending, since a failed reply does not prove the write failed.
        changed = desired != original
        if changed:
            report["control_restore"] = "REQUIRED"
            bridge.write_word(0x800d,desired)
        actual = bridge.read_words(0x800d,1)[0]
        report["verified_control"] = actual
        if actual != desired: raise CaptureError("control register readback mismatch")
        bridge.write_word(0x8000,0x0030)  # discard ready state from the previous setting
        reader, assembler = FrameReader(bridge,clock=clock), PairAssembler(500)
        for attempt in range(1,max_subpages+1):
            remaining = duration_s-(clock()-started)
            if remaining <= 0: break
            try:
                frame = reader.capture(budget_ms=min(1200,remaining*1000))
            except CaptureError as exc:
                assembler.reset()
                rejects[str(exc)] += 1
                with (directory/"rejections.jsonl").open("a",encoding="utf-8") as stream:
                    stream.write(json.dumps({"attempt":attempt,"reason":str(exc),"board_ms":bridge.last_ms})+"\n")
                continue
            index = report["subpages_saved"]
            name = f"subpage_{index:03d}"
            write_u16(directory/(name+"_u16_be.bin"),frame.words)
            detail = asdict(frame)
            del detail["words"]
            detail.update(page=frame.page,control=frame.control,attempt=attempt,
                          raw_file=name+"_u16_be.bin")
            save_json(directory/(name+".json"),detail)
            report["subpages_saved"] += 1
            paired = assembler.push(frame)
            if paired["status"] == "PAIRED_FOR_DIAGNOSTIC_ANALYSIS":
                pair = paired.pop("frames")
                accepted.append(pair)
                paired["subpage_files"] = [f"subpage_{index-1:03d}_u16_be.bin",name+"_u16_be.bin"]
                save_json(directory/f"pair_{len(accepted)-1:03d}.json",paired)
                report["accepted_pairs"] = len(accepted)
                if len(accepted) >= pairs: break
            elif paired["status"] != "WAITING_FOR_OTHER_SUBPAGE":
                rejects[paired["status"]] += 1
        report["status"] = "CAPTURED_REQUESTED_DIAGNOSTIC_PAIRS" if len(accepted)>=pairs else "INSUFFICIENT_TIMELY_PAIRS"
    except Exception as exc:
        report.update(status="ERROR",error=repr(exc))
    finally:
        if changed and original is not None:
            if bridge.failed:
                report["control_restore"] = "UNCONFIRMED_TRANSPORT_FAILED_REOPEN_REQUIRED"
            else:
                try:
                    bridge.write_word(0x800d,original)
                    restored = bridge.read_words(0x800d,1)[0]
                    report["restored_control"] = restored
                    report["control_restore"] = "VERIFIED" if restored==original else "READBACK_MISMATCH"
                except Exception as exc:
                    report.update(control_restore="FAILED",control_restore_error=repr(exc))
        report["rejections"] = dict(rejects)
        report["host_elapsed_s"] = clock()-started
        # Preserve acquisition evidence before any offline temperature calculation.
        save_json(directory/"acquisition_summary.json",report)
    return report, accepted


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-hardware",action="store_true",help="explicitly enable UART acquisition")
    parser.add_argument("--port",help="confirmed UART port; never automatically tries other ports")
    parser.add_argument("--ftdi-serial",help="optional exact UART interface serial; use D2XX with 1 ms latency and restore it on close")
    parser.add_argument("--out",type=Path)
    parser.add_argument("--pairs",type=int,default=10)
    parser.add_argument("--max-subpages",type=int,default=60)
    parser.add_argument("--duration-s",type=float,default=45)
    parser.add_argument("--refresh-code",type=int,default=3)
    args = parser.parse_args(argv)
    if not args.run_hardware:
        print(json.dumps({"status":"OFFLINE_PLAN_ONLY","hardware_accessed":False,
                          "identity_required":"BQFAST01","uart_host_baud":921600,
                          "next":"load verified SRAM image, then provide confirmed --port and --run-hardware"}))
        return 0
    if not args.port: parser.error("--run-hardware requires an explicitly confirmed --port")
    if not 1<=args.pairs<=100 or not 2<=args.max_subpages<=1000 or not 1<=args.duration_s<=600 or not 0<=args.refresh_code<=7:
        parser.error("invalid finite capture limits")
    calculator = Calculator()  # fail before opening hardware if algorithm is unavailable
    output = args.out or Path(__file__).resolve().parents[1]/"logs"/datetime.now().strftime("real_fast_%Y%m%d_%H%M%S_%f")
    output.mkdir(parents=True,exist_ok=False)
    with (output/"uart_transactions.jsonl").open("w",encoding="utf-8") as log:
        if args.ftdi_serial:
            from d2xx_transport import D2xxTransport
            bridge = FastBridge(D2xxTransport.open(args.ftdi_serial,args.port),log)
        else:
            bridge = FastBridge.open(args.port,log)
        try:
            report, pairs = acquire(bridge,output,pairs=args.pairs,max_subpages=args.max_subpages,
                                    duration_s=args.duration_s,refresh_code=args.refresh_code)
        finally:
            bridge.close()
    # Serial is closed before numerical processing, so computation cannot delay reads.
    eeprom_path = output/"eeprom_u16_be.bin"
    from thermal_calculate import read_u16
    try:
        eeprom = read_u16(eeprom_path,832) if pairs else None
        for index, pair in enumerate(pairs):
            save_json(output/f"temperature_{index:03d}.json",calculator.pair(eeprom,[f.words for f in pair]))
        report["offline_calculation"] = "PASS" if pairs else "NO_PAIRS"
    except Exception as exc:
        report.update(offline_calculation="ERROR",calculation_error=repr(exc))
    report["port"] = args.port
    report["files_sha256"] = {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(output.iterdir()) if f.is_file() and f.name!="summary.json"}
    save_json(output/"summary.json",report)
    print(json.dumps({"output":str(output),**report},ensure_ascii=False,indent=2))
    return 0 if (report["status"]=="CAPTURED_REQUESTED_DIAGNOSTIC_PAIRS" and report["offline_calculation"]=="PASS" and report["control_restore"] in ("NOT_NEEDED","VERIFIED")) else 1


if __name__ == "__main__": raise SystemExit(main())
