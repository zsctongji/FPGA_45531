"""Bounded desktop reassembly for the B6D0 draft (not board Ethernet).
arrival_ms is the receiver's monotonic uint32 clock, not capture_ms.
A source may include a caller-supplied boot/session identifier; the wire does not.
"""
from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass
from typing import Hashable
from draft_receiver import IMAGE_BYTES, PACKET_COUNT, FrameReassembler, parse_packet

HALF_RANGE = 0x80000000

def elapsed_u32(now: int, then: int) -> int:
    return (now - then) & 0xFFFFFFFF

def uint32(value: int) -> bool:
    return type(value) is int and 0 <= value <= 0xFFFFFFFF

@dataclass(frozen=True)
class CompletedFrame:
    source: Hashable
    event_id: int
    frame_id: int
    capture_ms: int
    image: bytes

@dataclass
class ReceiverStats:
    packets_seen: int = 0
    packets_accepted: int = 0
    malformed_packets: int = 0
    duplicate_packets: int = 0
    conflicting_duplicates: int = 0
    expired_sessions: int = 0
    dropped_sessions: int = 0
    completed_frames: int = 0
    image_crc_failures: int = 0
    replayed_packets: int = 0

@dataclass
class _Session:
    first_arrival_ms: int
    reassembler: FrameReassembler

class B6Receiver:
    """Hard frame lifetime and bounded recent-completion suppression.

    Clock steps must be nonnegative and less than 2^31 ms (including wrap).
    Duplicates never extend a frame's lifetime. Recently completed identities
    are suppressed for ttl_ms, subject to max_recent capacity. This is not a
    durable exactly-once service; callers must supply boot identity if needed.
    """
    def __init__(self, *, ttl_ms=2000, max_sessions=8, max_recent=64):
        if type(ttl_ms) is not int or not 0 < ttl_ms < HALF_RANGE:
            raise ValueError("ttl_ms must be in (0, 2^31)")
        if type(max_sessions) is not int or not 1 <= max_sessions <= 1024:
            raise ValueError("max_sessions must be between 1 and 1024")
        if type(max_recent) is not int or not 1 <= max_recent <= 4096:
            raise ValueError("max_recent must be between 1 and 4096")
        self.ttl_ms, self.max_sessions, self.max_recent = ttl_ms, max_sessions, max_recent
        self.sessions: dict[tuple[Hashable, tuple], _Session] = {}
        self.recent = OrderedDict()
        self.stats = ReceiverStats()
        self._last_now = None

    def _observe_time(self, now_ms):
        if not uint32(now_ms):
            raise ValueError("arrival_ms must be uint32")
        if self._last_now is not None and elapsed_u32(now_ms, self._last_now) >= HALF_RANGE:
            raise ValueError("receiver_clock_moved_backwards")
        self._last_now = now_ms

    def _expire(self, now_ms):
        for key in list(self.sessions):
            if elapsed_u32(now_ms, self.sessions[key].first_arrival_ms) >= self.ttl_ms:
                del self.sessions[key]
                self.stats.expired_sessions += 1
        for key in list(self.recent):
            if elapsed_u32(now_ms, self.recent[key]) >= self.ttl_ms:
                del self.recent[key]

    def ingest(self, packet: bytes, *, arrival_ms: int, source: Hashable = "default") -> CompletedFrame | None:
        hash(source)
        self._observe_time(arrival_ms)
        self.stats.packets_seen += 1
        self._expire(arrival_ms)
        try:
            identity, index, _ = parse_packet(packet)
        except ValueError:
            self.stats.malformed_packets += 1
            raise
        key = (source, identity)
        if key in self.recent:
            self.stats.replayed_packets += 1
            return None
        session = self.sessions.get(key)
        if session is None:
            if len(self.sessions) >= self.max_sessions:
                # Insertion order is creation order even across uint32 wrap.
                del self.sessions[next(iter(self.sessions))]
                self.stats.dropped_sessions += 1
            session = _Session(arrival_ms, FrameReassembler())
            self.sessions[key] = session
        duplicate = index in session.reassembler.chunks
        try:
            session.reassembler.add(packet)
        except ValueError as exc:
            if str(exc) == "conflicting_duplicate":
                self.stats.conflicting_duplicates += 1
                del self.sessions[key]
            raise
        if duplicate:
            self.stats.duplicate_packets += 1
        else:
            self.stats.packets_accepted += 1
        if len(session.reassembler.chunks) != PACKET_COUNT:
            return None
        try:
            image = session.reassembler.finish()
            if len(image) != IMAGE_BYTES:
                raise ValueError("completed_image_size")
        except ValueError:
            self.stats.image_crc_failures += 1
            del self.sessions[key]
            raise
        del self.sessions[key]
        if len(self.recent) >= self.max_recent:
            self.recent.popitem(last=False)
        self.recent[key] = arrival_ms
        self.stats.completed_frames += 1
        return CompletedFrame(source, identity[0], identity[1], identity[2], image)

    def expire(self, now_ms: int) -> int:
        self._observe_time(now_ms)
        before = len(self.sessions)
        self._expire(now_ms)
        return before - len(self.sessions)
