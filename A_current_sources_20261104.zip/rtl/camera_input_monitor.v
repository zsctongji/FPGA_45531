// Observe the camera ingress before DDR. No ready/backpressure; one record per VS.
// now_ms must be coherent in clk (C supplies the shared-time CDC adapter).
// LINE_FROM_HS=0: each DE run is a line (continuous display stream).
// LINE_FROM_HS=1: HS is line-active and DE may have CSI payload bubbles.
// Each valid beat has PIXELS_PER_CLOCK pixels. Normalize VS before this module.
// VS is active high blanking; the rising edge closes the preceding frame.
module camera_input_monitor #(
    parameter EXPECTED_WIDTH = 1920,
    parameter EXPECTED_HEIGHT = 1080,
    parameter PIXELS_PER_CLOCK = 4,
    parameter LINE_FROM_HS = 0
)(
    input wire clk, rst_n, in_vs, in_de, in_hs,
    input wire [31:0] now_ms,
    // Only qualified transport faults, not FIFO-empty/activity status bits.
    input wire [15:0] transport_errors,
    output reg record_valid, record_complete,
    output reg [31:0] record_frame_id, record_timestamp_ms,
    output reg [15:0] record_width, record_height, record_errors,
    output reg [31:0] source_frames, malformed_frames
);
    reg vs_d, hs_d, opened, seen_pixel, bad;
    reg [31:0] frame_id, first_pixel_ms;
    reg [15:0] line_pixels, lines, max_width, faults;
    wire boundary = in_vs && !vs_d;
    wire line_end = LINE_FROM_HS ? (hs_d && !in_hs) : !in_de;
    wire [16:0] final_lines = {1'b0, lines} + (line_pixels != 0);
    wire [15:0] final_width = line_pixels > max_width ? line_pixels : max_width;
    wire final_bad = bad || !seen_pixel || in_de ||
        (line_pixels != 0 && line_pixels != EXPECTED_WIDTH) ||
        final_lines != EXPECTED_HEIGHT || final_width != EXPECTED_WIDTH ||
        (faults | transport_errors) != 0;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_d <= 0; hs_d <= 0; opened <= 0; seen_pixel <= 0; bad <= 0;
            frame_id <= 0; first_pixel_ms <= 0;
            line_pixels <= 0; lines <= 0; max_width <= 0; faults <= 0;
            record_valid <= 0; record_complete <= 0;
            record_frame_id <= 0; record_timestamp_ms <= 0;
            record_width <= 0; record_height <= 0; record_errors <= 0;
            source_frames <= 0; malformed_frames <= 0;
        end else begin
            vs_d <= in_vs;
            hs_d <= in_hs;
            record_valid <= 0;
            if (boundary) begin
                if (opened) begin
                    record_valid <= 1;
                    record_complete <= !final_bad;
                    record_frame_id <= frame_id;
                    record_timestamp_ms <= first_pixel_ms;
                    record_width <= final_width;
                    record_height <= final_lines[16] ? 16'hffff : final_lines[15:0];
                    record_errors <= faults | transport_errors;
                    if (final_bad) malformed_frames <= malformed_frames + 1;
                end
                opened <= 1;
                frame_id <= source_frames;
                source_frames <= source_frames + 1;
                first_pixel_ms <= now_ms; // empty-frame diagnostic fallback
                seen_pixel <= 0; line_pixels <= 0; lines <= 0;
                max_width <= 0; faults <= 0; bad <= in_de;
            end else if (opened) begin
                faults <= faults | transport_errors;
                if (in_de) begin
                    if (!seen_pixel) begin
                        first_pixel_ms <= now_ms;
                        seen_pixel <= 1;
                    end
                    if (in_vs) bad <= 1;
                    if (line_pixels > 65535 - PIXELS_PER_CLOCK) begin
                        line_pixels <= 16'hffff;
                        bad <= 1;
                    end else line_pixels <= line_pixels + PIXELS_PER_CLOCK;
                end else if (line_end && line_pixels != 0) begin
                    if (line_pixels != EXPECTED_WIDTH) bad <= 1;
                    if (line_pixels > max_width) max_width <= line_pixels;
                    if (lines == 16'hffff) bad <= 1;
                    else lines <= lines + 1;
                    line_pixels <= 0;
                end
            end
        end
    end
endmodule
