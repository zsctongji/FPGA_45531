"""Freeze byte-exact hardware gray samples and a clearly labelled data preview."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import shutil
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]

def main():
    first=ROOT/'logs/a_side/headless/20261029_first_capture'
    run=ROOT/'logs/a_side/headless/20261029_stability_30min'
    target=ROOT/'team_work/01_video/ai_samples_20261029';target.mkdir(parents=True,exist_ok=True)
    selected=[('still_before',first/'frame_0000001248'),('hand_response_1',run/'frame_0000037884'),
              ('hand_response_2',run/'frame_0000038091'),('object_pattern',run/'frame_0000071760')]
    after=[]
    for p in run.glob('frame_*.json'):
        m=json.loads(p.read_text(encoding='utf-8'))
        if m['frame_id']>38160 and m['changed_count']==0:after.append((m['frame_id'],p.with_suffix('')))
    if not after:raise ValueError('No post-action still sample')
    selected.append(('still_after',min(after)[1]))
    manifest=dict(created_utc=datetime.now(timezone.utc).isoformat(),evidence='actual_FPGA_UART_gray',
        human_action='user confirmed palm movement/removal and patterned object placed in front of camera',
        visible_object_reviewed_display_frame=71760,
        source_frame_mapping=False,shared_soc_time=False,cpu_inference=False,
        intended_use='C model preprocessing/letterbox/input integrity; not an accuracy dataset',samples=[])
    font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',17)
    sheet=Image.new('RGB',(len(selected)*288,390),'#f5f5ef');draw=ImageDraw.Draw(sheet)
    for index,(label,base) in enumerate(selected):
        meta=json.loads(base.with_suffix('.json').read_text(encoding='utf-8'))
        data=base.with_suffix('.gray').read_bytes()
        assert len(data)==9216 and sum(data)==meta['checksum'] and not any(data[:2016]+data[7200:])
        files={}
        for suffix in ['.gray','.json','.pgm','.bmp']:
            src=base.with_suffix(suffix);dst=target/(label+suffix);shutil.copy2(src,dst)
            files[dst.name]=hashlib.sha256(dst.read_bytes()).hexdigest()
        manifest['samples'].append(dict(label=label,original=str(base.relative_to(ROOT)).replace('\\','/'),
            display_frame_id=meta['frame_id'],display_timestamp_ms=meta['timestamp_ms'],checksum=meta['checksum'],
            changed_count=meta['changed_count'],bbox_grid=meta['bbox_grid'],files=files))
        image=Image.frombytes('L',(96,96),data).convert('RGB').resize((288,288),Image.Resampling.NEAREST)
        d=ImageDraw.Draw(image)
        if meta['bbox_valid']:
            x0,y0,x1,y1=meta['bbox_grid'];d.rectangle((x0*3,(y0+21)*3,(x1+1)*3-1,(y1+22)*3-1),outline='#ffaa00',width=2)
        sheet.paste(image,(index*288,0))
        draw.text((index*288+10,294),label,font=font,fill='#18232a')
        draw.text((index*288+10,318),f"帧 {meta['frame_id']} / 变化 {meta['changed_count']}",font=font,fill='#18232a')
    draw.text((10,355),'实际串口快照；橙框为阈值帧差范围，非 AI 人体框。上下21行补黑。',font=font,fill='#18232a')
    sheet.save(target/'hardware_samples_preview.png')
    (target/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (target/'README.md').write_text('''# 实际相机 GRAY8 样本

五张样本来自本次 A FPGA 串口快照，原始 .gray 字节未缩放或画框，.json 保留显示流编号/本地时间/SUM32/同帧运动统计。PNG 预览上的橙框为另外绘制的阈值帧差框，不在原始模型输入里。object_pattern 的实际图像已检查，能够看到物体轮廓和表面图案，灰度0…147。

每张 9216 字节，96×96，unsigned GRAY8；前2016字节与末2016字节为0，中间5184字节为96×54。C 应逐字节复核后再按模型做INT8量化；模型预处理是否兼容、识别准确率尚未验证。

用户已确认手掌在镜头前移动并移开，样本可用于画面变化/运动接口检查。包围框是整幅变化区域，不等于手掌/人体检测结果。对照前一显示帧的统计不能直接拿两张串口快照相减重现，因为中间有未导出的显示帧。

source_frame_id=null，shared_soc_time=false，cpu_read=false 均保留。这些是显示侧真实样本，尚未绑定CSI源帧或统一时间，也不是软核推理日志。MANIFEST含原始路径、帧号和SHA256。
''',encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
