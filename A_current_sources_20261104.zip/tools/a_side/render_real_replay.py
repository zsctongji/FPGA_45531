"""Exercise A's actual RTL using separately captured real images/sensor values.

Output is explicitly OFFLINE REPLAY. It is not current fused sensor/video data.
"""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
from PIL import Image,ImageDraw,ImageFont
from capture_camera_input import ROOT

def main():
    gray=ROOT/'logs/a_side/headless/20261029_stability_30min/frame_0000071760.gray'
    thermal=ROOT/'logs/mlx90640/20261029_155654/frame_001.json'
    environment=ROOT/'logs/sensor_diag/20261026_215457/samples.csv'
    sources=[gray,gray.with_suffix('.json'),thermal,environment]
    work=ROOT/'build/a_side/real_replay';work.mkdir(parents=True,exist_ok=True)
    raw=gray.read_bytes();t=json.loads(thermal.read_text(encoding='utf-8'))
    e=next(csv.DictReader(environment.open(encoding='utf-8-sig')))
    assert len(raw)==9216 and len(t['pixels'])==768 and e['valid']=='True'
    active=raw[2016:7200];heat=bytes(max(0,min(255,round((v-20)*255/20))) for v in t['pixels'])
    (work/'camera.mem').write_text('\n'.join(f'{v:02x}' for v in active),encoding='ascii')
    (work/'thermal.mem').write_text('\n'.join(f'{v:02x}' for v in heat),encoding='ascii')
    tc=round(float(e['temperature_c'])*100);rh=round(float(e['humidity_rh'])*100)
    (work/'environment.mem').write_text(f'{tc&65535:04x}\n{rh:04x}\n',encoding='ascii')
    iv=ROOT/'tools/iverilog/bin/iverilog.exe';vvp=iv.with_name('vvp.exe')
    src=[ROOT/'sim/tb_a_real_replay.sv']+[ROOT/'rtl'/n for n in ['video_a_result_display.v','video_status_overlay.v','a_status_guard.v']]
    p=subprocess.run([str(iv),'-g2012','-I',str(ROOT/'rtl'),'-s','tb_a_real_replay','-o','replay.vvp']+[str(p) for p in src],cwd=work,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stderr)
    p=subprocess.run([str(vvp),'replay.vvp'],cwd=work,capture_output=True,text=True,timeout=30)
    if p.returncode or 'PASS tb_a_real_replay' not in p.stdout:raise RuntimeError(p.stdout+p.stderr)
    im=Image.open(work/'real_inputs_REPLAY.ppm').convert('RGB');out=Image.new('RGB',(960,660),'#f1f1eb')
    out.paste(im.resize((960,540),Image.Resampling.NEAREST),(0,0));draw=ImageDraw.Draw(out)
    font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
    lines=['离线 RTL 回放：分别采集的真实灰度图、MLX 热图与 SHT 环境样本',
           '热图固定映射 20–40℃；IR/环境绿灯，AI 无输入。显示布局测试。',
           '时间不一致，不代表同屏实物验收、实时融合或 AI 推理。']
    for i,line in enumerate(lines):draw.text((16,550+i*32),line,font=font,fill='#18232a')
    target=ROOT/'docs/A_real_inputs_OFFLINE_REPLAY.png';out.save(target)
    record=dict(status='PASS',scope='actual_RTL_offline_replay_of_separately_captured_real_inputs',
        simultaneous_capture=False,physical_hdmi_verified=False,ai_inference=False,
        heat_temperature_scale_c=[20,40],environment_temperature_c=tc/100,environment_humidity_percent=rh/100,
        image=str(target),sources={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources+src},
        log=p.stdout)
    (ROOT/'logs/a_real_inputs_replay.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
