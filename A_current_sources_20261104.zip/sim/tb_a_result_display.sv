`timescale 1ns/1ps
module tb_a_result_display;
    reg clk=0;always #5 clk=~clk;
    reg rst=0,vs=0,de=0;
    reg [31:0] now_ms=1000,v=1000,t=1000,e=1000,sid=7;
    reg [2:0] valid=7,fault=0;
    wire [23:0] rgb;wire hr,oh,ov,od;wire [9:0] ha;
    video_a_result_display #(.WIDTH(480),.HEIGHT(110)) dut(
        .clk(clk),.rst_n(rst),.in_hs(1'b0),.in_vs(vs),.in_de(de),.in_rgb(24'h102030),
        .now_ms(now_ms),.visual_timestamp_ms(v),.thermal_timestamp_ms(t),.environment_timestamp_ms(e),
        .valid_mask(valid),.fault_mask(fault),.alarm_active(1'b0),.prediction_valid(1'b0),
        .person_score(8'd192),.event_score(8'd128),.event_type(8'd1),
        .temperature_centi(16'd2534),.humidity_centi(16'd5678),.prediction_x(7'd0),.prediction_y(7'd0),
        .status_frame_id(sid),.display_frame_id(32'd7),.heat_pixel_valid(1'b1),.heat_level(8'd64),
        .heat_address(ha),.heat_request(hr),.out_hs(oh),.out_vs(ov),.out_de(od),.out_rgb(rgb));
    task frame(input integer mode);begin
        @(negedge clk);vs=1;@(negedge clk);vs=0;
        for(integer y=0;y<110;y++)begin
            for(integer x=0;x<480;x++)begin
                @(negedge clk);de=1;@(posedge clk);#1;
                if(od!==1||ov!==0||oh!==0)$fatal(1,"video control alignment");
                if(y==20&&x==22&&rgb!==(mode==0?24'h00cc80:mode==1?24'hffaa00:24'hff3000))$fatal(1,"IR health");
                if(y==20&&x==38&&rgb!==(mode==0?24'h00cc80:mode==1?24'h606060:24'hff3000))$fatal(1,"env health");
                if(y==20&&x==54&&rgb!==(mode==0?24'h00cc80:24'hffaa00))$fatal(1,"AI mismatch/age");
                if(y==40&&x==100&&rgb!==(mode==0?24'h00aaff:24'h303030))$fatal(1,"invalid AI score");
                if(y==84&&x==20&&mode!=0&&hr!==0)$fatal(1,"invalid heat requested");
            end
            @(negedge clk);de=0;repeat(2)@(negedge clk);
        end
    end endtask
    initial begin
        repeat(5)@(negedge clk);rst=1;frame(0);
        now_ms=3000;valid=3;frame(1);
        now_ms=1000;valid=7;fault=6;sid=8;frame(2);
        $display("PASS tb_a_result_display valid/stale/fault/missing, frame mismatch, score and thermal gating");$finish;
    end
    initial begin #5000000;$fatal(1,"timeout");end
endmodule
