"""Run the unchanged Efinix programmer with a compatible local Python runtime.

Supports inventory and verified MLX/A-camera diagnostic JTAG images. No Flash modes.
Dependencies live in build/jtag_runtime_py312; vendor files remain unchanged.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['list', 'scan', 'program-mlx', 'program-a-camera','program-a-headless','program-a-display'])
    args = parser.parse_args()
    vendor = ROOT / 'tools/efinity/2026.1'
    user_dir = ROOT / 'config/efinity_user'
    user_dir.mkdir(parents=True, exist_ok=True)
    os.environ.update(EFINITY_HOME=vendor.as_posix(),
                      EFXPGM_HOME=(vendor / 'pgm').as_posix(),
                      EFXDBG_HOME=(vendor / 'debugger').as_posix(),
                      EFINITY_USER_DIR_INI=(user_dir / 'user_dir.ini').as_posix())
    sys.path.insert(0, str(ROOT / 'build/jtag_runtime_py312'))
    sys.path.extend(str(vendor / path) for path in
                    ['pgm/bin', 'debugger/bin', 'python311/Lib/site-packages'])
    script = vendor / 'pgm/bin/efx_pgm/ftdi_program.py'
    options = ['--list_usb' if args.action == 'list' else '--scan_usb']
    if args.action in ('program-mlx','program-a-camera','program-a-headless','program-a-display'):
        name={'program-mlx':'mlx_bridge','program-a-camera':'a_camera_diag','program-a-headless':'a_headless','program-a-display':'a_display_test'}[args.action]
        release = json.loads((ROOT / ('logs/'+name+'_release.json')).read_text(encoding='utf-8-sig'))
        build = json.loads(Path(release['compile_record']).read_text(encoding='utf-8-sig'))
        image = ROOT / ('fpga_bitstreams/'+name+'/'+name+'.bit')
        if name.startswith('a_') and build.get('project')!=name:
            raise ValueError('Compile project does not match requested A diagnostic')
        if build['status'] != 'PASS' or hashlib.sha256(image.read_bytes()).hexdigest() != release['sha256']:
            raise ValueError('Verified diagnostic build/hash required')
        options = [str(image), '--mode', 'jtag', '--board_profile',
                   'Generic Board Profile Using FT4232H', '--jtag_clock_freq', '3000000']
    sys.argv = [str(script)] + options
    runpy.run_path(str(script), run_name='__main__')

if __name__ == '__main__':
    main()
