@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_a_side.ps1" -Mode Selftest
pause
