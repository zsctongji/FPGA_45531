"""Clone safe A12; add actual HDMI exercise with visible TEST labels."""
from pathlib import Path
import hashlib
import json
import re
import shutil
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'projects/12_a_headless';target=ROOT/'projects/13_a_display_test'
if target.exists():raise FileExistsError(target)
ignored={'outflow','work_syn','work_pnr','work_pt','work_sim','work_dbg','__pycache__'}
shutil.copytree(source,target,ignore=lambda d,n:[x for x in n if x in ignored])
names=['a_hdmi_display_exercise.v','video_a_result_display.v','video_status_overlay.v','a_status_guard.v','osd_font5x7.vh']
for name in names:shutil.copy2(ROOT/'rtl'/name,target/'rtl'/name)
top=target/'rtl/ti60f225_oob_top.v';s=top.read_text(encoding='utf-8')
anchor='dvi_encoder dvi_encoder_m0'
insert='''// Explicit A DISPLAY TEST: current camera, fixture B/C status. No inference.
wire [23:0] a_osd_rgb;
wire a_osd_hs,a_osd_vs,a_osd_de;
wire [2:0] a_osd_phase;
a_hdmi_display_exercise a_display_exercise(
    .clk(hdmi_tx_slow_clk),.rst_n(vid_rst_n),
    .in_hs(preprocess_hs),.in_vs(preprocess_vs),.in_de(preprocess_de),
    .in_rgb({preprocess_r,preprocess_g,preprocess_b}),
    .out_hs(a_osd_hs),.out_vs(a_osd_vs),.out_de(a_osd_de),.out_rgb(a_osd_rgb),.phase(a_osd_phase));

'''
assert s.count(anchor)==1;s=s.replace(anchor,insert+anchor)
start=s.index(anchor);before=s[:start];tail=s[start:]
for old,new in [('motion_r','a_osd_rgb[23:16]'),('motion_g','a_osd_rgb[15:8]'),('motion_b','a_osd_rgb[7:0]'),
                ('motion_hs','a_osd_hs'),('motion_vs','a_osd_vs'),('motion_de','a_osd_de')]:
    tail=tail.replace('('+old+')','('+new+')')
s=before+tail
top.write_text(s,encoding='utf-8')
xml=target/'ti60f225_oob.xml';s=xml.read_text(encoding='utf-8')
existing=set(re.findall(r'name="rtl/([^"/]+)"',s))
extra=''.join('        <efx:design_file name="rtl/'+n+'" version="default" library="default" />\n' for n in names if n not in existing and n.endswith('.v'))
pos=list(re.finditer(r'        <efx:design_file[^\n]+\n',s))[-1].end()
s=s[:pos]+extra+s[pos:];s=s.replace('value="0x41335631"','value="0x41354431"');xml.write_text(s,encoding='utf-8')
heat=ROOT/'logs/mlx90640/20261029_155654/frame_001.json'
pixels=json.loads(heat.read_text(encoding='utf-8'))['pixels'];assert len(pixels)==768
values=[max(0,min(255,round((v-20)*255/20))) for v in pixels]
(target/'a_display_thermal.mem').write_text('\n'.join(f'{v:02x}' for v in values)+'\n',encoding='ascii')
record=dict(scope='A HDMI display-interface exercise, not B/C live integration',usercode='0x41354431',
    underlying_video='actual camera preprocess stream',fixture_thermal=str(heat),thermal_sha256=hashlib.sha256(heat.read_bytes()).hexdigest(),
    fixture_temperature_c=25.47,fixture_humidity_percent=55.94,fixture_AI_scores=[192,128],
    always_visible_label='A DISPLAY TEST',phase_seconds=10,
    phases=['MISSING','VALID','STALE','FAULT','ALARM PRED','FRAME MISMATCH'],
    scl_sda_input_only=True,buzzer_low=True,board_tested=False)
(target/'A_DISPLAY_TEST.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(target)
