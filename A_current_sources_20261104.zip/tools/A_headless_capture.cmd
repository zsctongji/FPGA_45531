@echo off
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0start_a_side.ps1" -Mode HeadlessCapture %*
pause
