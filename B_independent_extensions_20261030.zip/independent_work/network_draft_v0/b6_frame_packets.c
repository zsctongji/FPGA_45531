#include "b6_frame_packets.h"
static void put16(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v;
}
static void put32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v;
}
uint32_t b6_crc32(const uint8_t *data, size_t bytes) {
    uint32_t crc = UINT32_C(0xffffffff);
    size_t i; unsigned b;
    for (i = 0; i < bytes; ++i) {
        crc ^= data[i];
        for (b = 0; b < 8; ++b)
            crc = (crc >> 1) ^ ((crc & 1u) ? UINT32_C(0xedb88320) : 0u);
    }
    return crc ^ UINT32_C(0xffffffff);
}
int b6_packetize_frame(const b6_frame_info_t *info, const uint8_t *image,
                      size_t image_bytes, uint8_t *buffer, size_t buffer_bytes,
                      b6_send_packet_fn send_packet, void *context,
                      uint16_t *sent_packets) {
    uint32_t image_crc; uint16_t index;
    if (sent_packets) *sent_packets = 0;
    if (!info || !image || image_bytes != B6_IMAGE_BYTES || !buffer ||
        buffer_bytes < B6_PACKET_BYTES || !send_packet || !sent_packets)
        return B6_EINVAL;
    image_crc = b6_crc32(image, image_bytes);
    for (index = 0; index < B6_PACKET_COUNT; ++index) {
        size_t offset = (size_t)index * B6_PAYLOAD_BYTES;
        size_t count = image_bytes - offset; size_t i;
        if (count > B6_PAYLOAD_BYTES) count = B6_PAYLOAD_BYTES;
        buffer[0] = 'B'; buffer[1] = '6'; buffer[2] = 'D'; buffer[3] = '0';
        buffer[4] = 0; buffer[5] = 1;
        put16(buffer + 6, B6_HEADER_BYTES);
        put32(buffer + 8, info->event_id);
        put32(buffer + 12, info->frame_id);
        put32(buffer + 16, info->capture_ms);
        put32(buffer + 20, B6_IMAGE_BYTES);
        put32(buffer + 24, image_crc);
        put32(buffer + 28, (uint32_t)offset);
        put32(buffer + 32, b6_crc32(image + offset, count));
        put16(buffer + 36, 96); put16(buffer + 38, 96);
        put16(buffer + 40, 96); put16(buffer + 42, index);
        put16(buffer + 44, B6_PACKET_COUNT); put16(buffer + 46, (uint16_t)count);
        for (i = 0; i < count; ++i) buffer[B6_HEADER_BYTES + i] = image[offset + i];
        if (send_packet(context, buffer, B6_HEADER_BYTES + count) != 0) return B6_ESEND;
        ++*sent_packets;
    }
    return B6_OK;
}
