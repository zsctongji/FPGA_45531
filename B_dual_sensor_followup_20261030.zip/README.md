# B 双传感器实测和恢复工具

2026-10-30：这是独立 FPGA 诊断的源码与证据交接，不是课程/竞赛报告章节。

最终连续会话 `logs/dual_soak_20261030_202918_079751` 实际运行 300.091 秒，保存 574 组及时配对热图和 212 条有效温湿度。热图观察配对年龄 242～409 ms；所有 574 组已用随包 Melexis 算法重算一致，保留 767 个有效像素和 index620 无效坏点。

**长稳没有无故障通过。** 共保留 10 次 20ms 串口事务超时，自动重开确切 UART 通道后恢复；7 次读取期间产生新子页被拒绝；结束边界另有 1 次子页期限拒绝。前两轮失败会话也完整保留。不能从这些记录断言超时一定发生在传感器、Windows 调度或某段电路。

两种传感器的诊断时间来自同一个 BQFAST01 FPGA 毫秒计数器；温湿度沿用原 b_sht30.c，通过主机回调访问真实 FPGA I2C。它不是最终 C3 SoC 驱动，不含真实视频/事件/网口。温度在串口关闭后离线换算，500ms 判断不包含换算和整机发布耗时，也不是曝光年龄。

仅查询地址0x44的一字节只读探针获得真实 NACK；重开同一 UART 后 MLX 控制寄存器和 SHT 状态/CRC 均再次通过。它验证错误应答与重开恢复，不等于物理拔线、短路或掉电恢复。开始时曾观察到总线两输入均低，重新加载同一 SRAM 程序后恢复；电气根因未确认，失败探针和重载记录保留。

退出时 MLX 控制寄存器恢复到十进制6401/0x1901；最终状态 SCL/SDA 读回高、蜂鸣器逻辑低。没有写 Flash，没有发送蜂鸣器 ON，模块保持断开；冷启动及实际发声未验收。

## 离线复核

Windows 64位 Python 3.10+，包内 DLL 已提供。运行以下命令不会访问板卡：

```text
python -B independent_work/hardware_followup/verify_delivery.py
```

该入口检查包内全部文件哈希，运行3项适配边界测试，并复核3轮会话：原始UART收发校验、板端时间顺序、SHT两处CRC/换算、原始热图及官方算法重算。预期是证据核查通过，保留采集结果中的 NOT_PASSED/RECOVERED_ERRORS，不会改成稳定性PASS。

需要重编译适配 DLL 时，关闭采集程序后运行：

```text
python -B independent_work/hardware_followup/build_adapter.py --cc GCC绝对路径
```

适配器只编译冻结的原 SHT30 C 源码和 HAL；源文件及构建散列随包。重新构建会改变 DLL 文件散列，应先完成原包核验再在副本中构建。

## 明确启用真实硬件

`dual_soak.py` 和 `restore_and_nack.py` 默认只输出离线计划。硬件方式需要原有 Efinity Python、FTDI/D2XX 驱动、明确的串口映射、BQFAST01 SRAM 程序及已核对的接线。COM8/C仅为本机本次映射，不能套到其他电脑。

```text
python -B independent_work/hardware_followup/dual_soak.py --run-hardware --seconds 300 --port COM实际号 --ftdi-serial 实际UART接口序列号
```

保持原20ms事务预算；使用高分辨率主机计时。发生迟到/模糊回复后丢弃当前热图片段，重开并清空指定通道，再核对身份、板端计数器连续、总线释放及控制寄存器；最多10次恢复。失败不补零、不重复计入。恢复记录随数据保存；有通信错误的会话不会返回无故障PASS。

`restore_and_nack.py` 只允许按先前会话的 original_control 证据恢复刷新率位，其他位不同则停止；随后进行有限NACK探针。源码/bitstream的SRAM加载入口仍是 `standalone_sensor_fast/host/load_fast_sram.py`；加载会替换当前临时FPGA逻辑，不能用于覆盖正在运行的队友联合测试。

后续只待最终 C 的匹配 FPGA/CPU 固件、真实 I2C/GPIO/共同时间和网络接口到位后集成；现场再验证实际断线、启动静音、摄像头同屏和网口闭环。已有A样图和补边材料不要求重复提供。
