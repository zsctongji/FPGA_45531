/* Host-only fault injection against unmodified b_sht30.c and c3_hal.c. */
#include "b_sensors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned checks, cases;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); exit(1); } } while (0)
typedef struct { int rc; unsigned delay; unsigned corrupt; } outcome;
typedef struct {
    uint32_t now;
    int command_rc;
    unsigned commands, reads, cursor, count;
    uint32_t last_read_ms;
    uint16_t raw_t, raw_h;
    outcome steps[8];
} mock;
static uint8_t reference_crc(const uint8_t *p) {
    unsigned c=255, i, j;
    for (i=0;i<2;i++) { c^=p[i]; for(j=0;j<8;j++) c=(c&128)?((c<<1)^0x31)&255:(c<<1)&255; }
    return (uint8_t)c;
}
static uint32_t clock_ms(void *p) { return ((mock *)p)->now; }
static int transaction(void *p,uint32_t bus,uint8_t addr,const uint8_t *tx,uint32_t nt,
                       uint8_t *rx,uint32_t nr,uint32_t timeout) {
    mock *m=(mock *)p; outcome o={COOP_OK,0,0};
    CHECK(bus==0); CHECK(addr==0x44 || addr==0x45); CHECK(timeout==20);
    if (nt==2 && nr==0) {
        CHECK(tx && tx[0]==0x24 && tx[1]==0); CHECK(rx==NULL);
        m->commands++; return m->command_rc;
    }
    CHECK(nt==0 && nr==6 && tx==NULL && rx!=NULL);
    m->reads++; m->last_read_ms=m->now;
    if(m->cursor<m->count) o=m->steps[m->cursor++];
    if(o.delay>=timeout) { m->now+=timeout; return COOP_ETIMEOUT; }
    m->now+=o.delay;
    if(o.rc!=COOP_OK) return o.rc;
    rx[0]=(uint8_t)(m->raw_t>>8); rx[1]=(uint8_t)m->raw_t; rx[2]=reference_crc(rx);
    rx[3]=(uint8_t)(m->raw_h>>8); rx[4]=(uint8_t)m->raw_h; rx[5]=reference_crc(rx+3);
    if(o.corrupt==1) rx[2]^=1;
    if(o.corrupt==2) rx[5]^=1;
    return COOP_OK;
}
static c3_hal_t setup(mock *m) {
    c3_hal_t h; memset(m,0,sizeof(*m)); m->raw_t=0x6666; m->raw_h=0x8000;
    memset(&h,0,sizeof(h)); h.context=m; h.now_ms=clock_ms; h.i2c_write_read=transaction;
    return h;
}
static void init(b_sht30_t *d,c3_hal_t *h) { CHECK(b_sht30_init(d,h,0x45)==COOP_OK); }
static int advance_poll(mock *m,b_sht30_t *d,unsigned delta) { m->now+=delta; return b_sht30_poll(d); }
static void success_wait_and_stale(void) {
    mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; init(&d,&h); cases++;
    CHECK(b_sht30_start(&d)==0); CHECK(b_sht30_start(&d)==COOP_EBUSY);
    CHECK(advance_poll(&m,&d,15)==COOP_EBUSY); CHECK(m.reads==0);
    CHECK(advance_poll(&m,&d,1)==0); CHECK(m.reads==1 && m.commands==1);
    CHECK(b_sht30_get(&d,&out)==0); CHECK(out.abi_version==COOP_ABI_VERSION);
    CHECK(out.valid_flags==7 && out.error_bits==0 && out.sample_id==1);
    CHECK(out.timestamp_ms==16 && out.temperature_centi_c==2500 && out.humidity_centi_percent==5000);
    m.now+=2000; CHECK(b_sht30_get(&d,&out)==0);
    m.now++; CHECK(b_sht30_get(&d,&out)==COOP_ETIMEOUT); CHECK(!out.valid_flags && (out.error_bits&1));
}
static void endpoints(void) {
    unsigned i; for(i=0;i<2;i++) {
        mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; init(&d,&h); cases++;
        m.raw_t=m.raw_h=i?65535:0; CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,16)==0);
        CHECK(b_sht30_get(&d,&out)==0); CHECK(out.temperature_centi_c==(i?13000:-4500));
        CHECK(out.humidity_centi_percent==(i?10000u:0u));
    }
}
static void read_fault_recovers(int rc,unsigned corrupt) {
    mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; init(&d,&h); cases++;
    m.steps[0]=(outcome){rc,0,corrupt}; m.count=1;
    CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,16)==COOP_EBUSY);
    CHECK(d.sample.valid_flags==0); CHECK(d.sample.error_bits==(corrupt?COOP_ERROR_CRC:rc==COOP_ENACK?COOP_ERROR_NACK:rc==COOP_ETIMEOUT?COOP_ERROR_TIMEOUT:COOP_ERROR_BUS));
    CHECK(advance_poll(&m,&d,4)==COOP_EBUSY); CHECK(m.commands==1);
    CHECK(advance_poll(&m,&d,1)==COOP_EBUSY); CHECK(m.commands==2);
    CHECK(advance_poll(&m,&d,15)==COOP_EBUSY); CHECK(m.reads==1);
    CHECK(advance_poll(&m,&d,1)==0); CHECK(m.reads==2 && d.attempts==2);
    CHECK(b_sht30_get(&d,&out)==0 && out.error_bits==0 && out.valid_flags==7);
}
static void command_failure_invalidates_previous(void) {
    mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; init(&d,&h); cases++;
    CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,16)==0);
    m.command_rc=COOP_ENACK; CHECK(b_sht30_start(&d)==COOP_ENACK);
    CHECK(d.attempts==1 && d.state==0 && m.reads==1);
    CHECK(b_sht30_get(&d,&out)==COOP_ESTATE); CHECK(out.sample_id==2 && !out.valid_flags);
    CHECK(out.error_bits==COOP_ERROR_NACK);
    m.command_rc=0; CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,16)==0);
    CHECK(b_sht30_get(&d,&out)==0 && out.sample_id==3);
}
static void max_retries(void) {
    mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; unsigned i; init(&d,&h); cases++;
    for(i=0;i<3;i++) { m.steps[i]=(outcome){COOP_ENACK,0,0}; }
    m.count=3;
    CHECK(b_sht30_start(&d)==0);
    for(i=0;i<3;i++) {
        CHECK(advance_poll(&m,&d,16)==(i==2?COOP_ENACK:COOP_EBUSY));
        if(i<2) CHECK(advance_poll(&m,&d,5)==COOP_EBUSY);
    }
    CHECK(m.commands==3 && m.reads==3 && d.state==0);
    CHECK(b_sht30_get(&d,&out)==COOP_ESTATE && out.error_bits==COOP_ERROR_NACK);
}
static void deadlines_and_backend_timeout(void) {
    mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; init(&d,&h); cases++;
    CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,100)==COOP_ETIMEOUT);
    CHECK(m.reads==0 && d.state==0); CHECK(b_sht30_get(&d,&out)==COOP_ESTATE && out.error_bits==1);
    h=setup(&m); init(&d,&h); cases++; m.steps[0]=(outcome){0,120,0}; m.count=1;
    CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,16)==COOP_EBUSY);
    CHECK(m.now==36 && d.sample.error_bits==COOP_ERROR_TIMEOUT);
    CHECK(advance_poll(&m,&d,5)==COOP_EBUSY); CHECK(advance_poll(&m,&d,16)==0);
    h=setup(&m); init(&d,&h); cases++; m.steps[0]=(outcome){0,10,0}; m.count=1;
    CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,95)==COOP_ETIMEOUT);
    CHECK(m.now==105 && d.state==0 && !d.sample.valid_flags);
}
static void wrapping_clock(void) {
    mock m; c3_hal_t h=setup(&m); b_sht30_t d; coop_environment_t out; init(&d,&h); cases++;
    m.now=0xfffffff8u; CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,15)==COOP_EBUSY);
    CHECK(advance_poll(&m,&d,1)==0); CHECK(b_sht30_get(&d,&out)==0 && out.timestamp_ms==8);
    m.now+=2001; CHECK(b_sht30_get(&d,&out)==COOP_ETIMEOUT);
    h=setup(&m); init(&d,&h); cases++; m.now=0xfffffff8u;
    CHECK(b_sht30_start(&d)==0); CHECK(advance_poll(&m,&d,100)==COOP_ETIMEOUT);
}
static void hal_validation(void) {
    mock m; c3_hal_t h=setup(&m), empty={0}; b_sht30_t d; uint8_t b=0; cases++;
    CHECK(b_sht30_init(&d,&h,0x90)==COOP_EINVAL); CHECK(b_sht30_init(&d,&empty,0x45)==COOP_ENOTSUP);
    CHECK(c3_i2c_write_read(&h,0,0x90,&b,1,NULL,0,20)==COOP_EINVAL);
    CHECK(c3_i2c_write_read(&h,0,0x45,&b,1,NULL,0,0)==COOP_EINVAL);
    CHECK(c3_i2c_write_read(&h,0,0x45,&b,1,NULL,0,0x80000000u)==COOP_EINVAL);
    CHECK(c3_i2c_write_read(&h,0,0x45,NULL,1,NULL,0,20)==COOP_EINVAL);
    CHECK(c3_i2c_write_read(&empty,0,0x45,&b,1,NULL,0,20)==COOP_ENOTSUP);
    CHECK(m.commands==0 && m.reads==0);
}
int main(void) {
    success_wait_and_stale(); endpoints();
    read_fault_recovers(COOP_ENACK,0); read_fault_recovers(COOP_EIO,0);
    read_fault_recovers(COOP_ETIMEOUT,0); read_fault_recovers(0,1); read_fault_recovers(0,2);
    command_failure_invalidates_previous(); max_retries(); deadlines_and_backend_timeout();
    wrapping_clock(); hal_validation();
    printf("{\"scope\":\"HOST_C_DRIVER_MOCK_HAL\",\"hardware_accessed\":false,\"cases\":%u,\"assertions\":%u,\"status\":\"PASS\"}\n",cases,checks);
    return 0;
}
