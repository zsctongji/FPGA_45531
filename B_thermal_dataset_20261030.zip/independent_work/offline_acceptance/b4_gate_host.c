/* Host bridge for the unmodified B4 C gates. No board/device I/O. */
#include "b4_publish_gate.h"
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

EXPORT void *host_gate_create(void) {
    b4_publish_state_t *state = malloc(sizeof(*state));
    if (state) b4_publish_reset(state);
    return state;
}
EXPORT void host_gate_destroy(void *state) { free(state); }
EXPORT uint32_t host_min_valid_pixels(void) {
    b4_publish_config_t config;
    b4_publish_config_default(&config);
    return config.quality.thermal_min_valid_pixels;
}
EXPORT int host_environment(void *state, uint32_t abi, uint32_t id,
    uint32_t ts, uint32_t flags, uint32_t errors, int32_t temp,
    uint32_t humidity, uint32_t now, uint32_t *reasons, uint32_t *preserved) {
    b4_publish_config_t config;
    coop_environment_t input, output, sentinel;
    int rc;
    b4_publish_config_default(&config);
    memset(&input, 0, sizeof(input));
    input.abi_version=abi; input.sample_id=id; input.timestamp_ms=ts;
    input.valid_flags=flags; input.error_bits=errors;
    input.temperature_centi_c=temp; input.humidity_centi_percent=humidity;
    memset(&output, 0xa5, sizeof(output)); sentinel=output;
    rc=b4_publish_environment(state,&input,now,&config,&output,reasons);
    *preserved=memcmp(&output, rc==COOP_OK ? &input : &sentinel, sizeof(output))==0;
    return rc;
}
EXPORT int host_thermal(uint32_t abi, uint32_t id, uint32_t ts,
    uint32_t flags, uint32_t errors, const int16_t *temperatures,
    const uint8_t *mask, uint32_t now, uint32_t *reasons,
    uint16_t *count, uint32_t *preserved) {
    b4_publish_config_t config;
    coop_thermal_t input, output, sentinel;
    int rc;
    b4_publish_config_default(&config);
    memset(&input,0,sizeof(input));
    input.abi_version=abi; input.sample_id=id; input.timestamp_ms=ts;
    input.valid_flags=flags; input.error_bits=errors;
    memcpy(input.temperature_centi_c,temperatures,sizeof(input.temperature_centi_c));
    memcpy(input.pixel_valid_bits,mask,sizeof(input.pixel_valid_bits));
    memset(&output,0xa5,sizeof(output)); sentinel=output;
    rc=b4_publish_thermal(&input,now,&config,&output,count,reasons);
    *preserved=memcmp(&output, rc==COOP_OK ? &input : &sentinel,sizeof(output))==0;
    return rc;
}
