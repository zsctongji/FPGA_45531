"""Package and verify a self-contained offline thermal dataset delivery."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parents[1]
NAME = "B_thermal_dataset_20261030"
ORIGINAL_SHA = "336dc31bbd202c2ba96e9014c167f69a4c4658a1030b43dae36f429d54b8fbd2"


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    archive = BASE/"artifacts"/(NAME+".zip")
    if archive.exists(): raise RuntimeError("preserve existing delivery; use a new version")
    original = BASE/"artifacts/B_fast_thermal_real100_20261030_v2.zip"
    if sha(original) != ORIGINAL_SHA: raise RuntimeError("original evidence archive changed")
    stamp = datetime.now().strftime("%H%M%S_%f")
    stage = BASE/"artifacts"/(NAME+"_stage_"+stamp)
    clean = BASE/"artifacts"/(NAME+"_clean_"+stamp)
    stage.mkdir()
    with zipfile.ZipFile(original) as z:
        for item in z.infolist():
            if not (stage/item.filename).resolve().is_relative_to(stage.resolve()):
                raise RuntimeError("archive path escapes delivery")
        z.extractall(stage)
    module = BASE/"independent_work/thermal_dataset"
    files = [p for p in module.rglob("*") if p.is_file() and
             not {"build", "__pycache__", "test_build"}.intersection(p.relative_to(module).parts)]
    offline = BASE/"independent_work/offline_acceptance"
    files += [offline/name for name in ("gate_host.py", "b4_gate_host.c", "thermal_features.py")]
    files += [p for p in (offline/"vendor").iterdir() if p.suffix in (".h", ".c")]
    files += [BASE/"records/B_热图数据集与剩余联调_20261030.md",
              BASE/"records/A_队友更新核查_20261030_最新.md", Path(__file__).resolve()]
    for path in files:
        target = stage/path.relative_to(BASE)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    manifest = {"scope": "OFFLINE_REAL100_DATASET_C_ABI_AND_PRESERVED_REAL_EVIDENCE",
                "new_board_measurements": 0, "hardware_accessed": False,
                "original_archive_sha256": ORIGINAL_SHA,
                "files_sha256": {p.relative_to(stage).as_posix(): sha(p)
                                 for p in sorted(stage.rglob("*")) if p.is_file()}}
    (stage/"thermal_dataset_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(stage.rglob("*")):
            if path.is_file(): z.write(path, path.relative_to(stage))
    with zipfile.ZipFile(archive) as z: z.extractall(clean)
    result = subprocess.run([sys.executable, "-B", str(clean/"independent_work/thermal_dataset/verify_dataset.py")],
                            capture_output=True, text=True, encoding="utf-8", timeout=120)
    log = BASE/"records"/(NAME+"_clean_verify.log")
    log.write_text(result.stdout+result.stderr, encoding="utf-8")
    if result.returncode: raise RuntimeError("clean verification failed: " + result.stderr)
    verification = json.loads(result.stdout)
    if verification["status"] != "PASS": raise RuntimeError("clean verification did not pass")
    if any(sha(clean/name) != digest for name, digest in manifest["files_sha256"].items()):
        raise RuntimeError("verification modified frozen bundle files")
    report = {"status": "CLEAN_BUNDLE_DATASET_AND_ORIGINAL_C_ABI_PASS",
              "at": datetime.now().astimezone().isoformat(),
              "archive": archive.name, "archive_bytes": archive.stat().st_size,
              "archive_sha256": sha(archive), "verification": verification,
              "preserves_original_evidence_archive_sha256": ORIGINAL_SHA,
              "new_board_measurements": 0, "hardware_accessed": False}
    (BASE/"records"/(NAME+"_clean_verify.json")).write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    (BASE/"artifacts"/(NAME+".sha256.txt")).write_text(sha(archive)+"  "+archive.name+"\n", encoding="ascii")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
