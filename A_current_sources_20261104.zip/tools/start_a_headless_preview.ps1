param([string]$Folder,[string]$Python)
$ErrorActionPreference='Stop'
$aRoot=Split-Path -Parent $PSScriptRoot
if(!$Folder){
    $aFolders=@(Get-ChildItem -LiteralPath (Join-Path $aRoot 'logs\a_side\headless') -Directory -ErrorAction SilentlyContinue)
    $aFolders+=@(Get-ChildItem -LiteralPath (Join-Path $aRoot 'logs\a_side') -Directory -Filter 'headlesscapture_*' -ErrorAction SilentlyContinue)
    $aCandidate=$aFolders|Where-Object {Get-ChildItem -LiteralPath $_.FullName -File -Filter 'frame_*.bmp'|Select-Object -First 1}|Sort-Object LastWriteTime -Descending|Select-Object -First 1
    if(!$aCandidate){throw 'No completed A image capture found. Run A_headless_capture.cmd first.'}
    $Folder=$aCandidate.FullName
}
if(!$Python){$Python=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'}
if(!(Test-Path -LiteralPath $Python)){throw 'Provide -Python with an available Python 3.11+'}
Write-Host "Read-only folder: $Folder"
Write-Host 'Open http://127.0.0.1:39005 ; Ctrl+C closes the preview.'
$aPreviousHome=$env:PYTHONHOME
try {
    $env:PYTHONHOME=$null
    & $Python -X utf8 (Join-Path $PSScriptRoot 'a_side\headless_preview.py') $Folder
    $aExit=$LASTEXITCODE
} finally {$env:PYTHONHOME=$aPreviousHome}
exit $aExit
