import copy
import math
from pathlib import Path
import unittest

from thermal_features import analyze
from gate_host import Gate, build_library
from run_offline_acceptance import assess_release


def fixture():
    return {"width":32,"height":24,"temperature_c":[20.0]*768,
            "pixel_reason":["VALID"]*768,"pixel_valid_bits_hex":("ff"*96)}


def invalidate(grid, i):
    grid["temperature_c"][i]=None
    grid["pixel_reason"][i]="EEPROM_BAD_PIXEL"
    bits=bytearray.fromhex(grid["pixel_valid_bits_hex"])
    bits[i//8]&=~(1<<(i%8))
    grid["pixel_valid_bits_hex"]=bits.hex()


class ThermalFeatures(unittest.TestCase):
    def test_bad_pixel_is_excluded_without_mutating_source(self):
        g=fixture();invalidate(g,620);snapshot=copy.deepcopy(g)
        f=analyze(g)
        self.assertEqual(f["valid_pixels"],767)
        self.assertEqual(f["invalid_indices_zero_based"],[620])
        self.assertEqual(f["statistics_valid_only"]["mean_c"],20)
        self.assertEqual(g,snapshot)
    def test_no_candidate_is_valid_result(self):
        f=analyze(fixture());self.assertEqual(f["candidates"],[])
        self.assertEqual(f["hot_pixels"],0)
    def test_component_geometry(self):
        g=fixture()
        for i in (33,34,65,66):g["temperature_c"][i]=30.0
        f=analyze(g);c=f["candidates"][0]
        self.assertEqual(c["area_pixels"],4)
        self.assertEqual(c["centroid_xy_pixels"],[1.5,1.5])
        self.assertEqual(c["bbox_xyxy_inclusive"],[1,1,2,2])
    def test_diagonal_and_row_edge_are_not_connected(self):
        g=fixture()
        for i in (31,32,34,67):g["temperature_c"][i]=30.0
        f=analyze(g,min_area=1)
        self.assertEqual(len(f["candidates"]),4)
    def test_masked_hole_is_not_a_bridge(self):
        g=fixture()
        for i in (33,34,35):g["temperature_c"][i]=30.0
        invalidate(g,34)
        self.assertEqual(len(analyze(g,min_area=1)["candidates"]),2)
    def test_absolute_threshold_and_small_component_filter(self):
        g=fixture();g["temperature_c"][0]=25
        self.assertEqual(analyze(g)["discarded_small_components"],1)
        self.assertEqual(analyze(g,absolute_min_c=26,min_area=1)["hot_pixels"],0)
    def test_nan_and_mask_mismatch_fail(self):
        g=fixture();g["temperature_c"][0]=math.nan
        with self.assertRaises(ValueError):analyze(g)
        g=fixture();g["pixel_reason"][0]="MISSING"
        with self.assertRaises(ValueError):analyze(g)
        g=fixture();g["pixel_valid_bits_hex"]="00"*96
        with self.assertRaises(ValueError):analyze(g)
    def test_bad_shape_mask_and_parameters_fail(self):
        for key,value in (("width",24),("temperature_c",[]),("pixel_reason",[]),("pixel_valid_bits_hex","ff")):
            g=fixture();g[key]=value
            with self.assertRaises(ValueError):analyze(g)
        for kwargs in ({"delta_c":-1},{"delta_c":math.inf},{"delta_c":True},{"absolute_min_c":math.nan},{"min_area":0},{"min_area":769},{"min_area":True}):
            with self.assertRaises(ValueError):analyze(fixture(),**kwargs)
    def test_all_invalid_has_no_fake_temperature(self):
        g=fixture()
        for i in range(768):invalidate(g,i)
        f=analyze(g)
        self.assertEqual(f["valid_pixels"],0)
        self.assertIsNone(f["statistics_valid_only"]["mean_c"])
        self.assertIsNone(f["candidate_policy"]["threshold_c"])
        self.assertEqual(f["candidates"],[])


class OriginalCGate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import os
        cls.library,cls.build=build_library(Path(__file__).resolve().parent/"test_build",os.environ.get("B_OFFLINE_CC"))
    def setUp(self):self.gate=Gate(self.library)
    def tearDown(self):self.gate.close()
    def environment(self,**change):
        args=dict(sample_id=1,timestamp_ms=100,flags=7,errors=0,temp_centi=2300,humidity_centi=6000,now_ms=100)
        args.update(change);return self.gate.environment(**args)
    def thermal(self,**change):
        args=dict(sample_id=1,timestamp_ms=100,flags=3,errors=64,temperatures=[2500]*768,mask=b"\xff"*96,now_ms=100)
        args.update(change);return self.gate.thermal(**args)
    def test_environment_age_boundary_and_rejected_history(self):
        self.assertEqual(self.environment(now_ms=2100)["rc"],0)
        rejected=self.environment(sample_id=2,timestamp_ms=200,now_ms=2201)
        self.assertEqual(rejected["rc"],-5)
        self.assertTrue(rejected["copy_or_rejection_preserved"])
        self.assertEqual(self.environment(sample_id=3,timestamp_ms=200,now_ms=200)["rc"],0)
    def test_future_wrap_and_duplicate(self):
        self.assertEqual(self.environment(timestamp_ms=100,now_ms=99)["rc"],-5)
        self.assertEqual(self.environment(timestamp_ms=0xfffffff0,now_ms=0x10)["rc"],0)
        self.assertEqual(self.environment(sample_id=2,timestamp_ms=0x10,now_ms=0x10)["rc"],0)
        self.assertNotEqual(self.environment(sample_id=2,timestamp_ms=0x10,now_ms=0x10)["rc"],0)
    def test_thermal_500_501_and_wrap(self):
        self.assertEqual(self.thermal(now_ms=600)["rc"],0)
        r=self.thermal(now_ms=601);self.assertEqual(r["rc"],-5)
        self.assertTrue(r["copy_or_rejection_preserved"])
        self.assertEqual(self.thermal(timestamp_ms=0xfffffff0,now_ms=0x10)["rc"],0)
        self.assertEqual(self.thermal(now_ms=99)["rc"],-5)
    def test_thermal_bad_pixel_preserved_and_default_is_700(self):
        bits=bytearray(b"\xff"*96);bits[620//8]&=~(1<<(620%8))
        r=self.thermal(mask=bytes(bits));self.assertEqual(r["rc"],0)
        self.assertEqual(r["valid_pixels"],767);self.assertEqual(r["reason_bits"],0)
        self.assertTrue(r["copy_or_rejection_preserved"])
        self.assertEqual(int(self.gate.lib.host_min_valid_pixels()),700)
    def test_700_699_and_bus_error(self):
        def mask(count):return bytes(sum(1<<b for b in range(8) if i*8+b<count) for i in range(96))
        self.assertEqual(self.thermal(mask=mask(700))["rc"],0)
        self.assertNotEqual(self.thermal(mask=mask(699))["rc"],0)
        self.assertNotEqual(self.thermal(errors=32)["rc"],0)
    def test_range_and_abi_input_validation(self):
        self.assertNotEqual(self.environment(humidity_centi=10001)["rc"],0)
        with self.assertRaises(ValueError):self.environment(abi=2)
        with self.assertRaises(ValueError):self.environment(timestamp_ms=-1)
        with self.assertRaises(ValueError):self.thermal(temperatures=[40000]*768)


class ReleaseEvidence(unittest.TestCase):
    def test_missing_evidence_never_defaults_to_pass(self):
        r=assess_release({});self.assertFalse(r["release_allowed"])
        self.assertEqual(len(r["blockers"]),7)
    def test_timing_or_synthetic_image_blocks_release(self):
        keys=assess_release({})["checks"]
        full=dict.fromkeys(keys,True)
        self.assertTrue(assess_release(full)["release_allowed"])
        for field in ("thermal_pair_500ms","shared_clock_validated","real_image_same_session","final_soc_i2c_deadlines_validated"):
            changed=dict(full);changed[field]=False
            self.assertEqual(assess_release(changed)["blockers"],[field])

if __name__=="__main__":unittest.main()
