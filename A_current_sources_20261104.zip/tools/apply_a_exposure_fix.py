"""Apply a bounded SC431HAI exposure/frame-length correction after real ID readback."""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[1]

def apply(report_path):
    baseline=json.loads(Path(report_path).read_text(encoding='utf-8'))
    registers={int(k,16):int(v,16) for k,v in baseline['camera_registers'].items()}
    assert baseline['camera_chip_id']=='0xCD6B'
    assert baseline['camera_timing_raw']==dict(width=1920,height=1080,hts=1400,vts=1500)
    assert [registers[a] for a in [0x3e00,0x3e01,0x3e02]]==[1,0xbb,0xf0]
    camera=ROOT/'projects/11_a_camera_diag/rtl/cam_i2c_ctrl/i2c'
    rom=camera/'i2c_master_reg_rom.v';text=rom.read_text(encoding='utf-8')
    pattern=r"^ROM\[8'h([0-9a-fA-F]+)\]\s*=\s*\{16'h([0-9a-fA-F]+),\s*8'h([0-9a-fA-F]+),\s*1'b([01])\};[^\n]*"
    matches=list(re.finditer(pattern,text,re.M))
    entries=[tuple(int(x,16) for x in m.groups()) for m in matches]
    assert len(entries)==180 and [x[0] for x in entries]==list(range(180))
    values=[]
    before_stream_inserted=False
    for _,addr,value,read in entries:
        if not read and addr==0x0100 and value==1:
            values.extend([(0x320e,0x05,0),(0x320f,0xd2,0)]) # VTS 1490
            before_stream_inserted=True
        if not read and addr in (0x3e00,0x3e01,0x3e02):
            value={0x3e00:0,0x3e01:0x7d,0x3e02:0}[addr] # 1000 lines -> 2000 half-lines
        values.append((addr,value,read))
    assert before_stream_inserted and len(values)==182
    original_hash=hashlib.sha256(rom.read_bytes()).hexdigest()
    block='\n'.join(f"ROM[8'h{i:02x}] = {{16'h{addr:04x},8'h{value:02x},1'b{read}}};" for i,(addr,value,read) in enumerate(values))
    rom.write_text(text[:matches[0].start()]+block+text[matches[-1].end():],encoding='utf-8')
    ctrl=camera/'i2c_master_ctrl_top.v';s=ctrl.read_text(encoding='utf-8')
    assert s.count('parameter DATA_LENGTH = 180')==1
    ctrl.write_text(s.replace('parameter DATA_LENGTH = 180','parameter DATA_LENGTH = 182'),encoding='utf-8')
    record=dict(baseline_report=str(Path(report_path).resolve()),chip_id='0xCD6B',
        exposure_before_lines=3551.5,exposure_after_lines=1000,vts_before=1500,vts_after=1490,
        timing_reference='https://raw.githubusercontent.com/rockchip-linux/kernel/develop-5.10/drivers/media/i2c/sc431hai.c',
        rationale='Exposure is encoded in half-lines; keep below VTS-8. Verify frame rate on hardware.',
        modified_registers={'0x3E00':'0x00','0x3E01':'0x7D','0x3E02':'0x00','0x320E':'0x05','0x320F':'0xD2'},
        other_camera_writes_unchanged=True,original_rom_sha256=original_hash,
        fixed_rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),hardware_result_pending=True)
    (ROOT/'logs/a_camera_exposure_fix_20261029.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('baseline_report')
    apply(p.parse_args().baseline_report)
