"""Bounded BQFAST01 serial transport, with injectable I/O for offline checks."""
import json
import struct
import time


class BoardError(RuntimeError):
    pass


class FastBridge:
    IDENTITY = b"BQFAST01"

    def __init__(self, transport, log, *, clock=time.monotonic):
        self.transport, self.log, self.clock = transport, log, clock
        self.seq, self.last_ms, self.failed = 0, None, False

    @classmethod
    def open(cls, port, log):
        # Importing this module never opens a device or imports serial.
        import serial
        stream = serial.Serial(port, 921600, timeout=.001, write_timeout=.02)
        stream.dtr = False
        stream.rts = False
        stream.reset_input_buffer()
        return cls(stream, log)

    def close(self):
        self.transport.close()

    def command(self, op=0, address=0, tx=b"", rx_count=0, *, budget_ms=20):
        if self.failed:
            raise BoardError("transport requires reopen after an ambiguous/late transaction")
        if op not in (0, 1, 3) or not 0 <= address <= 127 or len(tx)>4 or not 0 <= rx_count <= 64:
            raise ValueError("unsupported diagnostic request; no buzzer-ON operation exists")
        if not 0 < budget_ms <= 2000:
            raise ValueError("invalid transaction budget")
        self.seq = self.seq % 254 + 1  # 0xff is reserved for unsolicited identity.
        body = bytes((op,self.seq,address,len(tx),rx_count)) + tx.ljust(4,b"\0")
        checksum = 0
        for byte in body: checksum ^= byte
        request = b"\xa5\x5a" + body + bytes((checksum,))
        record = {"scope":"REAL_DIAGNOSTIC_IO_IF_EXECUTED", "request_hex":request.hex(),
                  "budget_ms":budget_ms, "op":op, "sequence":self.seq}
        start = self.clock()
        deadline = start + budget_ms/1000
        buffer = bytearray()
        try:
            written = self.transport.write(request)
            if written != len(request):
                raise BoardError("short UART write")
            while self.clock() < deadline:
                available = self.transport.in_waiting
                buffer.extend(self.transport.read(min(available,4096) if available else 1))
                while True:
                    begin = buffer.find(b"\x5a\xa5")
                    if begin < 0:
                        if len(buffer)>1: del buffer[:-1]
                        break
                    if begin: del buffer[:begin]
                    if len(buffer)<9: break
                    length = buffer[4]
                    if length>64:
                        del buffer[0]
                        continue
                    total = 10+length
                    if len(buffer)<total: break
                    response = bytes(buffer[:total])
                    xor = 0
                    for byte in response[2:-1]: xor ^= byte
                    if xor != response[-1]:
                        del buffer[0]
                        continue
                    del buffer[:total]
                    if response[2] != self.seq:
                        continue
                    record.update(response_hex=response.hex(),status=response[3])
                    current_ms = struct.unpack_from("<I",response,5)[0]
                    if self.last_ms is not None and ((current_ms-self.last_ms)&0xffffffff)>=0x80000000:
                        raise BoardError("board time reset or moved backwards")
                    self.last_ms = current_ms
                    record["board_ms"] = current_ms
                    if self.clock() > deadline:
                        raise TimeoutError("UART round trip exceeded transaction budget")
                    if response[3]:
                        raise BoardError("BOARD_STATUS_"+str(response[3]))
                    payload = response[9:-1]
                    expected = 8 if op==0 else 1 if op==3 else rx_count
                    if len(payload) != expected:
                        raise BoardError("unexpected diagnostic payload size")
                    return payload
            raise TimeoutError("no matching reply within transaction budget")
        except Exception as exc:
            self.failed = True
            record["error"] = repr(exc)
            record["trailing_received_hex"] = buffer.hex()
            raise
        finally:
            record["duration_ms"] = (self.clock()-start)*1000
            self.log.write(json.dumps(record)+"\n")
            self.log.flush()

    def identify(self):
        identity = self.command(budget_ms=200)
        if identity != self.IDENTITY:
            self.failed = True
            raise BoardError("wrong image identity; expected BQFAST01")
        status = self.command(3,budget_ms=200)
        if status[0]&4:
            self.failed = True
            raise BoardError("diagnostic buzzer logic unexpectedly high")
        return identity

    def read(self, address, tx, count):
        return self.command(1,address,tx,count,budget_ms=20)

    def read_words(self, reg, count):
        if not 1 <= count <= 832 or not 0 <= reg <= 65536-count:
            raise ValueError("invalid register range")
        output = []
        while count:
            chunk = min(32,count)
            payload = self.read(0x33,reg.to_bytes(2,"big"),chunk*2)
            output.extend(struct.unpack(">"+str(chunk)+"H",payload))
            reg += chunk
            count -= chunk
        return output

    def write_word(self, reg, value):
        self.read(0x33,reg.to_bytes(2,"big")+value.to_bytes(2,"big"),0)
