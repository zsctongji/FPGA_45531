import unittest
from check_capture import check

class CaptureContractTests(unittest.TestCase):
    def setUp(self):
        self.raw=bytes(2016)+bytes(i%251 for i in range(5184))+bytes(2016)
        self.meta=dict(frame_id=0xffffffff,timestamp_ms=0xffffffff,checksum=sum(self.raw),evidence='hardware')
    def test_legacy_minimal_metadata(self):
        self.assertFalse(check(self.raw,self.meta)['physical_proven'])
    def test_explicit_geometry(self):
        self.meta.update(width=96,height=96,active_width=96,active_height=54,pad_top=21,pad_bottom=21)
        self.assertEqual(check(self.raw,self.meta)['bytes'],9216)
    def test_wrong_declared_crop_rejected(self):
        for key,value in [('width',54),('active_height',96),('pad_top',20),('pad_bottom',22),('height',54),('active_width',95)]:
            with self.subTest(key=key),self.assertRaises(ValueError):check(self.raw,dict(self.meta,**{key:value}))
    def test_bool_is_not_uint32(self):
        for field in ('frame_id','timestamp_ms','checksum'):
            with self.subTest(field=field),self.assertRaises(ValueError):check(self.raw,dict(self.meta,**{field:True}))
    def test_geometry_bool_rejected(self):
        with self.assertRaises(ValueError):check(self.raw,dict(self.meta,pad_top=True))
    def test_reject_corrupt_padding_even_with_matching_sum(self):
        raw=bytes([1])+self.raw[1:]
        with self.assertRaises(ValueError):check(raw,dict(self.meta,checksum=sum(raw)))
    def test_reject_corrupt_active_data(self):
        raw=self.raw[:3000]+bytes([self.raw[3000]^1])+self.raw[3001:]
        with self.assertRaises(ValueError):check(raw,self.meta)

if __name__=='__main__':unittest.main()
