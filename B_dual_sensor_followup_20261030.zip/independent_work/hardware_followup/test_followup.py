"""Focused tests of the real C adapter boundary; no hardware is opened."""
import unittest
from dual_soak import Sensor, crc8

class FakeBridge:
    def __init__(self, *, bad_crc=False, fail_clock=False):
        self.last_ms=100;self.failed=False;self.bad_crc=bad_crc;self.fail_clock=fail_clock
    def command(self,op,address=0,tx=b'',rx_count=0,budget_ms=20):
        if self.fail_clock and op==3:raise TimeoutError('injected board clock failure')
        self.last_ms+=2
        if op==3:return b'\x03'
        if address!=0x45:raise AssertionError('wrong sensor address')
        if tx==b'\x24\x00' and rx_count==0:return b''
        if not tx and rx_count==6:
            raw=b'\x66\x66';rh=b'\x80\x00'
            return raw+bytes([crc8(raw)^(1 if self.bad_crc else 0)])+rh+bytes([crc8(rh)])
        raise AssertionError('unexpected I2C request')

class Tests(unittest.TestCase):
    def test_original_c_driver_and_board_time(self):
        b=FakeBridge();r=Sensor(b).sample()
        self.assertTrue(r['valid']);self.assertEqual(r['abi_version'],0x10000)
        self.assertEqual(r['temperature_centi_c'],2500)
        self.assertEqual(r['humidity_centi_percent'],5000)
        self.assertGreaterEqual(r['timestamp_ms'],100)
        self.assertEqual(r['attempts'],1)
    def test_crc_fault_exhausts_real_c_retry_limit(self):
        r=Sensor(FakeBridge(bad_crc=True)).sample()
        self.assertFalse(r['valid']);self.assertEqual(r['attempts'],3)
        self.assertEqual(r['error_bits'],4);self.assertEqual(r['valid_flags'],0)
    def test_clock_failure_never_accepts_sample(self):
        r=Sensor(FakeBridge(fail_clock=True)).sample()
        self.assertFalse(r['valid']);self.assertIsNotNone(r['callback_error'])

if __name__=='__main__':unittest.main()
