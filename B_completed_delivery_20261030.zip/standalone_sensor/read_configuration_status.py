import json,sys,time
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'tools'))
from program_led_sram import LocalSingleTap,CompatibleD2xx
from efx_pgm.device_utils import DeviceUtils
from efx_pgm.prog_detector import TiProgStateDetector
engine=LocalSingleTap(engine_provider=CompatibleD2xx(trst=False,frequency=1E6),tap='efx_ti')
report={'at':datetime.now().astimezone().isoformat(),'operation':'READ_CONFIGURATION_STATUS','wrote_flash':False,'samples':[]}
try:
 engine.configure('hiftdi://0x0403:0x6011/1');engine.reset()
 code=int(engine.read_dr(32));report['idcode']=hex(code)
 if code!=0x10660A79:raise RuntimeError('Unexpected target')
 detector=TiProgStateDetector(DeviceUtils().get_info_by_idcode(code))
 for _ in range(3):
  bits=detector.read_bsr(engine)
  report['samples'].append({'bits_lsb_first':bits,'state':detector.decode_prog_state(bits),'registers':detector.get_register_values(bits)})
  time.sleep(.1)
finally:
 engine.reset();engine.close()
p=ROOT/'logs'/'configuration_status_20261029.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
