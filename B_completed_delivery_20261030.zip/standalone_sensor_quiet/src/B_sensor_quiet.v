module B_sensor_quiet(
 input wire [3:0] key_i,input wire sys_pll_LOCKED,clk_sel,clk_50m,clk_54m,clk_25m_x2,
 (* syn_peri_port=0 *) input wire osc_clk,
 (* syn_peri_port=0 *) output wire osc_inst1_ENA,
 output wire [1:0] led_data,output wire sys_pll_RSTN,
 input wire uart_rx,output wire uart_tx,
 input wire sensor_scl_in,sensor_sda_in,
 output wire sensor_scl_out,sensor_sda_out,output wire sensor_scl_oe,sensor_sda_oe,
 output wire buzzer_sig);
assign sys_pll_RSTN=key_i[0];assign osc_inst1_ENA=1'b1;
reg [1:0] rst_sync=3;
always @(posedge clk_50m)rst_sync<={rst_sync[0],1'b0};
wire rst=rst_sync[1];reg [15:0] ms_div=0;reg [31:0] ms_now=0;reg [8:0] buzz_ms=0;
reg [1:0] scl_sync=3,sda_sync=3;
always @(posedge clk_50m)begin scl_sync<={scl_sync[0],sensor_scl_in};sda_sync<={sda_sync[0],sensor_sda_in};
 if(rst)begin ms_div<=0;ms_now<=0;buzz_ms<=0;end
 else if(ms_div==49999)begin ms_div<=0;ms_now<=ms_now+1;if(buzz_ms!=0)buzz_ms<=buzz_ms-1;end else ms_div<=ms_div+1;
 if(buzzer_on)buzz_ms<=250;
 if(buzzer_off)buzz_ms<=0;
end
// Diagnostic mute: constant LOW even after an old ON command.
assign buzzer_sig=1'b0;assign sensor_scl_out=0;assign sensor_sda_out=0;
reg i2c_start=0;reg [6:0] address=0,rx_count=0;reg [2:0] tx_count=0;reg [31:0] tx_data=0;
wire i2c_busy,i2c_done;wire [7:0] i2c_status;wire [511:0] i2c_rx;
b_i2c_transaction engine(.clk(clk_50m),.rst(rst),.start(i2c_start),.address(address),.tx_count(tx_count),.rx_count(rx_count),.tx_data(tx_data),
 .scl_in(scl_sync[1]),.sda_in(sda_sync[1]),.scl_low(sensor_scl_oe),.sda_low(sensor_sda_oe),.busy(i2c_busy),.done(i2c_done),.status(i2c_status),.rx_data(i2c_rx));
wire [7:0] rx_byte;wire rx_valid;reg tx_start=0;reg [7:0] tx_byte=0;wire tx_busy;
b_uart_rx rx(.clk(clk_50m),.rst(rst),.rx(uart_rx),.data(rx_byte),.valid(rx_valid));
b_uart_tx tx(.clk(clk_50m),.rst(rst),.start(tx_start),.data(tx_byte),.tx(uart_tx),.busy(tx_busy));
reg [7:0] cmd [0:10];reg [3:0] cmd_index=0;reg [7:0] cmd_xor=0;reg [31:0] last_byte_ms=0;
reg [31:0] last_heartbeat_ms=0;
reg reply_pending=0;reg [6:0] reply_index=0,reply_length=0;reg [7:0] reply_seq=0,reply_status=0,reply_xor=0;
reg [31:0] reply_ms=0;reg [511:0] reply_data=0;reg waiting_i2c=0;reg buzzer_on=0,buzzer_off=0;
reg [7:0] selected_byte;
always @*begin
 if(reply_index==0)selected_byte=8'h5a;else if(reply_index==1)selected_byte=8'ha5;
 else if(reply_index==2)selected_byte=reply_seq;else if(reply_index==3)selected_byte=reply_status;
 else if(reply_index==4)selected_byte={1'b0,reply_length};
 else if(reply_index<9)selected_byte=reply_ms[(reply_index-5)*8 +:8];
 else if(reply_index<9+reply_length)selected_byte=reply_data[(reply_index-9)*8 +:8];
 else selected_byte=reply_xor;
end
always @(posedge clk_50m)begin
 tx_start<=0;i2c_start<=0;buzzer_on<=0;buzzer_off<=0;
 if(rst)begin cmd_index<=0;reply_pending<=0;waiting_i2c<=0;reply_index<=0;end
 else begin
  if(cmd_index!=0 && ms_now-last_byte_ms>20)cmd_index<=0;
  if(rx_valid)begin
   last_byte_ms<=ms_now;
   if(cmd_index==0)begin if(rx_byte==8'ha5)begin cmd_index<=1;cmd_xor<=0;end end
   else if(cmd_index==1)begin if(rx_byte==8'h5a)cmd_index<=2;else cmd_index<=(rx_byte==8'ha5)?1:0;end
   else if(cmd_index<11)begin cmd[cmd_index]<=rx_byte;cmd_xor<=cmd_xor^rx_byte;cmd_index<=cmd_index+1;end
   else begin
    cmd_index<=0;
    if(cmd_xor==rx_byte && !waiting_i2c && !reply_pending)begin
     reply_seq<=cmd[3];reply_status<=0;reply_length<=0;reply_ms<=ms_now;reply_index<=0;reply_xor<=0;
     if(cmd[2]==0)begin reply_data<=512'h3130544549555142;reply_length<=8;reply_pending<=1;end
     else if(cmd[2]==3)begin reply_data<={509'b0,buzzer_sig,scl_sync[1],sda_sync[1]};reply_length<=1;reply_pending<=1;end
     else if(cmd[2]==2 && cmd[5]==1 && cmd[6]==0 && cmd[7]==0)begin
      buzzer_off<=1;reply_pending<=1;
     end
     else if(cmd[2]==1 && (cmd[4]==8'h33 || cmd[4]==8'h44 || cmd[4]==8'h45) && cmd[5]<=4 && cmd[6]<=64 && (cmd[5]!=0 || cmd[6]!=0))begin
      address<=cmd[4][6:0];tx_count<=cmd[5][2:0];rx_count<=cmd[6][6:0];tx_data<={cmd[10],cmd[9],cmd[8],cmd[7]};i2c_start<=1;waiting_i2c<=1;
     end else begin reply_status<=3;reply_pending<=1;end
    end
   end
  end
  if(!reply_pending && !waiting_i2c && !rx_valid && ms_now-last_heartbeat_ms>=1000)begin
    last_heartbeat_ms<=ms_now;reply_seq<=8'hff;reply_status<=0;reply_length<=8;reply_ms<=ms_now;reply_data<=512'h3130544549555142;reply_index<=0;reply_xor<=0;reply_pending<=1;
  end
  if(i2c_done && waiting_i2c)begin
    waiting_i2c<=0;reply_status<=i2c_status;reply_data<=i2c_rx;reply_length<=(i2c_status==0)?rx_count:0;reply_ms<=ms_now;reply_pending<=1;
  end
  if(reply_pending && !tx_busy && !tx_start)begin
    tx_byte<=selected_byte;tx_start<=1;
    if(reply_index>=2 && reply_index<9+reply_length)reply_xor<=reply_xor^selected_byte;
    if(reply_index==9+reply_length)begin reply_pending<=0;reply_index<=0;end else reply_index<=reply_index+1;
  end
 end
end
assign led_data={!i2c_busy,ms_now[9]};
endmodule
