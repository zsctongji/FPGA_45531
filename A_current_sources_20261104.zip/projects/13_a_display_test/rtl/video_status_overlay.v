`timescale 1ns/1ps
// 1-cycle RGB/control pipeline. All scalar status latched at VS rising.
// External heat_read_* is combinational from a stable, complete front buffer;
// heat bank may change only at VS; heat values are pre-normalised 0..255.
// No implicit sensor/AI data: validity gates every element. Grid 96x54.
module video_status_overlay #(
    parameter integer FRAME_WIDTH=1920,FRAME_HEIGHT=1080,
    parameter integer PANEL_X=16,PANEL_Y=80,HEAT_SCALE=4,BORDER=4,TEXT_X=320,TEXT_Y=16,
    parameter integer STATUS_FLAGS=0,UI_SCALE=1,DIAGNOSTIC_TEST=0
)(
    input wire clk,rst_n,in_hs,in_vs,in_de,
    input wire [23:0] in_rgb,
    input wire thermal_valid,environment_valid,ai_valid,alarm_active,prediction_valid,
    // Optional age/fault status, bits visual/thermal/environment. Set STATUS_FLAGS=1.
    input wire [2:0] stale_mask,fault_mask,
    input wire [2:0] diagnostic_phase,
    input wire [7:0] person_score,event_score,event_type,
    input wire signed [15:0] temperature_centi,
    input wire [15:0] humidity_centi,
    input wire [6:0] prediction_x,prediction_y,
    input wire [31:0] status_frame_id,display_frame_id,
    input wire heat_pixel_valid,
    input wire [7:0] heat_level,
    output wire [9:0] heat_address,
    output wire heat_request,
    output reg out_hs,out_vs,out_de,
    output reg [23:0] out_rgb
);
    reg vs_d,de_d;
    reg [15:0] x,y;
    reg [15:0] ui_x,ui_y;
    reg [7:0] ui_x_repeat,ui_y_repeat;
    wire [15:0] ux=UI_SCALE==1?x:ui_x,uy=UI_SCALE==1?y:ui_y;
    reg [2:0] phase;
    localparam TEXT_HEIGHT=DIAGNOSTIC_TEST?56:32;
    reg tv,ev,av,al,pv;
    reg [2:0] sm,fm;
    reg [7:0] ps,es,et;
    reg [15:0] px,py;
    reg signed [15:0] tc;
    reg [15:0] rh;
    reg [31:0] fid;
    `include "osd_font5x7.vh"
    reg [127:0] textline;
    reg [7:0] character;
    reg [34:0] bitmap;
    integer abs_tc,col,row,bit_index;
    always @* begin
        abs_tc=tc<0?-tc:tc;
        textline="                ";
        col=0;row=0;bit_index=0;character=32;bitmap=0;
        if(ux>=TEXT_X&&ux<TEXT_X+96&&uy>=TEXT_Y&&uy<TEXT_Y+TEXT_HEIGHT) begin
            col=(ux-TEXT_X)/6;row=(uy-TEXT_Y)/8;
            case(row)
            0: begin
                textline="T ----.-- C     ";
                if(ev) begin
                    textline[111:104]=tc<0?"-":"+";
                    textline[103:96]="0"+(abs_tc/10000)%10;
                    textline[95:88]="0"+(abs_tc/1000)%10;
                    textline[87:80]="0"+(abs_tc/100)%10;
                    textline[71:64]="0"+(abs_tc/10)%10;
                    textline[63:56]="0"+abs_tc%10;
                end
            end
            1: begin
                textline="RH ---.--       ";
                if(ev) begin
                    textline[103:96]="0"+(rh/10000)%10;
                    textline[95:88]="0"+(rh/1000)%10;
                    textline[87:80]="0"+(rh/100)%10;
                    textline[71:64]="0"+(rh/10)%10;
                    textline[63:56]="0"+rh%10;
                end
            end
            2: begin
                textline="AI --- FS --- T-";
                if(av) begin
                    textline[103:96]="0"+ps/100;textline[95:88]="0"+(ps/10)%10;textline[87:80]="0"+ps%10;
                    textline[47:40]="0"+es/100;textline[39:32]="0"+(es/10)%10;textline[31:24]="0"+es%10;
                    textline[7:0]=hexchar(et[3:0]);
                end
            end
            3: begin
                textline="FRAME 00000000  ";
                textline[79:16]={hexchar(fid[31:28]),hexchar(fid[27:24]),hexchar(fid[23:20]),hexchar(fid[19:16]),hexchar(fid[15:12]),hexchar(fid[11:8]),hexchar(fid[7:4]),hexchar(fid[3:0])};
            end
            5: if(DIAGNOSTIC_TEST)textline="A DISPLAY TEST  ";
            6: if(DIAGNOSTIC_TEST)case(phase)
                0:textline="0 MISSING       ";
                1:textline="1 VALID         ";
                2:textline="2 STALE         ";
                3:textline="3 FAULT         ";
                4:textline="4 ALARM PRED    ";
                default:textline="5 FRAME MISMATCH";
            endcase
            endcase
            character=textline[127-col*8 -:8];bitmap=glyph(character);
            bit_index=34-((uy-TEXT_Y)%8)*5-(ux-TEXT_X)%6;
        end
    end
    wire inside_heat=ux>=PANEL_X && ux<PANEL_X+32*HEAT_SCALE && uy>=PANEL_Y && uy<PANEL_Y+24*HEAT_SCALE;
    assign heat_address=inside_heat ? ((uy-PANEL_Y)/HEAT_SCALE)*32+(ux-PANEL_X)/HEAT_SCALE : 0;
    assign heat_request=in_de&&inside_heat&&tv;
    reg [23:0] pixel;
    always @* begin
        pixel=in_rgb;
        if(in_de) begin
            // Four 12x12 health squares: IR/env/AI/armed alarm. Grey means absent.
            if(uy>=16&&uy<28&&ux>=16&&ux<76) begin
                if(ux<28) pixel=fm[1]?24'hff3000:sm[1]?24'hffaa00:tv?24'h00cc80:24'h606060;
                else if(ux>=32&&ux<44) pixel=fm[2]?24'hff3000:sm[2]?24'hffaa00:ev?24'h00cc80:24'h606060;
                else if(ux>=48&&ux<60) pixel=fm[0]?24'hff3000:sm[0]?24'hffaa00:av?24'h00cc80:24'h606060;
                else if(ux>=64) pixel=al?24'hff3000:24'h606060;
            end
            // Separate score bars: width 0..255; no score when AI invalid/mismatched.
            if(uy>=36&&uy<44&&ux>=16&&ux<272) pixel=av&&ux-16<ps?24'h00aaff:24'h303030;
            if(uy>=48&&uy<56&&ux>=16&&ux<272) pixel=av&&ux-16<es?24'hffaa00:24'h303030;
            // Event type as four bits, documented as a diagnostic (not text OSD).
            if(uy>=60&&uy<68&&ux>=16&&ux<48) pixel=av&&et[(ux-16)/8]?24'hffffff:24'h303030;
            if(inside_heat) begin
                if(!tv||!heat_pixel_valid) pixel=((ux/4+uy/4)%2)?24'h606060:24'h303030;
                else pixel={heat_level,8'h20,~heat_level};
            end
            if(ux>=TEXT_X&&ux<TEXT_X+96&&uy>=TEXT_Y&&uy<TEXT_Y+TEXT_HEIGHT)
                pixel=(ux-TEXT_X)%6<5&&(uy-TEXT_Y)%8<7&&bitmap[bit_index]?24'hffffff:24'h202020;
            if(pv && ((x+3>=px&&x<=px+3&&y==py)||(y+3>=py&&y<=py+3&&x==px))) pixel=24'h00ffff;
            if(al && (x<BORDER||y<BORDER||x>=FRAME_WIDTH-BORDER||y>=FRAME_HEIGHT-BORDER)) pixel=24'hff0000;
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            vs_d<=0;de_d<=0;x<=0;y<=0;tv<=0;ev<=0;av<=0;al<=0;pv<=0;sm<=0;fm<=0;
            ui_x<=0;ui_y<=0;ui_x_repeat<=0;ui_y_repeat<=0;phase<=0;
            ps<=0;es<=0;et<=0;px<=0;py<=0;tc<=0;rh<=0;fid<=0;out_hs<=0;out_vs<=0;out_de<=0;out_rgb<=0;
        end else begin
            vs_d<=in_vs;de_d<=in_de;
            out_hs<=in_hs;out_vs<=in_vs;out_de<=in_de;out_rgb<=pixel;
            if(in_vs&&!vs_d) begin
                phase<=diagnostic_phase;
                ui_x<=0;ui_y<=0;ui_x_repeat<=0;ui_y_repeat<=0;
                sm<=STATUS_FLAGS?stale_mask:3'b0;fm<=STATUS_FLAGS?fault_mask:3'b0;
                x<=0;y<=0;tv<=thermal_valid;ev<=environment_valid&&humidity_centi<=10000;
                tc<=temperature_centi;rh<=humidity_centi;fid<=display_frame_id;
                av<=ai_valid&&status_frame_id==display_frame_id;
                // Alarm is current event state; it can remain held across frames.
                al<=alarm_active;
                pv<=prediction_valid&&status_frame_id==display_frame_id&&prediction_x<96&&prediction_y<54;
                ps<=person_score;es<=event_score;et<=event_type;
                px<=prediction_x*FRAME_WIDTH/96;py<=prediction_y*FRAME_HEIGHT/54;
            end else if(in_de) begin
                x<=x+1'b1;
                if(UI_SCALE>1)begin
                    if(ui_x_repeat==UI_SCALE-1)begin ui_x_repeat<=0;ui_x<=ui_x+1'b1;end
                    else ui_x_repeat<=ui_x_repeat+1'b1;
                end
            end else if(de_d) begin
                x<=0;y<=y+1'b1;ui_x<=0;ui_x_repeat<=0;
                if(UI_SCALE>1)begin
                    if(ui_y_repeat==UI_SCALE-1)begin ui_y_repeat<=0;ui_y<=ui_y+1'b1;end
                    else ui_y_repeat<=ui_y_repeat+1'b1;
                end
            end
        end
    end
endmodule
