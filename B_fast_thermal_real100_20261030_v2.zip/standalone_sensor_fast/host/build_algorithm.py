"""Rebuild the frozen numerical library with an explicit GCC executable."""
import argparse
from pathlib import Path
import subprocess


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gcc",default="gcc")
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    command=[args.gcc,"-std=c99","-O2","-Wall","-Wextra","-shared",
             str(root/"native/thermal_algorithm.c"),
             str(root/"vendor/mlx90640/functions/MLX90640_API.c"),
             "-I"+str(root/"vendor/mlx90640/headers"),"-lm","-o",str(root/"host/thermal_algorithm.dll")]
    return subprocess.run(command).returncode


if __name__=="__main__":raise SystemExit(main())
