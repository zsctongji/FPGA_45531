`timescale 1ns/1ps
module tb_i2c;
reg clk=0;always #5 clk=~clk;reg rst=1,start=0;reg [6:0] addr=7'h44,rc=0;reg [2:0] tc=0;reg [31:0] td=0;
tri1 scl,sda;wire sl,dl,busy,done;wire [7:0] status;wire [511:0] data;reg slave_low=0,stretch=0;
assign scl=(sl||stretch)?1'b0:1'bz;assign sda=(dl||slave_low)?1'b0:1'bz;
b_i2c_transaction #(.CLK_HZ(1000000),.I2C_HZ(100000),.TIMEOUT_CYCLES(5000)) dut(clk,rst,start,addr,tc,rc,td,scl,sda,sl,dl,busy,done,status,data);
reg [7:0] received;
task ws;begin @(negedge sda);while(scl!==1'b1)@(negedge sda);end endtask
task receive_byte;output [7:0] value;integer b;begin value=0;for(b=0;b<8;b=b+1)begin @(posedge scl);value={value[6:0],sda};end @(negedge scl);slave_low=1;@(posedge scl);@(negedge scl);slave_low=0;end endtask
task send_byte;input [7:0] value;input final_byte;integer b;begin
 for(b=7;b>=0;b=b-1)begin slave_low=!value[b];@(posedge scl);@(negedge scl);end
 slave_low=0;@(posedge scl);if(sda!==final_byte)$fatal(1,"read ACK/NACK incorrect");@(negedge scl);
end endtask
task launch;begin @(negedge clk);start=1;@(negedge clk);start=0;end endtask
task await_done;input [7:0] expected;begin wait(done);if(status!==expected)$fatal(1,"status got %d expected %d",status,expected);@(negedge clk);end endtask
initial begin #100;@(negedge clk);rst=0;
 tc=2;rc=0;td=32'h00000024;
 fork
 begin ws;receive_byte(received);if(received!=8'h88)$fatal(1,"write address");receive_byte(received);if(received!=8'h24)$fatal(1,"tx0");receive_byte(received);if(received!=0)$fatal(1,"tx1");end
 begin launch;await_done(0);end
 join
 addr=7'h33;tc=2;rc=2;td=32'h00000080;
 fork
 begin ws;receive_byte(received);if(received!=8'h66)$fatal(1,"combined write addr");receive_byte(received);if(received!=8'h80)$fatal(1,"reg hi");receive_byte(received);if(received!=0)$fatal(1,"reg lo");ws;receive_byte(received);if(received!=8'h67)$fatal(1,"read address");send_byte(8'h12,0);send_byte(8'h34,1);end
 begin launch;await_done(0);if(data[15:0]!=16'h3412)$fatal(1,"read payload %x",data[15:0]);end
 join
 tc=0;rc=1;addr=7'h44;launch;await_done(1);
 stretch=1;launch;await_done(2);stretch=0;
 addr=0;launch;await_done(3);
 if(sl||dl)$fatal(1,"bus not released");
 $display("PASS: write, repeated START/read, ACK/NACK, absent-device NACK, stuck-clock timeout, invalid address, bus release");$finish;
end
initial begin #1000000;$fatal(1,"bench timeout");end
endmodule
