import random
import unittest
import json
from pathlib import Path
import tempfile
import threading
import time
from serial_pump import SerialPump
import urllib.request
from http.server import ThreadingHTTPServer
from capture_headless import Decoder,HEADER,bmp
from headless_preview import handler

def fixture(fid=7):
    raw=bytes(2016)+bytes(i%251 for i in range(5184))+bytes(2016)
    parts=[]
    for i in range(36):
        h=HEADER.pack(b'A3V1',fid,123,sum(raw),32,1000,1,2,10,20,15,1,i,36,256,0)
        p=h+raw[i*256:(i+1)*256]
        parts.append(p+sum(p).to_bytes(4,'little'))
    return raw,parts

class HeadlessTests(unittest.TestCase):
    def test_serial_pump_preserves_bytes_and_closes(self):
        class Port:
            def __init__(self):self.parts=[b'abc',b'def'];self.setup=None
            def set_buffer_size(self,**kw):self.setup=kw
            def read(self,n):
                time.sleep(.001)
                return self.parts.pop(0) if self.parts else b''
        port=Port()
        with SerialPump(port) as pump:
            result=b''
            while len(result)<6:result+=pump.read()
            self.assertEqual(result,b'abcdef')
        self.assertEqual(port.setup['rx_size'],1048576)
        self.assertFalse(pump.thread.is_alive())

    def test_serial_pump_overflow_is_explicit_failure(self):
        class Port:
            def read(self,n):return b'x'*2048
        with SerialPump(Port(),max_chunks=1) as pump:
            pump.thread.join(timeout=1)
            with self.assertRaises(BufferError):pump.read()

    def test_readonly_preview_complete_and_path_limits(self):
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory);raw,parts=fixture();meta=Decoder().feed(b''.join(parts))[1][0][1]
            (folder/'frame_0000000007.json').write_text(json.dumps(meta),encoding='utf-8')
            (folder/'frame_0000000007.bmp').write_bytes(bmp(raw))
            (folder/'frame_0000000008.json').write_text('{',encoding='utf-8')
            server=ThreadingHTTPServer(('127.0.0.1',0),handler(folder));thread=threading.Thread(target=server.serve_forever);thread.start()
            try:
                url=f'http://127.0.0.1:{server.server_port}'
                with urllib.request.urlopen(url+'/status',timeout=2) as response:d=json.load(response)
                self.assertEqual(d['latest']['frame_id'],7)
                with urllib.request.urlopen(url+'/image.bmp?frame=7',timeout=2) as response:self.assertEqual(response.read(),bmp(raw))
                with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(url+'/image.bmp?frame=../../raw.bin',timeout=2)
            finally:server.shutdown();server.server_close();thread.join()

    def test_fragmented_wire_and_image(self):
        raw,parts=fixture();d=Decoder();wire=b'noise'+b''.join(parts);images=[];r=random.Random(17)
        while wire:
            n=r.randrange(1,700);records,out=d.feed(wire[:n]);wire=wire[n:];images+=out
        self.assertEqual(len(images),1);self.assertEqual(images[0][0],raw)
        meta=images[0][1];self.assertEqual(meta['bbox_grid'],[1,2,10,20])
        self.assertIsNone(meta['source_frame_id']);self.assertFalse(meta['shared_soc_time'])
        self.assertFalse(meta['cpu_read']);self.assertEqual(d.stats['noise_bytes'],5)
        self.assertEqual(bmp(raw)[:2],b'BM')

    def test_damaged_packet_and_missing_frame(self):
        _,parts=fixture();d=Decoder();p=bytearray(parts[5]);p[75]^=1;parts[5]=bytes(p)
        self.assertEqual(d.feed(b''.join(parts))[1],[])
        self.assertEqual(d.stats['bad_sum'],1)
        raw,nextparts=fixture(8);self.assertEqual(d.feed(b''.join(nextparts))[1][0][0],raw)
        self.assertEqual(d.stats['incomplete_images'],1)

    def test_metadata_cannot_mix(self):
        _,parts=fixture();d=Decoder();p=bytearray(parts[5]);p[16]+=1
        p[-4:]=sum(p[:-4]).to_bytes(4,'little');parts[5]=bytes(p)
        self.assertEqual(d.feed(b''.join(parts))[1],[])
        self.assertGreater(d.stats['metadata_mismatch'],0)

    def test_padding_failure_despite_valid_sum(self):
        _,parts=fixture();d=Decoder();p=bytearray(parts[0]);p[40]=1
        # Recompute each packet's image SUM32 header to defeat only the sum check.
        parts[0]=bytes(p)
        for i,packet in enumerate(parts):
            p=bytearray(packet);p[12:16]=(int.from_bytes(p[12:16],'little')+1).to_bytes(4,'little')
            p[-4:]=sum(p[:-4]).to_bytes(4,'little');parts[i]=bytes(p)
        self.assertEqual(d.feed(b''.join(parts))[1],[]);self.assertEqual(d.stats['bad_image'],1)

if __name__=='__main__':unittest.main()
