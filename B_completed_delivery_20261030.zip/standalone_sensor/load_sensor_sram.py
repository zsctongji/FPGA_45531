import hashlib,json,sys,traceback,contextlib,io
from pathlib import Path
from datetime import datetime
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'tools'))
from program_led_sram import LocalSingleTap,CompatibleD2xx,FtdiProgram,PinoutProfile
artifact=ROOT/'outflow'/'B_sensor_test.hex'
pins=(ROOT/'outflow'/'B_sensor_test.pinout.csv').read_text()
for row in ['B3,GPIOL_04,sensor_scl,Bidirectional','C3,GPIOL_06,sensor_sda,Bidirectional','B5,GPIOL_10,buzzer_sig,Output','R4,GPIOL_02,uart_rx,Input','R14,GPIOR_28,uart_tx,Output']:
 if row not in pins:raise RuntimeError('Pin validation failed: '+row)
report=dict(checked_at=datetime.now().astimezone().isoformat(),operation='LOAD_STANDALONE_SENSOR_TEST_TO_SRAM',wrote_flash=False,
 bitstream=str(artifact),sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),status='NOT_STARTED',final_soc_test=False)
frequency=float(sys.argv[1]) if len(sys.argv)>1 else 100000.0
report['jtag_frequency_hz']=frequency
engine=LocalSingleTap(engine_provider=CompatibleD2xx(trst=False,frequency=frequency),tap='efx_ti');output=io.StringIO()
try:
 engine.configure('hiftdi://0x0403:0x6011/1');engine.reset();report['idcode_before']='0x%08X'%int(engine.read_dr(32))
 if report['idcode_before']!='0x10660A79':raise RuntimeError('Wrong target')
 pinout=PinoutProfile();pinout.JTAG_SET='FTDI_ADBUS7'
 programmer=FtdiProgram(SimpleNamespace(input_file=str(artifact),output_file=None,mode='jtag',urls=['hiftdi://0x0403:0x6011/1'],num=1,pinout=pinout),jtag_program_freq=frequency)
 with contextlib.redirect_stdout(output),contextlib.redirect_stderr(output):programmer._jtag_program(engine)
 engine.reset();report['idcode_after']='0x%08X'%int(engine.read_dr(32));report['status']='VENDOR_SRAM_SEQUENCE_COMPLETED'
 from efx_pgm.device_utils import DeviceUtils
 from efx_pgm.prog_detector import TiProgStateDetector
 detector=TiProgStateDetector(DeviceUtils().get_info_by_idcode(int(report['idcode_after'],16)))
 bits=detector.read_bsr(engine);report['configuration_state']=detector.decode_prog_state(bits);report['configuration_registers']=detector.get_register_values(bits)
 if report['configuration_state']!='USER_MODE':report['status']='CONFIGURATION_NOT_RUNNING'
except Exception as exc:report['status']='ERROR';report['error']=repr(exc);report['traceback']=traceback.format_exc()
finally:
 try:engine.reset();engine.close()
 except Exception:pass
(ROOT/'logs'/'sensor_sram_load.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
(ROOT/'logs'/'sensor_sram_load.log').write_text(output.getvalue(),encoding='utf-8')
print(output.getvalue());print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='VENDOR_SRAM_SEQUENCE_COMPLETED' else 1)

