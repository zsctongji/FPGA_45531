"""Execute portable A C adapter on MSVC host; compare wire bytes with Python.

This is host verification, not RISC-V CPU execution on the FPGA.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import os
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools/a_side'))
from protocol import packets

def main():
    vswhere=Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Microsoft Visual Studio/Installer/vswhere.exe'
    vs=subprocess.check_output([str(vswhere),'-latest','-products','*','-requires','Microsoft.VisualStudio.Component.VC.Tools.x86.x64','-property','installationPath'],text=True).strip()
    if not vs:raise RuntimeError('MSVC C compiler not found')
    vcvars=Path(vs)/'VC/Auxiliary/Build/vcvars64.bat'
    build=ROOT/'build/a_side/native';build.mkdir(parents=True,exist_ok=True)
    # Batch file avoids nesting command-line quotes; paths are fixed workspace paths.
    script=build/'compile.cmd'
    script.write_text(f'@echo off\ncall "{vcvars}" > "{build / "vcvars.log"}"\nif errorlevel 1 exit /b 1\ncl.exe /nologo /W4 /WX /std:c11 /Fe:a_test.exe /Fo:.\\ "{ROOT / "sim/test_a_firmware.c"}" "{ROOT / "firmware/a_side/a_side.c"}"\nexit /b %errorlevel%\n',encoding='utf-8')
    result=subprocess.run(['cmd.exe','/d','/c',str(script)],cwd=build,capture_output=True,text=True,timeout=90)
    log=result.stdout+result.stderr
    if result.returncode:
        (ROOT/'logs/a_firmware_host.log').write_text(log,encoding='utf-8');raise RuntimeError(log)
    p=subprocess.run([str(build/'a_test.exe'),str(build/'packets.bin')],cwd=build,capture_output=True,text=True,timeout=10)
    log+=p.stdout+p.stderr
    if p.returncode:raise RuntimeError(log)
    raw=(build/'packets.bin').read_bytes();offset=0;actual=[]
    while offset<len(raw):
        size=int.from_bytes(raw[offset:offset+2],'big');offset+=2
        actual.append(raw[offset:offset+size]);offset+=size
    image=bytes(2016)+bytes(i%251 for i in range(5184))+bytes(2016)
    expected=packets(2,7,8,0xffffffff,0xfffffff0,image,1)
    if actual!=expected:raise ValueError('C/Python packet byte mismatch')
    record=dict(status='PASS',scope='native_host_C_execution_and_RV_cross_compile_separate',
        fpga_cpu_executed=False,packet_count=len(actual),wire_byte_exact=True,
        finished=datetime.now(timezone.utc).isoformat(),
        sources={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                 [ROOT/'sim/test_a_firmware.c',ROOT/'firmware/a_side/a_side.c',ROOT/'firmware/a_side/a_side.h',Path(__file__)]})
    (ROOT/'logs/a_firmware_host.log').write_text(log,encoding='utf-8')
    (ROOT/'logs/a_firmware_host.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(log);print(json.dumps(record,indent=2))

if __name__=='__main__':main()
