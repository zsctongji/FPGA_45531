import contextlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from capture_fast import acquire, main
from d2xx_transport import D2xxTransport
from thermal_calculate import Calculator, read_u16
from thermal_scheduler import CaptureError
from test_fast_capture import Clock, frame


class NumericalRegression(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]/"fixtures/real_recording_20261029"
        self.ee=read_u16(self.root/"eeprom_u16_be.bin",832)
        self.frames=[read_u16(self.root/f"frame{i}_u16_be.bin",834) for i in range(2)]
        self.calculator=Calculator()
    def test_real_raw_grid_matches_corrected_reference(self):
        actual=self.calculator.pair(self.ee,self.frames)
        expected=json.loads((self.root/"corrected_grid.json").read_text(encoding="utf-8"))
        self.assertEqual(actual["valid_pixel_count"],767)
        self.assertIsNone(actual["temperature_c"][620])
        self.assertEqual(actual["pixel_valid_bits_hex"],expected["pixel_valid_bits_hex"])
        for a,b in zip(actual["temperature_c"],expected["temperature_c"]):
            if b is None:self.assertIsNone(a)
            else:self.assertAlmostEqual(a,b,places=4)
        swapped=self.calculator.pair(self.ee,list(reversed(self.frames)))
        self.assertEqual(actual["temperature_c"],swapped["temperature_c"])
    def test_duplicate_control_and_truncated_raw_rejected(self):
        with self.assertRaises(ValueError):self.calculator.pair(self.ee,[self.frames[0]]*2)
        f=list(self.frames[1]);f[832]^=0x80
        with self.assertRaises(ValueError):self.calculator.pair(self.ee,[self.frames[0],f])
        with self.assertRaises(ValueError):read_u16(self.root/"frame0_u16_be.bin",832)


class DeviceFixture:
    def __init__(self): self.control=0x1901;self.failed=False;self.last_ms=100;self.writes=[]
    def identify(self):return b"BQFAST01"
    def read_words(self,reg,count):return [self.control] if reg==0x800d else [0]*count
    def write_word(self,reg,value):
        self.writes.append((reg,value))
        if reg==0x800d:self.control=value


class OrchestrationTests(unittest.TestCase):
    def test_default_entry_does_not_open_device(self):
        with patch("capture_fast.FastBridge.open",side_effect=AssertionError("unexpected hardware")) as opened:
            with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(main([]),0)
        opened.assert_not_called()
    def test_preserves_raw_then_restores_control(self):
        with tempfile.TemporaryDirectory() as temp, patch("capture_fast.FrameReader") as reader:
            reader.return_value.capture.side_effect=[frame(0,100,200),frame(1,300,400)]
            device=DeviceFixture()
            report,pairs=acquire(device,temp,pairs=1)
            self.assertEqual(report["status"],"CAPTURED_REQUESTED_DIAGNOSTIC_PAIRS")
            self.assertEqual(report["control_restore"],"VERIFIED")
            self.assertEqual(device.control,0x1901)
            self.assertEqual(len(pairs),1)
            self.assertEqual(read_u16(Path(temp)/"subpage_001_u16_be.bin",834),pairs[0][1].words)
            self.assertFalse(any(p.name.startswith("temperature") for p in Path(temp).iterdir()))
    def test_poisoned_transport_does_not_claim_restored(self):
        with tempfile.TemporaryDirectory() as temp, patch("capture_fast.FrameReader") as reader:
            device=DeviceFixture()
            def fail(**kwargs):device.failed=True;raise TimeoutError("ambiguous late reply")
            reader.return_value.capture.side_effect=fail
            report,pairs=acquire(device,temp,pairs=1)
            self.assertEqual(report["status"],"ERROR")
            self.assertEqual(report["control_restore"],"UNCONFIRMED_TRANSPORT_FAILED_REOPEN_REQUIRED")
            self.assertNotIn((0x800d,0x1901),device.writes)
    def test_torn_read_resets_pair_and_is_recorded(self):
        with tempfile.TemporaryDirectory() as temp, patch("capture_fast.FrameReader") as reader:
            reader.return_value.capture.side_effect=[frame(0,100,200),CaptureError("torn"),frame(1,300,400)]
            report,pairs=acquire(DeviceFixture(),temp,pairs=1,max_subpages=3)
            self.assertEqual(report["status"],"INSUFFICIENT_TIMELY_PAIRS")
            self.assertEqual(report["rejections"]["torn"],1)
            self.assertEqual(pairs,[])
            self.assertTrue((Path(temp)/"rejections.jsonl").exists())


class FtdiFixture:
    def __init__(self,port=8):self.port=port;self.latency=16;self.closed=False;self.calls=[]
    def __getattr__(self,name):return lambda *args:self.calls.append((name,args))
    def getComPortNumber(self):return self.port
    def getLatencyTimer(self):return self.latency
    def setLatencyTimer(self,value):self.latency=value
    def close(self):self.closed=True


class FtdiTransportTests(unittest.TestCase):
    def test_exact_interface_and_latency_restored(self):
        handle=FtdiFixture();seen=[]
        def open_ex(serial):seen.append(serial);return handle
        transport=D2xxTransport.open("EXACT_UART_D","COM8",SimpleNamespace(openEx=open_ex))
        self.assertEqual(seen,[b"EXACT_UART_D"])
        self.assertEqual(handle.latency,1)
        self.assertIn(("setBaudRate",(921600,)),handle.calls)
        transport.close()
        self.assertEqual(handle.latency,16)
        self.assertTrue(handle.closed)
    def test_wrong_com_closes_without_uart_configuration(self):
        handle=FtdiFixture(port=9)
        with self.assertRaises(ValueError):D2xxTransport.open("EXACT_UART_D","COM8",SimpleNamespace(openEx=lambda _:handle))
        self.assertTrue(handle.closed)
        self.assertEqual(handle.calls,[])


if __name__=="__main__":unittest.main()
