#include "b_sensors.h"
#include <string.h>
typedef uint32_t (*clock_cb)(void);
typedef int (*bus_cb)(uint8_t,const uint8_t*,uint32_t,uint8_t*,uint32_t,uint32_t);
static clock_cb clock_fn;
static bus_cb bus_fn;
static c3_hal_t hal;
static b_sht30_t sensor;
static uint32_t clock_read(void *ctx) {(void)ctx;return clock_fn();}
static int transfer(void *ctx,uint32_t bus,uint8_t addr,const uint8_t *tx,uint32_t nt,uint8_t *rx,uint32_t nr,uint32_t timeout) {
    (void)ctx;
    return bus==C3_I2C_SENSOR_BUS ? bus_fn(addr,tx,nt,rx,nr,timeout) : COOP_EINVAL;
}
__declspec(dllexport) int follow_bind(clock_cb c,bus_cb b) {
    if(!c||!b)return COOP_EINVAL;
    clock_fn=c;bus_fn=b;memset(&hal,0,sizeof(hal));
    hal.now_ms=clock_read;hal.i2c_write_read=transfer;
    return b_sht30_init(&sensor,&hal,0x45);
}
__declspec(dllexport) int follow_start(void) {return b_sht30_start(&sensor);}
__declspec(dllexport) int follow_poll(void) {return b_sht30_poll(&sensor);}
__declspec(dllexport) int follow_get(coop_environment_t *out) {return b_sht30_get(&sensor,out);}
__declspec(dllexport) unsigned follow_attempts(void) {return sensor.attempts;}
__declspec(dllexport) unsigned follow_environment_size(void) {return sizeof(coop_environment_t);}
