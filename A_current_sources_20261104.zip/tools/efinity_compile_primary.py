"""Run unchanged Efinity CLI scripts with the selected compatible Python.

Native Efinity tools, vendor sources and Windows security settings are unchanged.
Only child invocations of the vendor's Python executable are redirected to this
same runtime and wrapper, so Interface Designer also uses matching dependencies.
"""
import os
from pathlib import Path
import runpy
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'tools/efinity/2026.1'


def main():
    if sys.version_info[:2] != (3, 11):
        raise RuntimeError('Efinity protected components require CPython 3.11; use the verified project runtime.')
    action, *arguments = sys.argv[1:]
    scripts = VENDOR / 'scripts'
    sys.path[:0] = [str(scripts), str(VENDOR / 'pt/bin')]
    sys.path.append(str(VENDOR / 'python311/Lib/site-packages'))
    os.environ['PATH'] = str(VENDOR / 'python311/bin') + os.pathsep + os.environ['PATH']
    original_run = subprocess.run
    vendor_python = os.path.normcase(str(VENDOR / 'python311/bin/python.exe'))

    def compatible_run(command, *args, **kwargs):
        if isinstance(command, (list, tuple)) and command and os.path.normcase(str(command[0])) == vendor_python:
            child = Path(command[1]).resolve()
            if child.parent != scripts.resolve():
                raise ValueError('Unexpected Efinity Python child script')
            command = [sys.executable, str(Path(__file__).resolve()), child.name, *command[2:]]
        return original_run(command, *args, **kwargs)

    subprocess.run = compatible_run
    if action == '--preflight':
        sys.argv = [str(ROOT / 'tools/efinity_preflight.py')]
        runpy.run_path(sys.argv[0], run_name='__main__')
    else:
        if action not in ('efx_run.py', 'efx_run_pt_unified.py'):
            raise ValueError('Only Efinity compile and Interface Designer scripts are supported')
        sys.argv = [str(scripts / action), *arguments]
        runpy.run_path(sys.argv[0], run_name='__main__')


if __name__ == '__main__':
    main()
