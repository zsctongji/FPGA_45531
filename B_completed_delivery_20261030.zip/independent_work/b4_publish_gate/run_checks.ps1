param([string]$Compiler = 'C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe')
$ErrorActionPreference = 'Continue'
$root = $PSScriptRoot
$out = Join-Path $root 'out'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$include = 'D:\Ti60B\team_work\shared\include'
$quality = Join-Path $PSScriptRoot '..\b4_quality_policy'
$temporal = Join-Path $PSScriptRoot '..\b4_temporal_policy'
$log = Join-Path $out 'b4_publish_gate_checks.log'
& $Compiler -std=c11 -O2 -Wall -Wextra -Werror -pedantic ('-I' + $include) ('-I' + $quality) ('-I' + $temporal) (Join-Path $quality 'b4_quality_policy.c') (Join-Path $temporal 'b4_temporal_policy.c') (Join-Path $root 'b4_publish_gate.c') (Join-Path $root 'test_b4_publish_gate.c') -o (Join-Path $out 'test_b4_publish_gate.exe') > $log 2>&1
$compileCode = $LASTEXITCODE
if (Test-Path -LiteralPath $log) { Get-Content -LiteralPath $log }
if ($compileCode -ne 0) { throw "compile failed: $compileCode" }
& (Join-Path $out 'test_b4_publish_gate.exe') >> $log 2>&1
$testCode = $LASTEXITCODE
if (Test-Path -LiteralPath $log) { Get-Content -LiteralPath $log | Select-Object -Last 2 }
if ($testCode -ne 0) { throw "test failed: $testCode" }
