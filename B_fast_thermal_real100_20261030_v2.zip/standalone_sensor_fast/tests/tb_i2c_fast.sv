`timescale 1ns/1ps
module tb_i2c_fast;
reg clk=0;always #10 clk=~clk;
reg rst=1,start=0;reg [6:0] addr=7'h33,rc=0;reg [2:0] tc=0;reg [31:0] td=0;
tri1 scl,sda;wire sl,dl,busy,done;wire [7:0] status;wire [511:0] data;
reg slave_low=0,stretch=0;
assign scl=(sl||stretch)?1'b0:1'bz;
assign sda=(dl||slave_low)?1'b0:1'bz;
b_i2c_transaction #(.CLK_HZ(50000000),.I2C_HZ(400000),.TIMEOUT_CYCLES(500000))
 dut(clk,rst,start,addr,tc,rc,td,scl,sda,sl,dl,busy,done,status,data);
reg [7:0] received;integer k;time launched;
task ws;begin @(negedge sda);while(scl!==1'b1)@(negedge sda);end endtask
task receive_byte;output [7:0] value;integer b;begin
 value=0;for(b=0;b<8;b=b+1)begin @(posedge scl);value={value[6:0],sda};end
 @(negedge scl);slave_low=1;@(posedge scl);@(negedge scl);slave_low=0;
end endtask
task send_byte;input [7:0] value;input final_byte;integer b;begin
 for(b=7;b>=0;b=b-1)begin slave_low=!value[b];@(posedge scl);@(negedge scl);end
 slave_low=0;@(posedge scl);if(sda!==final_byte)$fatal(1,"read ACK/NACK incorrect");@(negedge scl);
end endtask
task launch;begin @(negedge clk);start=1;@(negedge clk);start=0;launched=$time;end endtask
task await_done;input [7:0] expected;begin
 wait(done);if(status!==expected)$fatal(1,"status got %d expected %d",status,expected);
 if(sl||dl)$fatal(1,"bus not released at done");@(negedge clk);
end endtask
initial begin
 #100;@(negedge clk);rst=0;
 tc=2;rc=64;td=32'h00000004;
 fork
 begin
  ws;receive_byte(received);if(received!=8'h66)$fatal(1,"write address");
  receive_byte(received);if(received!=8'h04)$fatal(1,"register high");
  receive_byte(received);if(received!=8'h00)$fatal(1,"register low");
  ws;receive_byte(received);if(received!=8'h67)$fatal(1,"repeated START/read address");
  for(k=0;k<64;k=k+1)send_byte(k^8'ha5,k==63);
 end
 begin
  launch;await_done(0);
  for(integer j=0;j<64;j=j+1)if(data[j*8 +:8]!==((j^8'ha5)&8'hff))$fatal(1,"payload index %d",j);
  if($time-launched>=10000000)$fatal(1,"normal transfer exceeded 10 ms");
  $display("64-byte combined transaction duration ns=%0d",$time-launched);
 end
 join
 // Clock is held LOW: hardware must stop after its 500000-clock budget.
 stretch=1;launch;await_done(2);
 if($time-launched<9999980 || $time-launched>10000100)$fatal(1,"10ms timeout outside expected clock bound");
 stretch=0;tc=1;rc=0;td=32'h24;addr=7'h44;
 fork
 begin ws;receive_byte(received);if(received!=8'h88)$fatal(1,"recovery address");receive_byte(received);if(received!=8'h24)$fatal(1,"recovery data");end
 begin launch;await_done(0);end
 join
 tc=0;rc=1;launch;await_done(1); // absent slave NACK
 addr=0;launch;await_done(3);
 $display("PASS: 50MHz/400k target, 64-byte payload, repeated START, final NACK, 10ms timeout, recovery, bus release");
 $finish;
end
initial begin #30000000;$fatal(1,"bench timeout");end
endmodule
