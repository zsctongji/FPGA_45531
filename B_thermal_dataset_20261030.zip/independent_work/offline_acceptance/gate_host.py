"""Compile and invoke the exact bundled B4 C sources; no Python gate emulation."""
import ctypes as C
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
U32, I32, U16, I16, U8 = C.c_uint32, C.c_int32, C.c_uint16, C.c_int16, C.c_uint8
ABI = 0x10000


def uint32(value):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 0xffffffff:
        raise ValueError("expected uint32")
    return value


def build_library(output_dir, compiler=None):
    cc = compiler or os.environ.get("CC") or shutil.which("gcc")
    candidate = Path(r"C:/Program Files (x86)/Dev-Cpp/MinGW64/bin/gcc.exe")
    if not cc and candidate.is_file(): cc = str(candidate)
    if not cc: raise RuntimeError("GCC is required to execute the original C gates; supply --cc")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    sources = [ROOT/"b4_gate_host.c"] + [ROOT/"vendor"/(n+".c") for n in
                                         ("b4_quality_policy","b4_temporal_policy","b4_publish_gate")]
    headers = sorted((ROOT/"vendor").glob("*.h"))
    identity = hashlib.sha256(b"".join(p.read_bytes() for p in sources+headers)).hexdigest()
    library = out/("b4_gate_"+identity[:12]+(".dll" if sys.platform=="win32" else ".so"))
    command = [str(cc),"-std=c11","-O2","-Wall","-Wextra","-Werror","-pedantic",
               "-shared","-I"+str(ROOT/"vendor")]
    if sys.platform != "win32": command += ["-fPIC"]
    command += [str(p) for p in sources]+["-o",str(library)]
    run = subprocess.run(command,capture_output=True,text=True,errors="replace",timeout=60)
    if run.returncode: raise RuntimeError("C compilation failed:\n"+run.stdout+run.stderr)
    version = subprocess.run([str(cc),"--version"],capture_output=True,text=True,timeout=15).stdout.splitlines()[0]
    return library,{"compiler":version,"flags":["-std=c11","-O2","-Wall","-Wextra","-Werror","-pedantic"],
                    "source_set_sha256":identity,"source_mode":"UNMODIFIED_BUNDLED_B4_C_POLICIES"}


class Gate:
    def __init__(self, library):
        self.lib = C.CDLL(str(Path(library).resolve()))
        self.lib.host_gate_create.restype = C.c_void_p
        self.lib.host_gate_destroy.argtypes = [C.c_void_p]
        self.lib.host_min_valid_pixels.restype = U32
        self.lib.host_environment.argtypes = [C.c_void_p,U32,U32,U32,U32,U32,I32,U32,U32,C.POINTER(U32),C.POINTER(U32)]
        self.lib.host_environment.restype = C.c_int
        self.lib.host_thermal.argtypes = [U32,U32,U32,U32,U32,C.POINTER(I16),C.POINTER(U8),U32,C.POINTER(U32),C.POINTER(U16),C.POINTER(U32)]
        self.lib.host_thermal.restype = C.c_int
        self.state = self.lib.host_gate_create()
        if not self.state: raise MemoryError("host gate state")
    def close(self):
        if self.state:
            self.lib.host_gate_destroy(self.state)
            self.state = None
    def __enter__(self): return self
    def __exit__(self,*unused): self.close()
    def environment(self, *, sample_id, timestamp_ms, flags, errors, temp_centi, humidity_centi, now_ms, abi=ABI):
        if abi != ABI: raise ValueError("ABI mismatch")
        if not self.state: raise ValueError("closed gate")
        for v in (sample_id,timestamp_ms,flags,errors,humidity_centi,now_ms): uint32(v)
        if isinstance(temp_centi,bool) or not isinstance(temp_centi,int) or not -(2**31) <= temp_centi < 2**31:
            raise ValueError("temperature must be int32")
        reason,preserved = U32(),U32()
        rc=self.lib.host_environment(self.state,abi,sample_id,timestamp_ms,flags,errors,temp_centi,humidity_centi,now_ms,C.byref(reason),C.byref(preserved))
        return {"rc":rc,"reason_bits":reason.value,"copy_or_rejection_preserved":bool(preserved.value)}
    def thermal(self, *, sample_id, timestamp_ms, flags, errors, temperatures, mask, now_ms, abi=ABI):
        if abi != ABI: raise ValueError("ABI mismatch")
        for v in (sample_id,timestamp_ms,flags,errors,now_ms): uint32(v)
        if len(temperatures)!=768 or len(mask)!=96: raise ValueError("thermal ABI dimensions")
        if any(isinstance(v,bool) or not isinstance(v,int) or not -32768<=v<=32767 for v in temperatures):
            raise ValueError("temperature must be int16 centi-C")
        values=(I16*768)(*temperatures); bits=(U8*96).from_buffer_copy(mask)
        reason,count,preserved=U32(),U16(),U32()
        rc=self.lib.host_thermal(abi,sample_id,timestamp_ms,flags,errors,values,bits,now_ms,C.byref(reason),C.byref(count),C.byref(preserved))
        return {"rc":rc,"reason_bits":reason.value,"valid_pixels":count.value,"copy_or_rejection_preserved":bool(preserved.value)}
