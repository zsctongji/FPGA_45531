"""Verify bundle contents and run host checks. Never opens board devices."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent

def execute(args):
    run=subprocess.run(args, cwd=ROOT, capture_output=True, text=True, errors="replace", timeout=90)
    if run.returncode:
        raise SystemExit(run.stdout+run.stderr)
    return run

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--cc")
    parser.add_argument("--report",type=Path)
    args=parser.parse_args()
    manifest=json.loads((ROOT/"B_independent_extensions_manifest.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        p=ROOT/item["path"]
        if not p.is_file() or p.stat().st_size!=item["bytes"] or hashlib.sha256(p.read_bytes()).hexdigest()!=item["sha256"]:
            raise SystemExit("Manifest mismatch: "+item["path"])
    python_results=[]
    for folder,pattern,expected in [("a96_gray_adapter","test_gray96_adapter.py",9),
                                    ("network_draft_v0","test_robust_receiver.py",14),
                                    ("network_draft_v0","test_network_draft.py",12)]:
        run=execute([sys.executable,"-B","-m","unittest","discover","-s",str(ROOT/"independent_work"/folder),"-p",pattern,"-v"])
        if f"Ran {expected} tests" not in run.stderr: raise SystemExit("Unexpected test count: "+pattern)
        python_results.append({"suite":pattern,"tests":expected,"status":"PASS"})
    cmd=[sys.executable,"-B",str(ROOT/"independent_work/c3_driver_host/run_driver_checks.py")]
    if args.cc: cmd += ["--cc",args.cc]
    c_report=json.loads(execute(cmd).stdout)
    report={"status":"PASS","scope":"OFFLINE_HOST_ONLY","hardware_accessed":False,
            "manifest_files_verified":len(manifest["files"]),"python_suites":python_results,"c_driver":c_report}
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))
if __name__=="__main__": main()
