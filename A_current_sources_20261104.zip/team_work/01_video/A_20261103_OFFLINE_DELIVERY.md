# A：最新仓库核对与无板交付（2026-11-03）

本轮没有连接或操作板卡、串口、JTAG、Flash。以下区分本轮离线复验、历史实测与联合待验。

## 仓库版本

已登录网页实际核对两个分支：默认 `codex/team-handoff` 更新于 2026-10-31，A 分支 `codex/a-video-20261029` 更新于 2026-10-30。默认分支当前提交为 `6c11cca8ca6cabf2d580334618434c8fd0877454`，标题为“Map video CDC FIFOs to BRAM and audit A B C pin ownership”。

网页下载的 ZIP 已完成，ZIP comment 与上述提交一致；源码只展开到 `build/repo_snapshot_20261103/FPGA_cooperation-codex-team-handoff`，没有覆盖本地 A 工程或队友 C 工程。根目录 README 含早期数字，应以最新专项文档为准：当前 C 回归入口为 53 次；不是原来的 49 次或 README 中的 50 次。该数字是队友的历史记录，本轮没有重跑整个 C 回归或 native 综合。

## 本轮完成

| 截图中 A 的任务 | 本轮交付 | 当前边界 |
|---|---|---|
| 摄像头 SoT、厂家工程、初始化及 lane/时钟核对 | `tools/audit_a_camera_reference.py` 和 `logs/a_camera_reference_20261103.json`；以本地 SC431HAI v3.4 厂家副本为参照，逐项提取 RX、PLL、SDC、寄存器和哈希 | RX 属性归一化比较与曝光配置可离线核对。SoT 根因、电气与线缆仍需新实物日志 |
| 完整视频采集、真实采集帧率和丢帧 | 历史 `logs/a_camera_input_acceptance_20261029.json` 及其原始数据；本轮重跑源格式/完整帧仿真 | 1970 条、65.196 s、约30.20124 fps 属历史源端记录，不是本轮新增采集或最终整机结果 |
| 96×54 / 96×96 及与 C 数据一致性 | 五张真图经当前 C 的实际 mailbox、DDR 行为模型和合成 CPU AXI 主机逐字节读回全部通过；新增可重跑入口 `tools/replay_a_current_c.py`，报告 `logs/a_current_c_replay_20261103.json` | 原始显示域帧号与时间不改名。测试台帧号/公共时间为合成值；未执行板上 CPU 或推理 |
| HDMI 叠加与 PC 接收 | 现有显示/同帧状态守卫、UDP 分包和 localhost 接收回归重跑通过；新增图像元数据契约检查与7项反例/边界测试 | 历史 A DISPLAY TEST 是接口测试画面，B/C字段并非实时整机数据；真实板端 Ethernet UDP 仍待验 |

### 校验器修正

原 `tools/a_side/check_capture.py` 验证长度、补零和 SUM32，却忽略元数据声明的尺寸。本轮新增检查：若声明 width/height、active_width/active_height、pad_top/pad_bottom，必须严格为 96/96、96/54、21/21；布尔值不能冒充 uint32 帧号、时间或校验值。兼容旧的仅含 mailbox 字段的元数据，不更改像素和协议。新反例包括改尺寸、改黑边、改有效数据和布尔类型。

### 摄像头静态核对结果

三份工程 11/12/13 均使用四条 RX 数据 lane，静态 delay=17、时钟 lane delay=0；RX optional 空属性归一化后与本地 v3.4 参照一致。源接口 SDC 声明 `i_mipi_rx_pclk` 为 20 ns（50 MHz）。这些是源文件声明，不是板上测量。

三工程均保留已验证曝光修正：0x3E00/01/02=00/7D/00，VTS 0x320E/0F=05/D2。与 v3.4 寄存器表相比还存在三个额外写入：0x3E08=80、0x3E09=2A、0x3221=66。工具完整列出差异，不把它们静默忽略；其对应实际模组与图像方向需 A/C/B 对照确认，所以总闸门仍为 REVIEW_REQUIRED。

## C 接入的决定性缺口

详见 `A_C_SOURCE_BOUNDARY_20261103.md`。当前 C 接口是单像素 GRAY8/VS/DE，厂家 CSI 解包输出为每拍四个 RAW10，旧显示侧还有双像素 BGR48。显示域已有灰度不能改名为源域采集；32位 RAW 数据不能按 RGB565 解释。尚需联合确定源端去马赛克、像素串行化、唯一 DDR、显示边界以及 PLL/Bank/pad 所有权。

此处不能仅靠“把端口连上”或再次播放保存图像结项。当前离线回放证明输入字节与 C 搬运一致，不证明 SoT 已修复、源首 DE 公共时间已上板、真实整机 HDMI 或板端网络已运行。

## 复现

使用本项目 Python 和 Icarus，工程根目录运行：

```powershell
python -X utf8 tools/audit_a_camera_reference.py
python -X utf8 tools/run_a_side.py
python -X utf8 tools/replay_a_current_c.py --repo "build/repo_snapshot_20261103/FPGA_cooperation-codex-team-handoff" --archive "C:/Users/zkr/Downloads/FPGA_cooperation-codex-team-handoff.zip"
```

第一条存在待审核寄存器差异时返回2，表示审计成功但尚未可发布；不能改成0来规避门禁。第二条含本机 loopback HTTP/UDP 测试，必须允许本机回环连接。受限环境的 WinError10013 以及 Icarus 子进程启动失败不算 RTL 失败；本轮在普通本机环境复跑保留了通过结果。

## 接板后的最小验收顺序

1. 先由 B 核对实际模组、排线方向、供电和独立/整机管脚。不要直接加载有 LCD 输出冲突的旧映像。
2. A/C 在同一最终镜像记录芯片 ID、初始化读回、各 lane SoT/CRC/ECC/溢出计数、源帧几何、完整帧数和测量时长。源码配置一致不能代替这一项。
3. 从真实源首 DE 锁存公共时间，取得同帧源图/96×54/补边96×96，检查 frame_id、时间、SUM32 和 C DDR/CPU 私有副本。VS数、完整帧数、采样数、网络重组数分别统计。
4. 接 B 的真实热图/环境和 C 的真实状态，核对显示帧对应及 STALE/FAULT；保存板端发送日志与 PC 原始 UDP，不用 localhost 包冒充板端网络。

两轮各30分钟长稳仍属于用户确认的 A 独立结果；18分钟中断为用户主动拔板，不改写原始记录，也不折算为整机稳定性。
