#include "b_sensors.h"
#include "b_mlx_port.h"
#include "MLX90640_API.h"
#include <string.h>
#include <math.h>
typedef uint32_t (*clock_cb_t)(void);
typedef int (*bus_cb_t)(uint8_t,const uint8_t*,uint32_t,uint8_t*,uint32_t,uint32_t);
static clock_cb_t clock_cb; static bus_cb_t bus_cb; static c3_hal_t hal;
static uint32_t now_ms(void *ctx) { (void)ctx; return clock_cb ? clock_cb() : 0; }
static int bus(void *ctx,uint32_t n,uint8_t a,const uint8_t *tx,uint32_t nt,uint8_t *rx,uint32_t nr,uint32_t timeout) { (void)ctx; return (n==0 && bus_cb) ? bus_cb(a,tx,nt,rx,nr,timeout) : COOP_EINVAL; }
__declspec(dllexport) int diag_bind(clock_cb_t c,bus_cb_t b,uint8_t a) { clock_cb=c;bus_cb=b;memset(&hal,0,sizeof(hal));hal.now_ms=now_ms;hal.i2c_write_read=bus; return b_sht30_init((b_sht30_t[1]){{0}},&hal,a); }
/* The bind return value above is only used as a capability sanity check by the SHT path. */
__declspec(dllexport) int diag_mlx_capture(uint32_t budget_ms,uint32_t calls,uint16_t *ee_out,uint16_t *frame0_out,uint16_t *frame1_out,float *pix0_out,float *pix1_out,uint16_t *meta_out) {
 int rc, r0=-99, r1=-99, sub0=255, sub1=255; uint16_t ee[832],f0[834],f1[834]; float p0[768],p1[768]; paramsMLX90640 p; uint32_t i; b_thermal_pair_t pair; uint8_t bad[96];
 if(!ee_out||!frame0_out||!frame1_out||!pix0_out||!pix1_out||!meta_out) return -1;
 rc=b_mlx_session_begin(&hal,budget_ms,calls); if(rc) return rc;
 rc=MLX90640_DumpEE(0x33,ee); if(rc){b_mlx_session_end();return rc;}
 rc=MLX90640_ExtractParameters(ee,&p); if(rc){b_mlx_session_end();return rc;}
 for(i=0;i<96;i++)bad[i]=0; for(i=0;i<5;i++){if(p.brokenPixels[i]!=0xffff)bad[p.brokenPixels[i]/8]|=(uint8_t)(1u<<(p.brokenPixels[i]%8));if(p.outlierPixels[i]!=0xffff)bad[p.outlierPixels[i]/8]|=(uint8_t)(1u<<(p.outlierPixels[i]%8));}
 r0=MLX90640_GetFrameData(0x33,f0); if(r0>=0){sub0=MLX90640_GetSubPageNumber(f0);MLX90640_CalculateTo(f0,&p,0.95f,MLX90640_GetTa(f0,&p)-8.0f,p0);}
 r1=-99; for(int tries=0; tries<6 && r1<0; ++tries){ uint16_t tmp[834]; int rr=MLX90640_GetFrameData(0x33,tmp); if(rr<0){r1=rr;break;} if(MLX90640_GetSubPageNumber(tmp)!=sub0){memcpy(f1,tmp,sizeof(f1));r1=rr;sub1=MLX90640_GetSubPageNumber(f1);MLX90640_CalculateTo(f1,&p,0.95f,MLX90640_GetTa(f1,&p)-8.0f,p1);} } 
 memcpy(ee_out,ee,sizeof(ee));memcpy(frame0_out,f0,sizeof(f0));memcpy(frame1_out,f1,sizeof(f1));memcpy(pix0_out,p0,sizeof(p0));memcpy(pix1_out,p1,sizeof(p1));
 memset(&pair,0,sizeof(pair)); b_thermal_init(&pair,&hal); if(r0>=0) b_thermal_push(&pair,(uint8_t)sub0,(uint8_t)((f0[832]>>12)&1u),p0,bad,1); if(r1>=0) b_thermal_push(&pair,(uint8_t)sub1,(uint8_t)((f1[832]>>12)&1u),p1,bad,1);
 meta_out[0]=(uint16_t)(r0<0?0xffff:r0);meta_out[1]=(uint16_t)(r1<0?0xffff:r1);meta_out[2]=(uint16_t)sub0;meta_out[3]=(uint16_t)sub1;meta_out[4]=(uint16_t)(pair.sample.valid_flags);meta_out[5]=(uint16_t)(pair.sample.error_bits);meta_out[6]=(uint16_t)(pair.sample.sample_id);meta_out[7]=(uint16_t)(p.brokenPixels[0]);meta_out[8]=(uint16_t)(p.outlierPixels[0]);
 rc=b_mlx_session_end(); meta_out[9]=(uint16_t)(rc==COOP_OK?0:1); return 0;
}


