"""Restore an evidenced MLX control register and check bounded real NACK recovery."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
sys.path.insert(0,str(BASE/'standalone_sensor_fast/host'))
from fast_bridge import FastBridge,BoardError
from d2xx_transport import D2xxTransport

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run-hardware',action='store_true')
    p.add_argument('--source-summary',type=Path)
    p.add_argument('--port');p.add_argument('--ftdi-serial')
    a=p.parse_args(argv)
    if not a.run_hardware:
        print(json.dumps(dict(status='OFFLINE_PLAN_ONLY',hardware_accessed=False)));return 0
    if not a.source_summary or not a.port or not a.ftdi_serial:p.error('evidence summary and explicit UART mapping required')
    evidence=json.loads(a.source_summary.read_text(encoding='utf-8'))
    target=evidence['original_control']
    if evidence.get('identity')!='BQFAST01' or not 0<=target<=65535:p.error('invalid restore evidence')
    out=BASE/'logs'/datetime.now().strftime('recovery_check_%Y%m%d_%H%M%S_%f');out.mkdir()
    report=dict(scope='REAL_STANDALONE_NACK_RECOVERY_AND_CONFIG_RESTORE',source_summary=str(a.source_summary.resolve()),source_summary_sha256=hashlib.sha256(a.source_summary.read_bytes()).hexdigest(),restore_target=target,port=a.port,ftdi_serial=a.ftdi_serial,wrote_flash=False,buzzer_on_commands_sent=0,physical_disconnect_tested=False,final_soc_acceptance=False)
    bridge=None
    try:
        with (out/'uart_transactions.jsonl').open('w',encoding='utf-8') as log:
            def connect():
                b=FastBridge(D2xxTransport.open(a.ftdi_serial,a.port),log,clock=time.perf_counter)
                try:b.identify()
                except BaseException:b.close();raise
                return b
            bridge=connect()
            report['idle_before']=bridge.command(3,budget_ms=200)[0]
            current=bridge.read_words(0x800d,1)[0]
            report['control_before_restore']=current
            if (current^target)&~0x0380:raise RuntimeError('control differs outside refresh field; do not overwrite')
            if current!=target:bridge.write_word(0x800d,target)
            restored=bridge.read_words(0x800d,1)[0]
            report['restored_control']=restored
            if restored!=target:raise RuntimeError('restore readback mismatch')
            report['restore']='VERIFIED'
            report['board_before_nack_ms']=bridge.last_ms
            begin=time.perf_counter()
            try:
                response=bridge.command(1,0x44,b'',1,budget_ms=20)
                report['nack_probe']=dict(status='UNEXPECTED_ACK',address7=0x44,response_hex=response.hex())
            except BoardError as exc:
                if str(exc)!='BOARD_STATUS_1':raise
                report['nack_probe']=dict(status='EXPECTED_NACK',address7=0x44,error=repr(exc),host_duration_ms=(time.perf_counter()-begin)*1000)
            # A complete nonzero board response is preserved. Reopen the exact
            # interface to purge late frames; do not continue a poisoned stream.
            bridge.close();bridge=None
            bridge=connect()
            report['idle_after_reopen']=bridge.command(3,budget_ms=200)[0]
            report['board_after_reopen_ms']=bridge.last_ms
            if ((bridge.last_ms-report['board_before_nack_ms'])&0xffffffff)>=0x80000000:raise RuntimeError('board clock reset during reopen')
            report['mlx_control_after_nack']=bridge.read_words(0x800d,1)[0]
            raw=bridge.read(0x45,bytes.fromhex('f32d'),3)
            crc=255
            for value in raw[:2]:
                crc^=value
                for _ in range(8):crc=((crc<<1)^0x31 if crc&128 else crc<<1)&255
            report.update(sht_status_hex=raw.hex(),sht_status_crc_ok=crc==raw[2])
            report['idle_final']=bridge.command(3,budget_ms=200)[0]
            report['status']='PASS_BOUNDED_NACK_AND_REOPEN_RECOVERY' if report['nack_probe']['status']=='EXPECTED_NACK' and report['idle_before']==report['idle_after_reopen']==report['idle_final']==3 and report['mlx_control_after_nack']==target and report['sht_status_crc_ok'] else 'NOT_PASSED'
    except Exception as exc:report.update(status='ERROR',error=repr(exc))
    finally:
        if bridge:bridge.close()
        report['files_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in out.iterdir() if f.is_file()}
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(output=str(out),**report),indent=2))
    return 0 if report['status']=='PASS_BOUNDED_NACK_AND_REOPEN_RECOVERY' else 1

if __name__=='__main__':raise SystemExit(main())
