`timescale 1ns/1ps
// Offline replay, not a simultaneous sensor/HDMI/AI acceptance test.
module tb_a_real_replay;
    reg clk=0;always #5 clk=~clk;
    reg rst=0,vs=0,de=0;reg [7:0] gray=0;
    reg [7:0] pixels[0:5183],thermal[0:767];reg [15:0] env[0:1];
    wire [9:0] heataddr;wire req,oh,ov,od;wire [23:0] rgb;
    integer file;
    video_a_result_display #(.WIDTH(480),.HEIGHT(270)) dut(
        .clk(clk),.rst_n(rst),.in_hs(1'b0),.in_vs(vs),.in_de(de),.in_rgb({gray,gray,gray}),
        .now_ms(32'd1000),.visual_timestamp_ms(32'd1000),.thermal_timestamp_ms(32'd1000),.environment_timestamp_ms(32'd1000),
        .valid_mask(3'b110),.fault_mask(3'b0),.alarm_active(1'b0),.prediction_valid(1'b0),
        .person_score(8'b0),.event_score(8'b0),.event_type(8'b0),
        .temperature_centi(env[0]),.humidity_centi(env[1]),.prediction_x(7'd0),.prediction_y(7'd0),
        .status_frame_id(32'b0),.display_frame_id(32'b0),.heat_pixel_valid(1'b1),.heat_level(thermal[heataddr]),
        .heat_address(heataddr),.heat_request(req),.out_hs(oh),.out_vs(ov),.out_de(od),.out_rgb(rgb));
    initial begin
        $readmemh("camera.mem",pixels);$readmemh("thermal.mem",thermal);$readmemh("environment.mem",env);
        repeat(5)@(negedge clk);rst=1;@(negedge clk);vs=1;@(negedge clk);vs=0;
        file=$fopen("real_inputs_REPLAY.ppm","wb");$fwrite(file,"P6\n480 270\n255\n");
        for(integer y=0;y<270;y++)begin
            for(integer x=0;x<480;x++)begin
                @(negedge clk);de=1;gray=pixels[(y/5)*96+x/5];@(posedge clk);#1;
                if(od!==1||oh!==0||ov!==0||(^rgb===1'bx))$fatal(1,"replay video / data invalid");
                $fwrite(file,"%c%c%c",rgb[23:16],rgb[15:8],rgb[7:0]);
            end
            @(negedge clk);de=0;repeat(2)@(negedge clk);
        end
        $fclose(file);$display("PASS tb_a_real_replay complete actual input replay; not hardware HDMI");$finish;
    end
    initial begin #2000000;$fatal(1,"timeout");end
endmodule
