/* Offline file reader only. Does not access a board, UART, MMIO or network. */
#include "b4_publish_gate.h"
#include <stdio.h>
#include <string.h>

_Static_assert(sizeof(coop_thermal_t) == 1652, "unexpected thermal ABI layout");

int main(int argc, char **argv) {
    FILE *file;
    coop_thermal_t input, output, sentinel;
    b4_publish_config_t config;
    uint32_t now, reasons, expected_id = 0;
    uint16_t valid;
    const uint16_t endian_probe = 1;
    if (argc != 2 || *(const unsigned char *)&endian_probe != 1) return 2;
    file = fopen(argv[1], "rb");
    if (!file) return 3;
    b4_publish_config_default(&config);
    for (;;) {
        size_t got = fread(&now, 1, sizeof(now), file);
        if (!got && feof(file)) break;
        if (got != sizeof(now) || fread(&input, 1, sizeof(input), file) != sizeof(input)) {
            fclose(file); return 4;
        }
        if (input.abi_version != COOP_ABI_VERSION || input.sample_id != expected_id ||
            input.valid_flags != 3u || input.error_bits != COOP_ERROR_PIXEL_QUALITY ||
            (input.pixel_valid_bits[620u/8u] & (1u << (620u%8u))) != 0 ||
            input.temperature_centi_c[620] != 0) { fclose(file); return 5; }
        memset(&output, 0xa5, sizeof(output));
        if (b4_publish_thermal(&input, now, &config, &output, &valid, &reasons) != COOP_OK ||
            valid != 767 || memcmp(&input, &output, sizeof(input))) { fclose(file); return 6; }
        memset(&output, 0xa5, sizeof(output)); sentinel = output;
        if (b4_publish_thermal(&input, input.timestamp_ms+501u, &config,
                              &output, &valid, &reasons) != COOP_ETIMEOUT ||
            memcmp(&output, &sentinel, sizeof(output))) { fclose(file); return 7; }
        ++expected_id;
    }
    if (ferror(file)) { fclose(file); return 8; }
    fclose(file);
    if (expected_id != 100u) return 9;
    printf("C_ABI_REPLAY_PASS records=%u sizeof_thermal=%u record_bytes=%u\n",
           (unsigned)expected_id, (unsigned)sizeof(input), (unsigned)(sizeof(now)+sizeof(input)));
    return 0;
}
