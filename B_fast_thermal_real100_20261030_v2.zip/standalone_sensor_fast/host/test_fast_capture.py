import copy
import io
import json
from pathlib import Path
import struct
import unittest

from fast_bridge import FastBridge, BoardError
from thermal_scheduler import (CaptureError, FrameReader, PairAssembler, Subpage,
                               age, refresh_control, validate_frame)


class Clock:
    def __init__(self): self.now = 0.
    def __call__(self): return self.now
    def sleep(self, seconds): self.now += seconds


def response(seq=1, status=0, payload=b"", stamp=100):
    body=bytes((seq,status,len(payload)))+struct.pack("<I",stamp)+payload
    xor=0
    for byte in body: xor^=byte
    return b"\x5a\xa5"+body+bytes((xor,))


class SerialFixture:
    def __init__(self, clock, response_bytes, step=.0001):
        self.clock,self.buffer,self.step=clock,bytearray(response_bytes),step
        self.writes=[]
        self.short=False
    @property
    def in_waiting(self): return len(self.buffer)
    def write(self, data):
        self.writes.append(data)
        return len(data)-1 if self.short else len(data)
    def read(self, count):
        self.clock.now+=self.step
        chunk=bytes(self.buffer[:count]);del self.buffer[:count]
        return chunk
    def close(self): pass


class SerialTransportTests(unittest.TestCase):
    def create(self, raw, step=.0001):
        self.clock=Clock();self.serial=SerialFixture(self.clock,raw,step)
        self.log=io.StringIO()
        return FastBridge(self.serial,self.log,clock=self.clock)
    def test_read_and_log(self):
        b=self.create(response(payload=b"\x12\x34"))
        self.assertEqual(b.read_words(0x8000,1),[0x1234])
        self.assertEqual(b.last_ms,100)
        self.assertEqual(json.loads(self.log.getvalue())["status"],0)
        self.assertEqual(self.serial.writes[0][2],1)
    def test_noisy_crc_and_heartbeat_are_skipped(self):
        bad=bytearray(response(payload=b"x"));bad[-1]^=1
        b=self.create(b"noise"+bytes(bad)+response(seq=255,payload=b"BQFAST01")+response(payload=b"x"))
        self.assertEqual(b.read(0x33,b"\x80\x00",1),b"x")
    def test_truncated_reply_is_bounded(self):
        b=self.create(response(payload=b"abc")[:-1],step=.001)
        with self.assertRaises(TimeoutError):b.read(0x33,b"a",3)
        with self.assertRaises(BoardError):b.read(0x33,b"a",3)
        self.assertEqual(len(self.serial.writes),1)
    def test_late_complete_reply_is_rejected(self):
        b=self.create(response(payload=b"a"),step=.021)
        with self.assertRaises(TimeoutError):b.read(0x33,b"a",1)
        self.assertTrue(b.failed)
    def test_board_error_and_short_payload(self):
        for raw in (response(status=2),response(payload=b"a")):
            b=self.create(raw)
            with self.assertRaises(BoardError):b.read(0x33,b"a",2)
    def test_short_write(self):
        b=self.create(b"");self.serial.short=True
        with self.assertRaises(BoardError):b.read(0x33,b"a",2)
    def test_wrap_is_accepted_reset_is_rejected(self):
        b=self.create(response(stamp=0xfffffff0)+response(seq=2,stamp=10))
        b.read(0x33,b"a",0)
        # Fixtures emulate separate reads, not pipelining.
        self.serial.buffer[:]=response(seq=2,stamp=10)
        b.read(0x33,b"a",0)
        self.serial.buffer[:]=response(seq=3,stamp=9)
        with self.assertRaises(BoardError):b.read(0x33,b"a",0)
    def test_identity_and_silent_status(self):
        b=self.create(response(payload=b"BQFAST01"))
        original=self.serial.write
        def write(data):
            n=original(data)
            if data[2]==3:self.serial.buffer[:]=response(seq=data[3],payload=b"\x03")
            return n
        self.serial.write=write
        self.assertEqual(b.identify(),b"BQFAST01")
    def test_wrong_identity_and_high_buzzer_fail(self):
        b=self.create(response(payload=b"BQUIET01"))
        with self.assertRaises(BoardError):b.identify()
        b=self.create(response(payload=b"BQFAST01"))
        original=self.serial.write
        def write(data):
            n=original(data)
            if data[2]==3:self.serial.buffer[:]=response(seq=data[3],payload=b"\x07")
            return n
        self.serial.write=write
        with self.assertRaises(BoardError):b.identify()
    def test_on_operation_and_bad_ranges_rejected_before_write(self):
        b=self.create(b"")
        for kwargs in ({"op":2},{"rx_count":65},{"budget_ms":0},{"tx":bytes(5)}):
            with self.assertRaises(ValueError):b.command(**kwargs)
        self.assertEqual(self.serial.writes,[])


class SensorFixture:
    def __init__(self,clock,page=0):
        self.clock,self.page=clock,page
        self.last_ms=10;self.polls=0;self.never_ready=False;self.overrun=False
        self.ram=[0]*832;self.calls=[];self.changed_page=False
    def read_words(self,reg,n):
        self.clock.now+=.001;self.last_ms+=1;self.calls.append((reg,n))
        if reg==0x8000:
            self.polls+=1
            if self.polls==1:return [(0 if self.never_ready else 8)|self.page]
            return [((8 if self.overrun else 0)|self.page) ^ int(self.changed_page)]
        if reg==0x800d:return [0x1981]
        if reg==0x400:return list(self.ram)
        raise ValueError(reg)
    def write_word(self,reg,value):
        self.clock.now+=.001;self.last_ms+=1;self.calls.append((reg,value))


def frame(page=0, observed=100, checked=200, control=0x1981):
    return Subpage([0]*832+[control,page],observed,observed,checked,checked,1.)


class SchedulerTests(unittest.TestCase):
    def test_reader_preserves_all_indices_and_times(self):
        c=Clock();s=SensorFixture(c)
        s.ram=list(range(832))
        r=FrameReader(s,clock=c,sleep=c.sleep).capture()
        self.assertEqual(r.words[:832],s.ram)
        self.assertEqual(r.page,0)
        self.assertLess(r.ready_observed_ms,r.checked_completed_ms)
        self.assertIn((0x400,832),s.calls)
    def test_poll_is_finite(self):
        c=Clock();s=SensorFixture(c);s.never_ready=True
        with self.assertRaises(TimeoutError):FrameReader(s,clock=c,sleep=c.sleep).capture(budget_ms=10)
        self.assertLess(c.now,.014)
    def test_overrun_and_changed_page_rejected(self):
        for key in ("overrun","changed_page"):
            c=Clock();s=SensorFixture(c);setattr(s,key,True)
            with self.assertRaises(CaptureError):FrameReader(s,clock=c,sleep=c.sleep).capture()
    def test_aux_invalid_is_not_silent_zero(self):
        c=Clock();s=SensorFixture(c);s.ram[768]=0x7fff
        with self.assertRaises(CaptureError):FrameReader(s,clock=c,sleep=c.sleep).capture()
    def test_pair_500_boundary_and_501_reject(self):
        for end,expected in ((600,"PAIRED_FOR_DIAGNOSTIC_ANALYSIS"),(601,"PAIR_OBSERVED_AGE_EXCEEDED")):
            a=PairAssembler();a.push(frame(0,100,200))
            r=a.push(frame(1,300,end))
            self.assertEqual(r["status"],expected)
    def test_duplicate_replacement_and_control_change(self):
        a=PairAssembler();a.push(frame(0))
        self.assertEqual(a.push(frame(0,250,300))["status"],"DUPLICATE_SUBPAGE_REPLACED")
        self.assertEqual(a.push(frame(1,310,350,control=0x1901))["status"],"CONTROL_CHANGED_DISCARD_OLD")
    def test_pair_wrap_and_reset(self):
        a=PairAssembler();a.push(frame(0,0xffffff00,0xffffff10))
        self.assertEqual(a.push(frame(1,0xffffff20,0x10))["status"],"PAIRED_FOR_DIAGNOSTIC_ANALYSIS")
        a.push(frame());a.reset();self.assertIsNone(a.pending)
    def test_future_and_invalid_frame_fail(self):
        a=PairAssembler()
        with self.assertRaises(CaptureError):a.push(frame(0,300,100))
        f=frame();f.words[833]=2
        with self.assertRaises(CaptureError):a.push(f)
    def test_refresh_changes_only_requested_bits(self):
        old=0x1901;new=refresh_control(old,3)
        self.assertEqual(new,0x1981)
        self.assertEqual((old^new)&~0x0380,0)
        self.assertEqual(age(0x10,0xfffffff0),32)
        with self.assertRaises(ValueError):refresh_control(old,8)


if __name__=="__main__":unittest.main()
