#ifndef B6_FRAME_PACKETS_H
#define B6_FRAME_PACKETS_H
#include <stddef.h>
#include <stdint.h>
#define B6_IMAGE_BYTES 9216u
#define B6_PAYLOAD_BYTES 1200u
#define B6_HEADER_BYTES 48u
#define B6_PACKET_BYTES (B6_HEADER_BYTES + B6_PAYLOAD_BYTES)
#define B6_PACKET_COUNT 8u
#define B6_OK 0
#define B6_EINVAL (-1)
#define B6_ESEND (-2)
/* Local DRAFT ONLY. No accepted team network ABI is claimed.
 * image must remain immutable during this synchronous call.
 * send_packet must copy/consume the packet before returning; buffer is reused.
 * Callback success means transport accepted it, not that the peer received it.
 */
typedef struct {
    uint32_t event_id;
    uint32_t frame_id;
    uint32_t capture_ms;
} b6_frame_info_t;
typedef int (*b6_send_packet_fn)(void *context, const uint8_t *packet, size_t bytes);
uint32_t b6_crc32(const uint8_t *data, size_t bytes);
int b6_packetize_frame(const b6_frame_info_t *info, const uint8_t *image,
                      size_t image_bytes, uint8_t *buffer, size_t buffer_bytes,
                      b6_send_packet_fn send_packet, void *context,
                      uint16_t *sent_packets);
#endif
