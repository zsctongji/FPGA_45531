"""Production PC receiver stress with real image bytes, PC-authored test events.
All wire messages are SYNTHETIC. This is not B-board Ethernet evidence.
"""
from pathlib import Path
from datetime import datetime,timezone
import csv
import hashlib
import json
import random
import socket
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools/a_side'))
from protocol import packets,event_body

def main():
    target=ROOT/'logs/a_side/pc_stress_20261029'
    target.mkdir(parents=True,exist_ok=False)
    source=ROOT/'team_work/01_video/ai_samples_20261029/object_pattern.gray';image=source.read_bytes()
    count=300;period=.2
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as reservation:
        reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
    command=[sys.executable,'-u',str(ROOT/'tools/a_side/receiver.py'),'--bind','127.0.0.1','--port',str(port),
             '--web-port','0','--seconds','70','--output',str(target)]
    started=time.monotonic();ready=False
    with (target/'process.log').open('w',encoding='utf-8') as log:
        process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
        try:
            while time.monotonic()-started<10:
                if process.poll() is not None:raise RuntimeError('Receiver exited before readiness')
                if 'UDP 127.0.0.1:' in (target/'process.log').read_text(encoding='utf-8'):ready=True;break
                time.sleep(.05)
            if not ready:raise TimeoutError('Receiver readiness')
            start=time.monotonic();rng=random.Random(20261029)
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as tx:
                for i in range(count):
                    deadline=start+i*period
                    if deadline>time.monotonic():time.sleep(deadline-time.monotonic())
                    dest=('127.0.0.1',port)
                    event=event_body(event_type=0,score=0,valid_mask=0)
                    tx.sendto(packets(1,0xA20261029&0xffffffff,i,71760,i*200,event,1)[0],dest)
                    parts=packets(2,0xA20261029&0xffffffff,i,71760,i*200,image,1)
                    if i%25==0:
                        bad=bytearray(parts[0]);bad[50]^=1;tx.sendto(bad,dest)
                    order=list(range(8));rng.shuffle(order)
                    if i%7==0:
                        tx.sendto(parts[0],dest);tx.sendto(parts[0],dest);order.remove(0)
                    if i%20==0:order.remove(3)
                    for n in order:tx.sendto(parts[n],dest)
            code=process.wait(timeout=20)
            if code:raise RuntimeError('Receiver failed; see process.log')
        finally:
            if process.poll() is None:process.terminate();process.wait(timeout=10)
    summary=json.loads((target/'receiver_summary.json').read_text())
    events=list(csv.DictReader((target/'events.csv').open(encoding='utf-8-sig')))
    images=list(target.glob('*.pgm'));c=summary['counters']
    assert len(events)==300 and len(images)==285 and summary['saved']==585
    assert c['invalid']==12 and c['timeout']==15 and c['duplicate']==43 and c['out_of_order']>0
    assert summary['incomplete']==0 and all(p.read_bytes()[-9216:]==image for p in images)
    record=dict(status='PASS',scope='PC_loopback_production_receiver_under_disk_load',
        board_ethernet_verified=False,synthetic_events=True,source_image=str(source),source_image_sha256=hashlib.sha256(image).hexdigest(),
        events=300,complete_images=285,deliberately_incomplete_images=15,corrupt_datagrams_rejected=12,
        duplicate_datagrams_ignored=43,all_saved_image_bytes_match=True,counters=c,
        seconds=time.monotonic()-started,folder=str(target),finished=datetime.now(timezone.utc).isoformat(),
        sources={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                 [Path(__file__),ROOT/'tools/a_side/protocol.py',ROOT/'tools/a_side/receiver.py']})
    (ROOT/'logs/a_udp_stress_20261029.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
