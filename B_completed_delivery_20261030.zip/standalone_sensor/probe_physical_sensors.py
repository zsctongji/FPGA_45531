import json,sys,time
from pathlib import Path
from datetime import datetime
import ftd2xx
from bridge import Bridge
ROOT=Path(__file__).resolve().parent
out=ROOT/'logs'/'physical_probe';out.mkdir(exist_ok=True)
report={'at':datetime.now().astimezone().isoformat(),'source':'REAL_BOARD','final_soc_test':False,'ports':[]}
with (out/'uart_transactions.jsonl').open('a',encoding='utf-8') as log:
 for serial_name in ftd2xx.listDevices():
  if serial_name==b'A':continue
  try:
   d=ftd2xx.openEx(serial_name);port=d.getComPortNumber();d.close()
   name='COM'+str(port);bridge=Bridge(name,log)
   try:
    identity=bridge.command()
    row={'ftdi_channel':serial_name.decode(),'port':name,'identity':identity.decode('ascii','replace')}
    report['ports'].append(row)
    if identity==b'BTEST001':
     report['selected_port']=name;report['identity']='BTEST001';report['initial_bus_levels']=int.from_bytes(bridge.command(3),'little');report['board_ms']=bridge.last_ms
     for addr in [0x45,0x44,0x33]:
      r={'address7':hex(addr)}
      try:
       if addr==0x33:
        data=bridge.read(addr,bytes.fromhex('800d'),2);r['control_hex']=data.hex()
       else:
        bridge.read(addr,bytes.fromhex('2400'),0);time.sleep(.020);data=bridge.read(addr,b'',6);r['raw_hex']=data.hex()
       r['status']='ACK'
      except Exception as exc:r['status']='ERROR';r['error']=repr(exc)
      report.setdefault('sensor_probes',[]).append(r)
     report['status']='BRIDGE_FOUND';break
   except Exception as exc:report['ports'].append({'port':name,'error':repr(exc)})
   finally:bridge.close()
  except Exception as exc:report['ports'].append({'ftdi_channel':serial_name.decode(),'error':repr(exc)})
report.setdefault('status','NO_UART_BRIDGE_RESPONSE')
(out/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='BRIDGE_FOUND' else 1)
