`timescale 1ns/1ps
module tb_quiet;
reg clk=0;always #10 clk=~clk;
reg rx=1;wire tx,buzzer,oe1,oe2;tri1 scl,sda;
assign scl=oe1?1'b0:1'bz;assign sda=oe2?1'b0:1'bz;
B_sensor_quiet dut(.key_i(4'b1111),.sys_pll_LOCKED(1'b1),.clk_sel(1'b0),.clk_50m(clk),.clk_54m(1'b0),.clk_25m_x2(1'b0),.osc_clk(1'b0),.uart_rx(rx),.uart_tx(tx),.sensor_scl_in(scl),.sensor_sda_in(sda),.sensor_scl_oe(oe1),.sensor_sda_oe(oe2),.buzzer_sig(buzzer));
localparam BIT=8680;
reg [7:0] out[0:99];integer n=0,i;reg [7:0] byte_rx;
always begin @(negedge tx);#(BIT+BIT/2);for(i=0;i<8;i=i+1)begin byte_rx[i]=tx;#BIT;end if(tx!==1)$fatal(1,"bad stop bit");out[n]=byte_rx;n=n+1;end
always @(posedge clk) if(buzzer!==1'b0)$fatal(1,"buzzer is not muted");
task send;input [7:0] v;integer k;begin rx=0;#BIT;for(k=0;k<8;k=k+1)begin rx=v[k];#BIT;end rx=1;#BIT;end endtask
task packet;input [7:0] op,seq,nt,arg;reg [7:0] checksum;begin
 checksum=op^seq^nt^arg;
 send(8'ha5);send(8'h5a);send(op);send(seq);send(0);send(nt);send(0);send(arg);send(0);send(0);send(0);send(checksum);
end endtask
initial begin
 #5000;
 packet(0,7,0,0);wait(n==18);#BIT;
 if({out[9],out[10],out[11],out[12],out[13],out[14],out[15],out[16]}!="BQUIET01")$fatal(1,"wrong quiet identity");
 packet(2,8,1,1);wait(n==28);#BIT;
 if(out[21]!=3)$fatal(1,"old ON command was not rejected");
 packet(2,9,1,0);wait(n==38);#BIT;
 if(out[31]!=0)$fatal(1,"OFF command failed");
 packet(3,10,0,0);wait(n==49);#BIT;
 if(out[41]!=0 || out[47][2]!=0)$fatal(1,"status did not report silent output");
 $display("PASS: default output LOW; BQUIET01 identity; legacy ON rejected; OFF accepted; status LOW");$finish;
end
initial begin #20000000;$fatal(1,"test timeout");end
endmodule
