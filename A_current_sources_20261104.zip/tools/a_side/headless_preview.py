"""Read-only local viewer of saved real gray snapshots; never opens the UART."""
import argparse
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
from pathlib import Path
import re
import time

PAGE='''<!doctype html><meta charset="utf-8"><title>A 实际灰度图导出</title>
<style>body{font:17px system-ui;margin:28px;background:#f5f5f0;color:#18232a;max-width:1000px}canvas{image-rendering:pixelated;width:480px;height:480px;background:#111}pre{white-space:pre-wrap;background:white;padding:16px} .layout{display:flex;gap:28px;flex-wrap:wrap}dt{font-weight:600;margin-top:10px}dd{margin-left:0}</style>
<h1>A · 板上灰度图与运动统计</h1><p>来自已保存的 USB 串口图像，每张 96×96。编号和时间属于 DDR 读出后的显示流；摄像头采集帧率另由 A2 记录测量。</p>
<div class="layout"><div><canvas id="image" width="96" height="96"></canvas><p id="label">等待完整图像</p></div><dl id="fields"></dl></div>
<p>上下各 21 行为黑色填充。橙框为同帧阈值帧差范围；它不是 AI 人体框。此页不表示软核推理、HDMI 或以太网验收。</p>
<details><summary>原始元数据</summary><pre id="raw"></pre></details>
<script>
let last='';const cvs=document.getElementById('image'),ctx=cvs.getContext('2d');
function add(k,v){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=v;document.getElementById('fields').append(dt,dd)}
async function refresh(){try{let r=await fetch('/status',{cache:'no-store'}),d=await r.json();if(!d.latest)return;let m=d.latest;
document.getElementById('raw').textContent=JSON.stringify(d,null,2);document.getElementById('fields').replaceChildren();
add('显示帧 / 本地时间 ms',`${m.frame_id} / ${m.timestamp_ms}`);add('完整图字节 / SUM32',`9216 / ${m.checksum}`);
add('变化点 / 差值和',`${m.changed_count} / ${m.absolute_difference_sum}`);add('与前一显示帧比较',m.comparison_valid?'有效':'尚无基线');
add('运动 / 网格包围框',`${m.motion} / ${JSON.stringify(m.bbox_grid)}`);add('有效区灰度范围',`${m.gray_min}～${m.gray_max}`);
add('已保存图像',d.images);add('来源关联', '显示流，尚未绑定 CSI 源帧 / 共享时间');
add('采集状态',d.capture_active?'正在写入新快照':'显示最后保存的完整快照');
document.getElementById('label').textContent=m.file;
if(last!==d.capture+m.file){let im=new Image();im.onload=()=>{ctx.drawImage(im,0,0);if(m.bbox_valid){let [x0,y0,x1,y1]=m.bbox_grid;ctx.strokeStyle='#ffad36';ctx.lineWidth=.4;ctx.strokeRect(x0,y0+21,x1-x0+1,y1-y0+1)}};im.src='/image.bmp?frame='+m.frame_id;last=d.capture+m.file;}
}catch(e){document.getElementById('label').textContent='等待完整写入 / '+e.message}}
refresh();setInterval(refresh,500);
</script>'''

def handler(folder,follow_latest=False):
    root=Path(folder).resolve()
    def current_folder():
        if not follow_latest:return root
        candidates=[p for p in root.iterdir() if p.is_dir() and next(p.glob('frame_*.bmp'),None)]
        return max(candidates,key=lambda p:p.stat().st_mtime) if candidates else root
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            folder=current_folder()
            if self.path=='/':content=PAGE.encode();mime='text/html; charset=utf-8'
            elif self.path=='/status':
                files=sorted(folder.glob('frame_*.json'));latest=None
                # A JSON file is written last. If the newest is mid-write, show
                # the previous complete snapshot rather than a partial object.
                for file in reversed(files[-3:]):
                    try:
                        candidate=json.loads(file.read_text(encoding='utf-8'))
                        if not file.with_suffix('.bmp').is_file():continue
                        latest=candidate
                        latest['file']=file.name;break
                    except (OSError,ValueError):continue
                active=bool(files) and time.time()-files[-1].stat().st_mtime<3
                content=json.dumps(dict(images=len(files),latest=latest,capture_active=active,capture=folder.name),ensure_ascii=False).encode();mime='application/json; charset=utf-8'
            elif match:=re.fullmatch(r'/image\.bmp\?frame=(\d{1,10})',self.path):
                file=folder/f'frame_{int(match[1]):010d}.bmp'
                try:content=file.read_bytes()
                except OSError:self.send_error(404);return
                mime='image/bmp'
            else:self.send_error(404);return
            self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(content)))
            self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(content)
        def log_message(self,*args):pass
    return Handler

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder');p.add_argument('--port',type=int,default=39005)
    p.add_argument('--follow-latest',action='store_true')
    a=p.parse_args();server=ThreadingHTTPServer(('127.0.0.1',a.port),handler(a.folder,a.follow_latest))
    print(f'A actual gray preview: http://127.0.0.1:{a.port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
