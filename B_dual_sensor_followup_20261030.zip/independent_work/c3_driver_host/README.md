# 原 SHT30 C 驱动的主机故障注入验证

直接用主机 GCC/Clang 编译随包附带的原版 b_sht30.c 与 c3_hal.c，通过 C mock HAL 注入时钟、I2C 返回值、CRC 错误和有限事务延迟。没有重新用 Python 实现传感器驱动。

已通过 16 个场景、361 条断言：转换等待边界、固定原始值换算和上下限、NACK/总线错误/读超时恢复、温度和湿度 CRC 错误恢复、三次重试耗尽、启动失败清除旧数据、100 ms 总期限、后端20 ms事务超时、2000 ms陈旧边界、uint32回绕、地址和HAL参数校验。

运行：

```text
python run_driver_checks.py --cc "C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\gcc.exe" --report results/local_report.json
```

依赖 Python 3.10+ 及主机 C11 GCC/Clang。脚本会从 PATH、CC 环境变量或本机已有 GCC 默认路径寻找编译器；不会下载软件、访问串口或烧写板卡。

vendor/ 的5个文件从本地团队接口快照原样复制；与原文件逐字节一致，散列记录于 results/host_driver_report.json。源位置为 FPGA_B_20261025/team_work/02_sensors_alarm 和 upstream_snapshot，不能据此声称验证了队友所有新分支。

scope=HOST_C_DRIVER_MOCK_HAL，hardware_accessed=false。该结果证明指定驱动在可控的主机回调下遵循上述状态转换。真实 SoC I2C 的 STOP 清理、总线恢复和超时仍要在后端实现后上板验证。若真实回调永不返回，普通 C 包装层不能将其强制中止。
