"""A2D1 serial diagnostic contract, corruption and mixed-stream regression."""
import struct
import unittest
from capture_camera_input import Decoder, DEBUG_RECORD, RECORD
from capture_headless import Decoder as MixedDecoder


def packet(frame=1, flags=6, config=0x0744, raw=0x1234, seen=0x5234):
    blob=DEBUG_RECORD.pack(b'A2D1',frame,33,1920,1080,1,flags,config,
                           3,0,0,raw,seen,7,1666667,0)
    return blob[:-4]+struct.pack('<I',sum(blob[:-4]))


class DebugTests(unittest.TestCase):
    def test_config_and_debug_coexist(self):
        self.assertEqual(DEBUG_RECORD.size,48)
        row=Decoder().feed(packet())[0]
        self.assertEqual(row['camera_register_address'],0x320d)
        self.assertEqual(row['camera_register_value'],0x44)
        self.assertEqual(row['raw_csi_debug'],0x1234)
        self.assertEqual(row['raw_csi_seen'],0x5234)
        self.assertEqual(row['raw_csi_rising_cycles'],7)
        self.assertEqual(row['raw_csi_window_cycles'],1666667)
        self.assertFalse(row['transport_errors_qualified'])

    def test_corruption_noise_fragmentation_and_resync(self):
        bad=bytearray(packet());bad[34]^=128
        stream=b'noise'+packet(1)+bad+packet(3)
        decoder=Decoder();rows=[]
        for byte in stream:rows.extend(decoder.feed(bytes([byte])))
        self.assertEqual([r['frame_id'] for r in rows],[1,3])
        self.assertEqual(decoder.stats['invalid'],1)

    def test_legacy_and_extended_can_mix(self):
        old=RECORD.pack(b'A2V1',0,0,1920,1080,1,4,0x0744,2,0,0,0)
        old=old[:-4]+struct.pack('<I',sum(old[:-4]))
        rows=Decoder().feed(old+packet())
        self.assertEqual([r['protocol'] for r in rows],['A2V1','A2D1'])
        self.assertIsNone(rows[0]['raw_csi_debug'])
        self.assertIsNone(rows[0]['raw_csi_seen'])
        self.assertEqual(rows[1]['raw_csi_debug'],0x1234)
        self.assertEqual(set(rows[0]),set(rows[1])) # Stable CSV columns.

    def test_config_invalid_flags_and_partial_record(self):
        d=Decoder()
        self.assertFalse(d.feed(packet(config=0x1044)+packet(flags=7)))
        self.assertEqual(d.stats['invalid'],2)
        good=packet(flags=0)
        self.assertFalse(d.feed(good[:-1]))
        self.assertEqual(d.feed(good[-1:])[0]['raw_csi_debug'],0x1234)

    def test_extended_without_config(self):
        row=Decoder().feed(packet(flags=0,config=0xabcd,raw=0xffff,seen=0xffff))[0]
        self.assertIsNone(row['camera_register_address'])
        self.assertEqual(row['raw_csi_debug'],65535)

    def test_headless_demux_accepts_extended(self):
        decoder=MixedDecoder();rows=[];images=[]
        for offset in range(0,48,5):
            r,i=decoder.feed(packet()[offset:offset+5]);rows.extend(r);images.extend(i)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['protocol'],'A2D1')
        self.assertFalse(images)


if __name__=='__main__':unittest.main()
