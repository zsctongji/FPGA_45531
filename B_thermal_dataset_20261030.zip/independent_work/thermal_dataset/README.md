# B：100 组真实热图的离线数据交接

这一步使用 2026-10-30 已保存的 Ti60F225 + MLX90640 实测记录，不连接板卡，也不增加实测样本数。原始采集、原厂算法换算、主机上的 C 策略探针分别标明。

在工程根目录运行：

```powershell
python -B independent_work/thermal_dataset/build_dataset.py
python -B -m unittest discover -s independent_work/thermal_dataset -p test_dataset.py -v
```

输出 `results/thermal_records.jsonl`（每行一组）、`thermal_metrics.csv`、`thermal_probe_records.bin` 和 `dataset_report.json`。100 组使用 200 个不同测量子页；4 个预热子页排除。每个位置保持原有 32×24 行优先索引，不镜像、不旋转。620 号坏点在 JSON 中为 null，96 字节位图按 LSB 优先保存。热区只是候选温度连通域，尚无人体或跌倒标签。

JSONL 包含原始子页文件名及 SHA256、原始浮点温度和有效原因、独立板端时钟域、配对观察年龄，以及原 B4 C 策略的四种探针。重建的 ABI 标志为 COMPLETE|CONVERTED=3，错误位保留 PIXEL_QUALITY=64；这不是板上曾发布过这些结构体的证据。B4 允许保留坏点告警；最终 C3 驱动的严格策略仍需 C 确认，不能把 B4 通过等同 C3 通过。

二进制只供离线软件回放，不是新增正式网络协议。每条 1656 字节：小端 uint32 `probe_now_ms`，随后 1652 字节原 `coop_thermal_t`。原 ABI 不变。有效温度用 Python round（恰好半数时取偶数）转为百分之一摄氏度；无效位置的整数占位为 0，位图仍为 0，不能将其解释为 0°C。C 读取器直接包含冻结的团队 ABI 和 B4 源码，编译时检查结构体大小，再逐条验证拷贝、掩码和过期拒绝。

观察年龄从首个子页 ready 被板端观察到开始，到第二个子页最终状态检查完成。100 组均低于 500ms；这个时间不含后续电脑温度计算、传输到最终 SoC/图像融合/显示的耗时，也不代表曝光年龄。`remaining_budget_ms` 是该观察点上的算术余量，不是整机性能承诺。500ms 恰好接受，501ms 与未来时间拒绝；计数器回绕单独测试。

不能把该会话与之前另一次 SHT30 或 A 图像会话配成“真实同步数据”。仍需最终 SoC I2C/时钟、同会话视频、空间方向，以及事件、显示、网络、报警的联合验收。无需为了运行这些工具连接板子。
