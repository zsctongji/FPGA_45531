`timescale 1ns/1ps
module tb_camera_input_uart #(parameter DATA_VS_HIGH=0,HAS_CONFIG=0,EXTENDED=0);
    reg clk=0;always #5 clk=~clk;
    reg rst_n=0,vs=0,de=0,hs=0;
    wire tx;wire [31:0] drops;
    reg [15:0] raw_debug=16'h1234;
    localparam N=EXTENDED ? 48 : 36;
    camera_input_uart #(.CLK_HZ(1000000),.BAUD(100000),.WIDTH(8),.HEIGHT(3),.EXTENDED_DIAGNOSTIC(EXTENDED)) dut(
        .clk(clk),.rst_n(rst_n),.in_vs(vs),.in_de(de),.in_hs(hs),.raw_debug(raw_debug),
        .config_snapshot(128'h2f2e2d2c2b2a29282726252423222120),.config_valid(HAS_CONFIG!=0),
        .tx(tx),.telemetry_drops(drops));
    task tick;begin @(posedge clk);#1;end endtask
    task boundary;begin @(negedge clk);vs=!DATA_VS_HIGH;de=0;tick();end endtask
    task line(input integer beats);integer i;begin
        @(negedge clk);vs=DATA_VS_HIGH;de=1;hs=1;
        for(i=0;i<beats;i=i+1)begin
            tick();
            if(i+1<beats)begin
                @(negedge clk);de=0;tick();tick(); // CSI payload bubbles within HS
                @(negedge clk);de=1;
            end
        end
        @(negedge clk);de=0;hs=0;tick();
    end endtask
    reg [7:0] bytes[0:N-1];
    reg [15:0] ref_seen=0,ref_previous=0;
    reg [31:0] ref_edges=0,ref_cycles=0;
    reg [15:0] saved_seen[0:3],saved_raw[0:3];
    reg [31:0] saved_edges[0:3],saved_cycles[0:3];
    integer accepted=0;
    always @(posedge clk) if(rst_n)begin
        ref_seen=ref_seen | raw_debug;
        ref_edges=ref_edges+(|(raw_debug & ~ref_previous));
        ref_cycles=ref_cycles+1;
        ref_previous=raw_debug;
        if(dut.rv && !dut.active)begin
            saved_seen[accepted]=ref_seen;saved_raw[accepted]=raw_debug;
            saved_edges[accepted]=ref_edges;saved_cycles[accepted]=ref_cycles;
            accepted=accepted+1;ref_seen=0;ref_edges=0;ref_cycles=0;
        end
    end
    integer n,b,k,received=0;reg [31:0] sum,wire_sum;
    initial begin
        wait(rst_n);
        for(k=0;k<2;k=k+1)begin
            for(n=0;n<N;n=n+1)begin
                @(negedge tx);repeat(15)@(posedge clk);#1;
                for(b=0;b<8;b=b+1)begin
                    bytes[n][b]=tx;
                    repeat(10)@(posedge clk);#1;
                end
                if(tx!==1)$fatal(1,"UART stop bit");
            end
            if({bytes[3],bytes[2],bytes[1],bytes[0]}!==(EXTENDED ? 32'h31443241 : 32'h31563241))$fatal(1,"magic");
            if(bytes[4]!==k*2 || bytes[12]!==8 || bytes[14]!==3 || bytes[16]!==1 || bytes[17]!==(DATA_VS_HIGH*2+HAS_CONFIG*4))
                $fatal(1,"frame/geometry/flag metadata");
            if(HAS_CONFIG)begin
                if(bytes[18]!==(8'h20+k*2) || bytes[19]!==k*2)$fatal(1,"config snapshot/index endian");
            end else if(bytes[18]!==8'h34 || bytes[19]!==8'h12)$fatal(1,"debug endian");
            if(EXTENDED)begin
                if({bytes[33],bytes[32]}!==saved_raw[k] || {bytes[35],bytes[34]}!==saved_seen[k])$fatal(1,"raw debug snapshot/sticky window");
                if({bytes[39],bytes[38],bytes[37],bytes[36]}!==saved_edges[k])$fatal(1,"raw rising cycle count");
                if({bytes[43],bytes[42],bytes[41],bytes[40]}!==saved_cycles[k])$fatal(1,"debug window clocks");
                if(k==1 && !(saved_seen[k]&16'h4000))$fatal(1,"lost transient while UART busy");
            end
            sum=0;for(n=0;n<N-4;n=n+1)sum=sum+bytes[n];
            wire_sum={bytes[N-1],bytes[N-2],bytes[N-3],bytes[N-4]};
            if(sum!==wire_sum)$fatal(1,"SUM32");
            if(bytes[28]!==k || bytes[24]!==k)$fatal(1,"drop/malformed counters");
            received=received+1;
        end
        $display("PASS tb_camera_input_uart: real 8N1 decode, endian/checksum, busy drop and recovery");
        $finish;
    end
    initial begin
        if(EXTENDED)begin
            wait(dut.active);repeat(20)tick();
            @(negedge clk);raw_debug=16'h5234;tick();
            @(negedge clk);raw_debug=16'h1234;
        end
    end
    initial begin
        tick();@(negedge clk);rst_n=1;boundary();line(2);line(2);line(2);boundary();
        // First frame learns actual VS polarity; only following complete frames publish.
        line(2);line(2);line(2);boundary();
        // Malformed second frame arrives while UART is busy: count, never stall.
        line(1);line(2);line(2);boundary();
        wait(received==1);repeat(20)tick();line(2);line(2);line(2);boundary();
    end
    initial begin #2000000;$fatal(1,"timeout");end
endmodule
