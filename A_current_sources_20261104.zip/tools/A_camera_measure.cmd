@echo off
echo Read-only 65-second camera ingress measurement. A diagnostic image required.
echo No monitor needed. Do not run another tool on the same UART.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_a_side.ps1" -Mode CameraMeasure
pause
