#include "b4_publish_gate.h"
#include <string.h>

static uint32_t age_valid(uint32_t now_ms, uint32_t sample_ms, uint32_t max_age_ms) {
    uint32_t age = now_ms - sample_ms;
    return age < 0x80000000u && age <= max_age_ms;
}

void b4_publish_config_default(b4_publish_config_t *config) {
    if (!config) return;
    b4_quality_policy_default(&config->quality);
    b4_temporal_config_default(&config->temporal);
    config->max_thermal_age_ms = COOP_THERMAL_MAX_LAG_MS;
}

void b4_publish_reset(b4_publish_state_t *state) {
    if (!state) return;
    b4_temporal_reset(&state->environment_temporal);
}

int b4_publish_environment(b4_publish_state_t *state,
                           const coop_environment_t *input,
                           uint32_t now_ms,
                           const b4_publish_config_t *config,
                           coop_environment_t *output,
                           uint32_t *reason_bits) {
    uint32_t quality_reasons = 0, temporal_reasons = 0;
    int rc;
    if (reason_bits) *reason_bits = 0;
    if (!state || !input || !config || !output) return COOP_EINVAL;
    rc = b4_quality_environment(input, &config->quality, &quality_reasons);
    if (rc != COOP_OK) {
        if (reason_bits) *reason_bits = quality_reasons << B4_GATE_REASON_QUALITY_SHIFT;
        return rc;
    }
    rc = b4_temporal_accept_environment(&state->environment_temporal, input,
                                        now_ms, &config->temporal,
                                        &temporal_reasons);
    if (rc != COOP_OK) {
        if (reason_bits) *reason_bits = temporal_reasons << B4_GATE_REASON_TEMPORAL_SHIFT;
        return rc;
    }
    *output = *input;
    return COOP_OK;
}

int b4_publish_thermal(const coop_thermal_t *input,
                       uint32_t now_ms,
                       const b4_publish_config_t *config,
                       coop_thermal_t *output,
                       uint16_t *valid_pixels,
                       uint32_t *reason_bits) {
    uint32_t quality_reasons = 0;
    int rc;
    if (reason_bits) *reason_bits = 0;
    if (valid_pixels) *valid_pixels = 0;
    if (!input || !config || !output || !config->max_thermal_age_ms ||
        config->max_thermal_age_ms >= 0x80000000u)
        return COOP_EINVAL;
    rc = b4_quality_thermal(input, &config->quality, valid_pixels, &quality_reasons);
    if (rc != COOP_OK) {
        if (reason_bits) *reason_bits = quality_reasons << B4_GATE_REASON_QUALITY_SHIFT;
        return rc;
    }
    if (!age_valid(now_ms, input->timestamp_ms, config->max_thermal_age_ms)) {
        uint32_t age = now_ms - input->timestamp_ms;
        uint32_t temporal_reason = age >= 0x80000000u
            ? B4_TEMPORAL_REASON_FUTURE : B4_TEMPORAL_REASON_TOO_OLD;
        if (reason_bits) *reason_bits = temporal_reason << B4_GATE_REASON_TEMPORAL_SHIFT;
        return COOP_ETIMEOUT;
    }
    *output = *input;
    return COOP_OK;
}
