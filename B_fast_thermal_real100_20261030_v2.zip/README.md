# Ti60F225 real-board thermal delivery

Read records/B_热成像100组实测交接_20261030.md.
Offline: python -B standalone_sensor_fast/verify_fast_bundle.py
Offline raw-evidence audit: python -B tools/audit_fast_real100.py --verify-only
100 real thermal pairs; not final C3 or fall-detection acceptance.
